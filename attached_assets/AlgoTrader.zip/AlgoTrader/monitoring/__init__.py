# Import all monitoring components
from monitoring.trade_monitor import TradeMonitor
from monitoring.opportunity_detector import OpportunityDetector
from monitoring.alert_system import AlertSystem