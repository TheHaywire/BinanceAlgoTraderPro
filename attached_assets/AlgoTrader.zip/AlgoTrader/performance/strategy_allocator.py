"""
Dynamic Strategy Allocation System for optimizing capital distribution across strategies
"""

import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from models import db, Trade, StrategyPerformance

class StrategyAllocator:
    """
    Dynamic strategy allocator for optimizing capital allocation across strategies
    based on performance metrics and market conditions
    """
    
    def __init__(self, client, initial_allocation=None):
        """
        Initialize strategy allocator
        
        Args:
            client (BinanceClient): Binance client instance
            initial_allocation (dict, optional): Initial allocation percentages by strategy
        """
        self.client = client
        self.logger = logging.getLogger(__name__)
        
        # Default allocation gives 100% to the first strategy if none provided
        self.allocation = initial_allocation or {'MomentumBreakoutStrategy': 100.0}
        
        # Strategy performance metrics
        self.performance_metrics = {}
        
        # Market regime indicators
        self.market_regime = {
            'is_trending': False,
            'is_volatile': False,
            'correlation_level': 'low',
            'trend_direction': 'neutral'
        }
        
    def update_market_regime(self, symbols=None):
        """
        Update market regime indicators
        
        Args:
            symbols (list, optional): List of symbols to analyze
        """
        if symbols is None:
            symbols = ['BTCUSDT']  # Default to BTC
            
        try:
            # Analyze market trend
            self._analyze_trend(symbols[0])
            
            # Analyze volatility
            self._analyze_volatility(symbols[0])
            
            # Log market regime
            self.logger.info(f"Market regime updated: Trending: {self.market_regime['is_trending']}, "
                           f"Volatile: {self.market_regime['is_volatile']}, "
                           f"Direction: {self.market_regime['trend_direction']}")
                           
        except Exception as e:
            self.logger.error(f"Error updating market regime: {e}")
    
    def _analyze_trend(self, symbol):
        """
        Analyze market trend for a symbol
        
        Args:
            symbol (str): Symbol to analyze
        """
        try:
            # Get historical data for the 1h and 4h timeframes
            klines_1h = self.client.get_historical_klines(symbol, '1h', limit=50)
            klines_4h = self.client.get_historical_klines(symbol, '4h', limit=30)
            
            # Convert to DataFrames
            df_1h = pd.DataFrame(klines_1h)
            df_4h = pd.DataFrame(klines_4h)
            
            # Calculate EMAs
            df_1h['ema20'] = df_1h['close'].ewm(span=20, adjust=False).mean()
            df_1h['ema50'] = df_1h['close'].ewm(span=50, adjust=False).mean()
            
            df_4h['ema20'] = df_4h['close'].ewm(span=20, adjust=False).mean()
            df_4h['ema50'] = df_4h['close'].ewm(span=50, adjust=False).mean()
            
            # Determine trend
            is_trending_1h = (df_1h['ema20'].iloc[-1] > df_1h['ema50'].iloc[-1] and 
                            df_1h['close'].iloc[-1] > df_1h['ema20'].iloc[-1]) or \
                           (df_1h['ema20'].iloc[-1] < df_1h['ema50'].iloc[-1] and 
                            df_1h['close'].iloc[-1] < df_1h['ema20'].iloc[-1])
                            
            is_trending_4h = (df_4h['ema20'].iloc[-1] > df_4h['ema50'].iloc[-1] and 
                            df_4h['close'].iloc[-1] > df_4h['ema20'].iloc[-1]) or \
                           (df_4h['ema20'].iloc[-1] < df_4h['ema50'].iloc[-1] and 
                            df_4h['close'].iloc[-1] < df_4h['ema20'].iloc[-1])
                            
            # Update market regime
            self.market_regime['is_trending'] = is_trending_1h and is_trending_4h
            
            # Determine trend direction
            if df_1h['ema20'].iloc[-1] > df_1h['ema50'].iloc[-1] and df_4h['ema20'].iloc[-1] > df_4h['ema50'].iloc[-1]:
                self.market_regime['trend_direction'] = 'bullish'
            elif df_1h['ema20'].iloc[-1] < df_1h['ema50'].iloc[-1] and df_4h['ema20'].iloc[-1] < df_4h['ema50'].iloc[-1]:
                self.market_regime['trend_direction'] = 'bearish'
            else:
                self.market_regime['trend_direction'] = 'neutral'
                
        except Exception as e:
            self.logger.error(f"Error analyzing trend: {e}")
    
    def _analyze_volatility(self, symbol):
        """
        Analyze market volatility for a symbol
        
        Args:
            symbol (str): Symbol to analyze
        """
        try:
            # Get historical data for the 1h timeframe
            klines_1h = self.client.get_historical_klines(symbol, '1h', limit=50)
            
            # Convert to DataFrame
            df = pd.DataFrame(klines_1h)
            
            # Calculate ATR
            df['high_low'] = df['high'] - df['low']
            df['high_close'] = np.abs(df['high'] - df['close'].shift())
            df['low_close'] = np.abs(df['low'] - df['close'].shift())
            df['tr'] = df[['high_low', 'high_close', 'low_close']].max(axis=1)
            df['atr'] = df['tr'].rolling(14).mean()
            
            # Calculate ATR as percentage of price
            df['atr_pct'] = df['atr'] / df['close'] * 100
            
            # Determine volatility regime
            current_atr_pct = df['atr_pct'].iloc[-1]
            historical_atr_pct = df['atr_pct'].mean()
            
            # Is volatility high compared to historical?
            self.market_regime['is_volatile'] = current_atr_pct > (historical_atr_pct * 1.5)
            
        except Exception as e:
            self.logger.error(f"Error analyzing volatility: {e}")
    
    def update_performance_metrics(self):
        """Update performance metrics for all strategies"""
        try:
            # Get recent strategy performance records
            now = datetime.utcnow()
            period_start = now - timedelta(days=30)
            
            strategy_records = StrategyPerformance.query.filter(
                StrategyPerformance.period_end >= period_start
            ).all()
            
            if not strategy_records:
                self.logger.info("No recent strategy performance records found")
                return
                
            # Group records by strategy
            strategies = {}
            for record in strategy_records:
                if record.strategy not in strategies:
                    strategies[record.strategy] = []
                    
                strategies[record.strategy].append(record.to_dict())
                
            # Calculate performance metrics for each strategy
            for strategy, records in strategies.items():
                records_df = pd.DataFrame(records)
                
                # Calculate average metrics
                win_rate = records_df['winning_trades'].sum() / (records_df['winning_trades'].sum() + records_df['losing_trades'].sum()) * 100
                profit_loss = records_df['profit_loss'].sum()
                sharpe_ratio = records_df['sharpe_ratio'].mean()
                max_drawdown = records_df['max_drawdown'].max()
                
                # Store metrics
                self.performance_metrics[strategy] = {
                    'win_rate': win_rate,
                    'profit_loss': profit_loss,
                    'sharpe_ratio': sharpe_ratio,
                    'max_drawdown': max_drawdown
                }
                
            self.logger.info(f"Updated performance metrics for {len(strategies)} strategies")
            
        except Exception as e:
            self.logger.error(f"Error updating performance metrics: {e}")
    
    def calculate_optimal_allocation(self):
        """
        Calculate optimal allocation percentages based on performance and market regime
        
        Returns:
            dict: Updated allocation percentages by strategy
        """
        try:
            # Update performance metrics and market regime
            self.update_performance_metrics()
            self.update_market_regime()
            
            # Get available strategies
            strategies = list(self.performance_metrics.keys())
            
            if not strategies:
                self.logger.warning("No strategy performance data available for allocation")
                return self.allocation
                
            # Initialize scores
            scores = {}
            
            for strategy in strategies:
                metrics = self.performance_metrics.get(strategy, {})
                
                # Skip strategies with no metrics
                if not metrics:
                    continue
                    
                # Calculate base score from performance metrics
                # Higher win rate, higher profit, higher Sharpe ratio, lower drawdown = better score
                win_rate_score = metrics.get('win_rate', 50) / 100
                profit_score = min(max(metrics.get('profit_loss', 0) / 100, 0), 1)  # Cap between 0 and 1
                sharpe_score = min(max(metrics.get('sharpe_ratio', 0) / 3, 0), 1)  # Cap between 0 and 1
                drawdown_penalty = min(metrics.get('max_drawdown', 0) / 1000, 1)  # Cap between 0 and 1
                
                # Base score is weighted average of metrics
                base_score = (win_rate_score * 0.3 + profit_score * 0.3 + sharpe_score * 0.3) * (1 - drawdown_penalty * 0.5)
                
                # Apply market regime adjustments
                # Momentum strategy performs better in trending markets
                if strategy == 'MomentumBreakoutStrategy':
                    if self.market_regime['is_trending']:
                        base_score *= 1.5
                    else:
                        base_score *= 0.7
                        
                # Future strategies would have their own adjustments here
                
                # Store final score
                scores[strategy] = max(base_score, 0.1)  # Ensure minimum score
            
            # Calculate allocation percentages based on scores
            total_score = sum(scores.values())
            
            if total_score > 0:
                new_allocation = {strategy: (score / total_score) * 100 for strategy, score in scores.items()}
            else:
                # Equal allocation if no scores
                new_allocation = {strategy: 100 / len(strategies) for strategy in strategies}
                
            # Apply circuit breaker for underperforming strategies
            for strategy, metrics in self.performance_metrics.items():
                # If a strategy has significant drawdown or negative return, limit allocation
                if metrics.get('max_drawdown', 0) > 150 or metrics.get('profit_loss', 0) < -100:
                    if strategy in new_allocation:
                        new_allocation[strategy] = min(new_allocation[strategy], 20)  # Cap at 20%
                        
                        # Redistribute excess allocation to other strategies
                        excess = new_allocation[strategy] - 20
                        if excess > 0:
                            new_allocation[strategy] = 20
                            
                            # Get other strategies
                            other_strategies = [s for s in new_allocation.keys() if s != strategy]
                            
                            if other_strategies:
                                # Proportional redistribution
                                other_total = sum(new_allocation[s] for s in other_strategies)
                                for s in other_strategies:
                                    new_allocation[s] += excess * (new_allocation[s] / other_total)
            
            # Round to 1 decimal place
            new_allocation = {strategy: round(alloc, 1) for strategy, alloc in new_allocation.items()}
            
            # Ensure total is 100%
            total = sum(new_allocation.values())
            if abs(total - 100) > 0.1:  # If not close to 100
                # Normalize to 100%
                factor = 100 / total
                new_allocation = {strategy: round(alloc * factor, 1) for strategy, alloc in new_allocation.items()}
                
                # Adjust largest allocation to make total exactly 100%
                total = sum(new_allocation.values())
                if total != 100:
                    largest_strategy = max(new_allocation, key=new_allocation.get)
                    new_allocation[largest_strategy] += 100 - total
            
            # Log allocation changes
            self.logger.info(f"Updated strategy allocation: {new_allocation}")
            
            # Update allocation
            self.allocation = new_allocation
            
            return new_allocation
            
        except Exception as e:
            self.logger.error(f"Error calculating optimal allocation: {e}")
            return self.allocation
    
    def get_allocation_for_strategy(self, strategy_name):
        """
        Get allocation percentage for a specific strategy
        
        Args:
            strategy_name (str): Strategy name
            
        Returns:
            float: Allocation percentage
        """
        return self.allocation.get(strategy_name, 0.0)
    
    def apply_allocation_to_position_size(self, strategy_name, base_position_size):
        """
        Apply allocation percentage to calculate actual position size
        
        Args:
            strategy_name (str): Strategy name
            base_position_size (float): Base position size
            
        Returns:
            float: Adjusted position size
        """
        allocation_pct = self.get_allocation_for_strategy(strategy_name)
        adjustment_factor = allocation_pct / 100
        
        # Apply circuit breaker for trending/volatile markets
        if self.market_regime['is_volatile']:
            # Reduce position size in high volatility
            adjustment_factor *= 0.7
        
        return base_position_size * adjustment_factor