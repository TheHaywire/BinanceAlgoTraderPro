import sqlite3
import os
import logging
import pandas as pd
from datetime import datetime
from config import DB_FILENAME

class Database:
    """
    Database class for storing trade history and performance data
    """
    
    def __init__(self, db_file=DB_FILENAME):
        """
        Initialize database connection
        
        Args:
            db_file (str): Database filename
        """
        self.logger = logging.getLogger(__name__)
        # Make sure we have a valid db_file path
        if not db_file or db_file.strip() == '':
            db_file = 'data/trading_history.db'  # Use a default path if DB_FILENAME is not set
        
        # Ensure the path is absolute
        if not os.path.isabs(db_file):
            # If it's a relative path, make it relative to the current directory
            db_file = os.path.join(os.getcwd(), db_file)
            
        self.logger.info(f"Using database file: {db_file}")
        self.db_file = db_file
        self.conn = None
        
        # Initialize database
        self._initialize_database()
    
    def _initialize_database(self):
        """Initialize database connection and tables"""
        try:
            # Ensure the directory exists
            db_dir = os.path.dirname(self.db_file)
            if db_dir:  # Only create directory if there's a path component
                os.makedirs(db_dir, exist_ok=True)
            
            # Connect to database
            self.conn = sqlite3.connect(self.db_file, check_same_thread=False)
            
            # Enable foreign keys
            self.conn.execute("PRAGMA foreign_keys = ON;")
            
            # Create trades table
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    strategy TEXT NOT NULL,
                    side TEXT NOT NULL,
                    entry_price REAL NOT NULL,
                    exit_price REAL,
                    quantity REAL NOT NULL,
                    profit_loss REAL,
                    profit_loss_pct REAL,
                    entry_time TEXT NOT NULL,
                    exit_time TEXT,
                    status TEXT NOT NULL,
                    stop_loss REAL,
                    take_profit REAL,
                    exit_reason TEXT
                )
            ''')
            
            # Create performance table
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS performance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT NOT NULL,
                    starting_balance REAL NOT NULL,
                    ending_balance REAL,
                    trades_count INTEGER,
                    win_count INTEGER,
                    loss_count INTEGER,
                    win_rate REAL,
                    profit_loss REAL,
                    profit_loss_pct REAL,
                    max_drawdown REAL
                )
            ''')
            
            self.conn.commit()
            self.logger.info("Database initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Error initializing database: {e}")
    
    def insert_trade(self, symbol, strategy, side, entry_price, quantity, stop_loss, take_profit):
        """
        Insert a new trade record
        
        Args:
            symbol (str): Trading symbol
            strategy (str): Strategy name
            side (str): Trade side (LONG/SHORT)
            entry_price (float): Entry price
            quantity (float): Trade quantity
            stop_loss (float): Stop loss price
            take_profit (float): Take profit price
            
        Returns:
            int: Trade ID
        """
        try:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            cursor = self.conn.execute('''
                INSERT INTO trades (
                    timestamp, symbol, strategy, side, entry_price, 
                    quantity, entry_time, status, stop_loss, take_profit
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                timestamp, symbol, strategy, side, entry_price, 
                quantity, timestamp, 'OPEN', stop_loss, take_profit
            ))
            
            self.conn.commit()
            trade_id = cursor.lastrowid
            self.logger.info(f"Inserted trade record: ID {trade_id}")
            
            return trade_id
            
        except Exception as e:
            self.logger.error(f"Error inserting trade: {e}")
            return -1
    
    def update_trade(self, trade_id, exit_price, exit_reason, status='CLOSED'):
        """
        Update trade with exit information
        
        Args:
            trade_id (int): Trade ID
            exit_price (float): Exit price
            exit_reason (str): Exit reason
            status (str): Trade status
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Get trade details
            trade = self.get_trade_by_id(trade_id)
            
            if not trade:
                self.logger.warning(f"Trade not found: ID {trade_id}")
                return False
                
            # Calculate profit/loss
            if trade['side'] == 'LONG':
                profit_loss = (exit_price - trade['entry_price']) * trade['quantity']
                profit_loss_pct = ((exit_price / trade['entry_price']) - 1) * 100
            else:  # SHORT
                profit_loss = (trade['entry_price'] - exit_price) * trade['quantity']
                profit_loss_pct = ((trade['entry_price'] / exit_price) - 1) * 100
                
            exit_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            # Update trade record
            self.conn.execute('''
                UPDATE trades
                SET exit_price = ?, exit_time = ?, status = ?, 
                    profit_loss = ?, profit_loss_pct = ?, exit_reason = ?
                WHERE id = ?
            ''', (
                exit_price, exit_time, status, 
                profit_loss, profit_loss_pct, exit_reason, trade_id
            ))
            
            self.conn.commit()
            self.logger.info(f"Updated trade: ID {trade_id}, P/L: {profit_loss_pct:.2f}%")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error updating trade: {e}")
            return False
    
    def get_trade_by_id(self, trade_id):
        """
        Get trade by ID
        
        Args:
            trade_id (int): Trade ID
            
        Returns:
            dict: Trade data or None if not found
        """
        try:
            cursor = self.conn.execute('''
                SELECT * FROM trades WHERE id = ?
            ''', (trade_id,))
            
            row = cursor.fetchone()
            
            if row:
                columns = [desc[0] for desc in cursor.description]
                return dict(zip(columns, row))
            else:
                return None
                
        except Exception as e:
            self.logger.error(f"Error retrieving trade: {e}")
            return None
    
    def get_open_trades(self, symbol=None):
        """
        Get all open trades
        
        Args:
            symbol (str, optional): Filter by symbol
            
        Returns:
            list: List of open trades
        """
        if not self.conn:
            self.logger.error("Database connection is not available")
            return []
            
        try:
            sql = "SELECT * FROM trades WHERE status = 'OPEN'"
            params = []
            
            if symbol:
                sql += " AND symbol = ?"
                params.append(symbol)
                
            cursor = self.conn.execute(sql, params)
            
            columns = [desc[0] for desc in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
            
        except Exception as e:
            self.logger.error(f"Error retrieving open trades: {e}")
            return []
    
    def get_trade_history(self, limit=100):
        """
        Get trade history
        
        Args:
            limit (int): Maximum number of trades to return
            
        Returns:
            pd.DataFrame: Trade history dataframe
        """
        if not self.conn:
            self.logger.error("Database connection is not available")
            return pd.DataFrame()
            
        try:
            sql = f'''
                SELECT * FROM trades 
                ORDER BY timestamp DESC 
                LIMIT {limit}
            '''
            
            return pd.read_sql_query(sql, self.conn)
            
        except Exception as e:
            self.logger.error(f"Error retrieving trade history: {e}")
            return pd.DataFrame()
    
    def update_daily_performance(self):
        """
        Update daily performance statistics
        
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.conn:
            self.logger.error("Database connection is not available")
            return False
            
        try:
            today = datetime.now().strftime('%Y-%m-%d')
            
            # Get today's trades
            today_trades = pd.read_sql_query('''
                SELECT * FROM trades 
                WHERE date(entry_time) = date('now')
                OR date(exit_time) = date('now')
            ''', self.conn)
            
            if today_trades.empty:
                return True  # No trades today
                
            # Get account info for today
            # This would need to be passed in from the client
            # For now we'll just use a placeholder
            starting_balance = 10000  # Placeholder
            ending_balance = 10000  # Placeholder
            
            # Calculate performance metrics
            closed_trades = today_trades[today_trades['status'] == 'CLOSED']
            trades_count = len(closed_trades)
            
            if trades_count > 0:
                win_count = len(closed_trades[closed_trades['profit_loss'] > 0])
                loss_count = len(closed_trades[closed_trades['profit_loss'] <= 0])
                win_rate = (win_count / trades_count) * 100 if trades_count > 0 else 0
                profit_loss = closed_trades['profit_loss'].sum()
                profit_loss_pct = profit_loss / starting_balance * 100
            else:
                win_count = 0
                loss_count = 0
                win_rate = 0
                profit_loss = 0
                profit_loss_pct = 0
                
            # Calculate max drawdown (simplified)
            max_drawdown = 0
            
            # Check if we already have a record for today
            cursor = self.conn.execute('''
                SELECT id FROM performance WHERE date = ?
            ''', (today,))
            
            existing_record = cursor.fetchone()
            
            if existing_record:
                # Update existing record
                self.conn.execute('''
                    UPDATE performance
                    SET ending_balance = ?, trades_count = ?, win_count = ?,
                        loss_count = ?, win_rate = ?, profit_loss = ?,
                        profit_loss_pct = ?, max_drawdown = ?
                    WHERE date = ?
                ''', (
                    ending_balance, trades_count, win_count,
                    loss_count, win_rate, profit_loss,
                    profit_loss_pct, max_drawdown, today
                ))
            else:
                # Insert new record
                self.conn.execute('''
                    INSERT INTO performance (
                        date, starting_balance, ending_balance, trades_count,
                        win_count, loss_count, win_rate, profit_loss,
                        profit_loss_pct, max_drawdown
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    today, starting_balance, ending_balance, trades_count,
                    win_count, loss_count, win_rate, profit_loss,
                    profit_loss_pct, max_drawdown
                ))
                
            self.conn.commit()
            return True
            
        except Exception as e:
            self.logger.error(f"Error updating performance: {e}")
            return False
    
    def get_performance_summary(self, days=30):
        """
        Get performance summary
        
        Args:
            days (int): Number of days to include
            
        Returns:
            pd.DataFrame: Performance summary
        """
        if not self.conn:
            self.logger.error("Database connection is not available")
            return pd.DataFrame()
            
        try:
            sql = f'''
                SELECT * FROM performance
                ORDER BY date DESC
                LIMIT {days}
            '''
            
            return pd.read_sql_query(sql, self.conn)
            
        except Exception as e:
            self.logger.error(f"Error retrieving performance summary: {e}")
            return pd.DataFrame()
            
    def close(self):
        """Close database connection"""
        if self.conn:
            try:
                self.conn.close()
                self.logger.info("Database connection closed")
            except Exception as e:
                self.logger.error(f"Error closing database connection: {e}")
                
    def __del__(self):
        """Destructor to ensure database connection is closed"""
        self.close()
