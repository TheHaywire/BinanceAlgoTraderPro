import os
import logging
import threading
import time
from dotenv import load_dotenv
from flask import Flask
from api.binance_client import BinanceClient
from api.websocket_manager import WebSocketManager
from strategies.momentum_breakout import MomentumBreakoutStrategy
from risk_management.risk_manager import RiskManager
from risk_management.position_sizer import PositionSizer
from risk_management.advanced_risk_manager import AdvancedRiskManager
from performance.performance_monitor import PerformanceMonitor
from performance.strategy_allocator import StrategyAllocator
from utils.logger import setup_logger
from models import db, Trade, DailyPerformance, StrategyPerformance, MarketData, SystemMetrics
import psycopg2

# Load environment variables
load_dotenv()

# Set up logging
logger = setup_logger()

# Create the Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY', 'dev-key-for-testing')

# Configure database
db_url = os.environ.get('DATABASE_URL')
if db_url and db_url.startswith("postgres://"):
    db_url = db_url.replace("postgres://", "postgresql://", 1)
app.config['SQLALCHEMY_DATABASE_URI'] = db_url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_recycle': 300,
    'pool_pre_ping': True
}

# Initialize database with app
db.init_app(app)

# Global variables to store bot state
trading_bot = None
websocket_manager = None
client = None
risk_manager = None
advanced_risk_manager = None
performance_monitor = None
strategy_allocator = None
trade_monitor = None
opportunity_detector = None
alert_system = None

# Bot state for dashboard
bot_state = {
    "running": False,
    "connected": False,
    "account_balance": 0,
    "active_trades": 0,
    "total_trades": 0,
    "win_rate": 0,
    "daily_pnl": 0,
    "strategy": "Momentum Breakout",
    "symbols": ["BTCUSDT"],
    "last_update": None,
    "trading_allowed": True,
    "current_drawdown": 0.0,
    "max_drawdown_threshold": 10.0,
    "strategy_allocation": {}
}

def initialize_trading_bot():
    """Initialize the trading bot components with API credentials"""
    global trading_bot, websocket_manager, client, risk_manager, advanced_risk_manager
    global performance_monitor, strategy_allocator, trade_monitor, opportunity_detector, alert_system
    
    try:
        # Check for API credentials
        api_key = os.environ.get("BINANCE_API_KEY")
        api_secret = os.environ.get("BINANCE_API_SECRET")
        
        if not api_key or not api_secret:
            logger.error("API credentials not found. Please set BINANCE_API_KEY and BINANCE_API_SECRET environment variables.")
            return
        
        # Initialize Binance client
        client = BinanceClient(api_key, api_secret, testnet=True)
        
        # Test the connection
        account_info = client.get_account_info()
        logger.info(f"Connected to Binance Testnet")
        logger.info(f"Account balance: {account_info.get('totalWalletBalance', 'unknown')} USDT")
        
        # Initialize standard risk manager
        risk_manager = RiskManager(client, max_position_size_pct=5.0, max_loss_pct=2.0)
        
        # Initialize position sizer
        position_sizer = PositionSizer(client, default_risk_pct=1.0, max_position_pct=5.0)
        
        # Create placeholder for advanced components that need app context
        advanced_risk_manager = None
        performance_monitor = None
        strategy_allocator = None
        trade_monitor = None
        opportunity_detector = None
        alert_system = None
        
        # Initialize advanced components that require database access
        # This needs to be done after app is created and within app context
        if app:
            with app.app_context():
                try:
                    # Initialize advanced risk manager
                    advanced_risk_manager = AdvancedRiskManager(
                        client, 
                        base_risk_pct=1.0, 
                        max_position_pct=5.0, 
                        max_drawdown_pct=10.0
                    )
                    
                    # Initialize performance monitor
                    performance_monitor = PerformanceMonitor(client)
                    
                    # Initialize strategy allocator
                    strategy_allocator = StrategyAllocator(client)
                    
                    # Initialize trade monitor
                    from monitoring.trade_monitor import TradeMonitor
                    trade_monitor = TradeMonitor(client)
                    
                    # Initialize opportunity detector
                    from monitoring.opportunity_detector import OpportunityDetector
                    opportunity_detector = OpportunityDetector(client)
                    
                    # Initialize alert system
                    from monitoring.alert_system import AlertSystem
                    alert_system = AlertSystem()
                except Exception as e:
                    logger.error(f"Error initializing advanced components: {e}")
        
        # Create trading strategy - starting with BTCUSDT Momentum Breakout
        trading_bot = MomentumBreakoutStrategy(
            client=client,
            risk_manager=risk_manager,
            symbol="BTCUSDT",
            interval="15m",
            timeframes=["5m", "15m", "1h", "4h"]
        )
        
        # Initialize WebSocket manager with the strategy
        websocket_manager = WebSocketManager(client, [trading_bot])
        
        # Start websocket in a separate thread
        websocket_thread = threading.Thread(target=websocket_manager.start)
        websocket_thread.daemon = True  # Thread will exit when main program exits
        websocket_thread.start()
        
        # Only start performance monitoring thread if components are initialized
        if performance_monitor and strategy_allocator:
            performance_thread = threading.Thread(target=performance_monitoring_task, 
                                                args=(performance_monitor, advanced_risk_manager, strategy_allocator))
            performance_thread.daemon = True
            performance_thread.start()
            logger.info("Performance monitoring thread started")
        else:
            logger.warning("Performance monitoring components not fully initialized. Thread not started.")
        
        logger.info(f"Trading bot initialized with strategy: {trading_bot.__class__.__name__}")
        
        # Return the initialized components
        return {
            "client": client,
            "risk_manager": risk_manager,
            "advanced_risk_manager": advanced_risk_manager,
            "performance_monitor": performance_monitor,
            "strategy_allocator": strategy_allocator,
            "trading_bot": trading_bot,
            "websocket_manager": websocket_manager,
            "trade_monitor": trade_monitor,
            "opportunity_detector": opportunity_detector,
            "alert_system": alert_system
        }
        
    except Exception as e:
        logger.error(f"Error initializing trading bot: {e}")
        return None

def performance_monitoring_task(performance_monitor, risk_manager, strategy_allocator):
    """Background task for monitoring performance and updating risk parameters"""
    # Wait a bit before starting to ensure application is fully initialized
    time.sleep(10)
    
    while True:
        try:
            # Skip if components are not initialized
            if not performance_monitor or not strategy_allocator:
                logger.warning("Performance monitoring components not initialized. Retrying in 60 seconds.")
                time.sleep(60)
                continue
                
            # Need app context for database operations
            with app.app_context():
                # Update performance metrics
                performance_monitor.update_performance_metrics()
                
                # Log system metrics
                performance_monitor.log_system_metrics()
                
                # Calculate optimal strategy allocation
                allocation = strategy_allocator.calculate_optimal_allocation()
                
                # Update bot state with allocation
                bot_state["strategy_allocation"] = allocation
                
                # Update risk status if available
                if risk_manager:
                    try:
                        risk_status = risk_manager.get_trade_status()
                        bot_state["trading_allowed"] = risk_status["trading_allowed"]
                        bot_state["current_drawdown"] = risk_status["current_drawdown_pct"]
                    except Exception as e:
                        logger.error(f"Error updating risk status: {e}")
                
            # Log success
            logger.info("Performance monitoring task completed successfully")
                
            # Sleep for 15 minutes before next update
            time.sleep(15 * 60)
            
        except Exception as e:
            logger.error(f"Error in performance monitoring task: {e}")
            time.sleep(60)  # Sleep for 1 minute on error

# Create database tables within app context
with app.app_context():
    try:
        # Create all database tables
        db.create_all()
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error creating database tables: {e}")

# Try to initialize trading bot on startup
trading_components = initialize_trading_bot()

# Update the bot's state if trading components were initialized
if trading_components:
    # Check if we can get account info
    try:
        account_info = trading_components["client"].get_account_info()
        bot_state["account_balance"] = float(account_info.get('totalWalletBalance', 0))
        bot_state["connected"] = True
        bot_state["running"] = True
        
        # Get active trades count from database
        with app.app_context():
            bot_state["active_trades"] = Trade.query.filter_by(status='OPEN').count()
            bot_state["total_trades"] = Trade.query.count()
            
            # Calculate win rate if there are closed trades
            closed_trades = Trade.query.filter_by(status='CLOSED').count()
            if closed_trades > 0:
                winning_trades = Trade.query.filter(
                    Trade.status == 'CLOSED', 
                    Trade.profit_loss_percent > 0
                ).count()
                bot_state["win_rate"] = (winning_trades / closed_trades) * 100
                
        # Get risk status
        if trading_components.get("advanced_risk_manager"):
            risk_status = trading_components["advanced_risk_manager"].get_trade_status()
            bot_state["trading_allowed"] = risk_status["trading_allowed"]
            bot_state["current_drawdown"] = risk_status["current_drawdown_pct"]
            
        # Get strategy allocation
        if trading_components.get("strategy_allocator"):
            allocation = trading_components["strategy_allocator"].allocation
            bot_state["strategy_allocation"] = allocation
                
    except Exception as e:
        logger.error(f"Error updating bot state: {e}")

# Import routes after app is created to avoid circular imports
from dashboard.routes import init_routes
init_routes(app, bot_state, trading_components)

# This is the main Flask application for gunicorn to use
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
