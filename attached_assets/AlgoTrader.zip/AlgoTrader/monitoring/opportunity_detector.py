"""
Advanced Opportunity Detection Engine for identifying and evaluating trading opportunities
"""

import logging
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from models import db, MarketData

class OpportunityDetector:
    """
    Advanced system for detecting and scoring trading opportunities across markets
    """
    
    def __init__(self, client):
        """
        Initialize the opportunity detector
        
        Args:
            client (BinanceClient): Binance client instance
        """
        self.client = client
        self.logger = logging.getLogger(__name__)
        
        # Store detected opportunities
        self.opportunities = []
        
        # Opportunity scoring weights
        self.scoring_weights = {
            'pattern_strength': 0.3,
            'volume_confirmation': 0.2,
            'trend_alignment': 0.2,
            'volatility': 0.15,
            'liquidity': 0.15
        }
        
        # Supported patterns for detection
        self.supported_patterns = [
            'breakout', 
            'support_resistance',
            'momentum_divergence',
            'trend_reversal',
            'volume_spike',
            'funding_rate_extreme'
        ]
        
        # Market anomalies we track
        self.tracked_anomalies = [
            'price_outlier',
            'volume_outlier',
            'volatility_spike',
            'correlation_breakdown',
            'funding_rate_anomaly'
        ]
        
        # Watchlist for monitoring specific opportunities
        self.watchlist = []
        
    def scan_all_markets(self, symbols=None, timeframes=['15m', '1h', '4h']):
        """
        Scan all markets for trading opportunities
        
        Args:
            symbols (list, optional): List of symbols to scan
            timeframes (list, optional): List of timeframes to analyze
            
        Returns:
            list: Detected opportunities
        """
        try:
            # Get symbols to scan
            if symbols is None:
                all_symbols = self.client.get_exchange_info()
                symbols = [s['symbol'] for s in all_symbols['symbols'] if s['symbol'].endswith('USDT')]
                # Limit to top 20 by volume for now
                symbols = symbols[:20]
            
            self.logger.info(f"Scanning {len(symbols)} markets for opportunities on {timeframes} timeframes")
            
            # Reset opportunities
            self.opportunities = []
            
            # Scan each symbol
            for symbol in symbols:
                for timeframe in timeframes:
                    self._scan_single_market(symbol, timeframe)
            
            # Sort opportunities by score
            self.opportunities.sort(key=lambda x: x['score'], reverse=True)
            
            self.logger.info(f"Detected {len(self.opportunities)} trading opportunities")
            return self.opportunities
            
        except Exception as e:
            self.logger.error(f"Error scanning markets: {e}")
            return []
    
    def _scan_single_market(self, symbol, timeframe):
        """
        Scan a single market for trading opportunities
        
        Args:
            symbol (str): Trading symbol
            timeframe (str): Timeframe to analyze
        """
        try:
            # Get historical data
            klines = self.client.get_historical_klines(symbol, timeframe, limit=100)
            if not klines:
                return
                
            # Convert to dataframe
            df = pd.DataFrame(klines)
            
            # Apply pattern recognition
            patterns = self._detect_patterns(df, symbol, timeframe)
            
            # Apply anomaly detection
            anomalies = self._detect_anomalies(df, symbol, timeframe)
            
            # Apply momentum analysis
            momentum_signals = self._analyze_momentum(df, symbol, timeframe)
            
            # Combine all detected opportunities
            all_signals = patterns + anomalies + momentum_signals
            
            # Add to opportunities list
            self.opportunities.extend(all_signals)
            
        except Exception as e:
            self.logger.error(f"Error scanning {symbol} on {timeframe}: {e}")
    
    def _detect_patterns(self, df, symbol, timeframe):
        """
        Detect chart patterns
        
        Args:
            df (DataFrame): Price data
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            list: Detected patterns
        """
        patterns = []
        
        try:
            # Detect breakouts
            breakout = self._detect_breakout(df, symbol, timeframe)
            if breakout:
                patterns.append(breakout)
                
            # Detect support/resistance interactions
            sr_pattern = self._detect_support_resistance(df, symbol, timeframe)
            if sr_pattern:
                patterns.append(sr_pattern)
                
            # Detect divergences
            divergence = self._detect_divergence(df, symbol, timeframe)
            if divergence:
                patterns.append(divergence)
                
            return patterns
            
        except Exception as e:
            self.logger.error(f"Error detecting patterns for {symbol} on {timeframe}: {e}")
            return []
    
    def _detect_breakout(self, df, symbol, timeframe):
        """
        Detect price breakouts
        
        Args:
            df (DataFrame): Price data
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            dict: Breakout opportunity if detected, None otherwise
        """
        try:
            # Simple breakout detection - price breaking above resistance
            # Get last 20 candles for range calculation
            recent_df = df.tail(20)
            
            # Calculate range
            high = recent_df['high'].max()
            low = recent_df['low'].min()
            
            # Current price
            current_price = df['close'].iloc[-1]
            prev_price = df['close'].iloc[-2]
            
            # Calculate upper range boundary (resistance)
            upper_range = high - (high - low) * 0.2
            
            # Check for breakout
            if prev_price < upper_range and current_price >= upper_range:
                # Calculate confirmation metrics
                volume_increase = df['volume'].iloc[-1] / df['volume'].iloc[-5:-1].mean()
                price_momentum = df['close'].pct_change(5).iloc[-1] * 100
                
                # Calculate breakout strength score (0-1)
                breakout_strength = min((current_price - upper_range) / (high - low) * 2, 1.0)
                
                # Score the opportunity (0-100)
                score = self._calculate_opportunity_score({
                    'pattern_strength': breakout_strength,
                    'volume_confirmation': min(volume_increase / 2, 1.0),
                    'trend_alignment': min(price_momentum / 5, 1.0) if price_momentum > 0 else 0,
                    'volatility': min(df['high'].pct_change().std() * 10, 1.0),
                    'liquidity': 0.8  # Placeholder - would use actual liquidity metrics
                })
                
                return {
                    'type': 'pattern',
                    'pattern': 'breakout',
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'direction': 'bullish',
                    'price': current_price,
                    'score': score,
                    'detection_time': datetime.utcnow().isoformat(),
                    'metrics': {
                        'breakout_level': upper_range,
                        'range_high': high,
                        'range_low': low,
                        'volume_increase': volume_increase,
                        'price_momentum': price_momentum
                    }
                }
                
            return None
            
        except Exception as e:
            self.logger.error(f"Error detecting breakout for {symbol} on {timeframe}: {e}")
            return None
    
    def _detect_support_resistance(self, df, symbol, timeframe):
        """
        Detect support/resistance interactions
        
        Args:
            df (DataFrame): Price data
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            dict: Support/resistance opportunity if detected, None otherwise
        """
        try:
            # Simple implementation - would use more sophisticated methods in production
            # Find significant price levels over the last 50 candles
            price_levels = []
            
            # Use recent lows for support levels
            for i in range(5, len(df) - 5):
                # Check if this candle's low is a local minimum
                if (df['low'].iloc[i] <= df['low'].iloc[i-5:i].min() and
                    df['low'].iloc[i] <= df['low'].iloc[i+1:i+6].min()):
                    price_levels.append({
                        'type': 'support',
                        'price': df['low'].iloc[i],
                        'strength': 1  # Simple implementation
                    })
            
            # Use recent highs for resistance levels
            for i in range(5, len(df) - 5):
                # Check if this candle's high is a local maximum
                if (df['high'].iloc[i] >= df['high'].iloc[i-5:i].max() and
                    df['high'].iloc[i] >= df['high'].iloc[i+1:i+6].max()):
                    price_levels.append({
                        'type': 'resistance',
                        'price': df['high'].iloc[i],
                        'strength': 1  # Simple implementation
                    })
            
            # Check if current price is near any significant level
            current_price = df['close'].iloc[-1]
            
            for level in price_levels:
                # Calculate distance to level as percentage
                distance_pct = abs(current_price - level['price']) / current_price * 100
                
                # If price is very close to a level (within 0.5%)
                if distance_pct < 0.5:
                    # Determine if price is respecting or breaking the level
                    if (level['type'] == 'support' and df['close'].iloc[-1] > df['close'].iloc[-2]) or \
                       (level['type'] == 'resistance' and df['close'].iloc[-1] < df['close'].iloc[-2]):
                        interaction = 'respecting'
                    else:
                        interaction = 'breaking'
                    
                    # Score the opportunity
                    pattern_strength = min(1.0, 0.5 / max(0.1, distance_pct))
                    volume_increase = df['volume'].iloc[-1] / df['volume'].iloc[-5:-1].mean()
                    
                    score = self._calculate_opportunity_score({
                        'pattern_strength': pattern_strength,
                        'volume_confirmation': min(volume_increase / 2, 1.0),
                        'trend_alignment': 0.7,  # Placeholder
                        'volatility': min(df['high'].pct_change().std() * 10, 1.0),
                        'liquidity': 0.8  # Placeholder
                    })
                    
                    return {
                        'type': 'pattern',
                        'pattern': 'support_resistance',
                        'symbol': symbol,
                        'timeframe': timeframe,
                        'direction': 'bullish' if level['type'] == 'support' else 'bearish',
                        'price': current_price,
                        'score': score,
                        'detection_time': datetime.utcnow().isoformat(),
                        'metrics': {
                            'level_type': level['type'],
                            'level_price': level['price'],
                            'interaction': interaction,
                            'distance_pct': distance_pct
                        }
                    }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error detecting support/resistance for {symbol} on {timeframe}: {e}")
            return None
    
    def _detect_divergence(self, df, symbol, timeframe):
        """
        Detect divergences between price and indicators
        
        Args:
            df (DataFrame): Price data
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            dict: Divergence opportunity if detected, None otherwise
        """
        try:
            # Calculate RSI
            delta = df['close'].diff()
            gain = delta.where(delta > 0, 0)
            loss = -delta.where(delta < 0, 0)
            avg_gain = gain.rolling(window=14).mean()
            avg_loss = loss.rolling(window=14).mean()
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            
            # Find recent price highs/lows
            price_window = 10
            
            # Calculate if we have a lower high in price but higher high in RSI (bearish divergence)
            if (df['close'].iloc[-1] < df['close'].iloc[-price_window:-1].max() and
                rsi.iloc[-1] > rsi.iloc[-price_window:-1].max()):
                
                score = self._calculate_opportunity_score({
                    'pattern_strength': 0.8,  # Strong pattern
                    'volume_confirmation': 0.5,  # Neutral
                    'trend_alignment': 0.7,  # Fairly aligned
                    'volatility': min(df['high'].pct_change().std() * 10, 1.0),
                    'liquidity': 0.8  # Placeholder
                })
                
                return {
                    'type': 'pattern',
                    'pattern': 'momentum_divergence',
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'direction': 'bearish',
                    'price': df['close'].iloc[-1],
                    'score': score,
                    'detection_time': datetime.utcnow().isoformat(),
                    'metrics': {
                        'divergence_type': 'bearish',
                        'price_action': 'lower high',
                        'indicator': 'RSI',
                        'indicator_action': 'higher high',
                        'rsi_value': rsi.iloc[-1]
                    }
                }
            
            # Calculate if we have a higher low in price but lower low in RSI (bullish divergence)
            if (df['close'].iloc[-1] > df['close'].iloc[-price_window:-1].min() and
                rsi.iloc[-1] < rsi.iloc[-price_window:-1].min()):
                
                score = self._calculate_opportunity_score({
                    'pattern_strength': 0.8,  # Strong pattern
                    'volume_confirmation': 0.5,  # Neutral
                    'trend_alignment': 0.7,  # Fairly aligned
                    'volatility': min(df['high'].pct_change().std() * 10, 1.0),
                    'liquidity': 0.8  # Placeholder
                })
                
                return {
                    'type': 'pattern',
                    'pattern': 'momentum_divergence',
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'direction': 'bullish',
                    'price': df['close'].iloc[-1],
                    'score': score,
                    'detection_time': datetime.utcnow().isoformat(),
                    'metrics': {
                        'divergence_type': 'bullish',
                        'price_action': 'higher low',
                        'indicator': 'RSI',
                        'indicator_action': 'lower low',
                        'rsi_value': rsi.iloc[-1]
                    }
                }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error detecting divergence for {symbol} on {timeframe}: {e}")
            return None
    
    def _detect_anomalies(self, df, symbol, timeframe):
        """
        Detect market anomalies
        
        Args:
            df (DataFrame): Price data
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            list: Detected anomalies
        """
        anomalies = []
        
        try:
            # Detect price outliers
            price_anomaly = self._detect_price_anomaly(df, symbol, timeframe)
            if price_anomaly:
                anomalies.append(price_anomaly)
                
            # Detect volume outliers
            volume_anomaly = self._detect_volume_anomaly(df, symbol, timeframe)
            if volume_anomaly:
                anomalies.append(volume_anomaly)
                
            # Detect funding rate anomalies (futures only)
            if 'USDT' in symbol:  # Simple check for futures
                funding_anomaly = self._detect_funding_rate_anomaly(symbol, timeframe)
                if funding_anomaly:
                    anomalies.append(funding_anomaly)
            
            return anomalies
            
        except Exception as e:
            self.logger.error(f"Error detecting anomalies for {symbol} on {timeframe}: {e}")
            return []
    
    def _detect_price_anomaly(self, df, symbol, timeframe):
        """
        Detect price outliers
        
        Args:
            df (DataFrame): Price data
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            dict: Price anomaly if detected, None otherwise
        """
        try:
            # Calculate Z-score for price changes
            returns = df['close'].pct_change()
            mean_return = returns.mean()
            std_return = returns.std()
            latest_return = returns.iloc[-1]
            
            # Z-score
            z_score = (latest_return - mean_return) / std_return if std_return > 0 else 0
            
            # Check for significant outlier (Z-score > 3)
            if abs(z_score) > 3:
                direction = 'bullish' if z_score > 0 else 'bearish'
                
                # Calculate anomaly strength (0-1)
                anomaly_strength = min(abs(z_score) / 5, 1.0)
                
                # Score the opportunity
                score = self._calculate_opportunity_score({
                    'pattern_strength': anomaly_strength,
                    'volume_confirmation': min(df['volume'].iloc[-1] / df['volume'].iloc[-5:-1].mean() / 2, 1.0),
                    'trend_alignment': 0.5,  # Neutral for anomalies
                    'volatility': min(std_return * 100, 1.0),
                    'liquidity': 0.8  # Placeholder
                })
                
                return {
                    'type': 'anomaly',
                    'anomaly': 'price_outlier',
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'direction': direction,
                    'price': df['close'].iloc[-1],
                    'score': score,
                    'detection_time': datetime.utcnow().isoformat(),
                    'metrics': {
                        'z_score': z_score,
                        'return': latest_return * 100,  # as percentage
                        'average_return': mean_return * 100,  # as percentage
                        'return_volatility': std_return * 100  # as percentage
                    }
                }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error detecting price anomaly for {symbol} on {timeframe}: {e}")
            return None
    
    def _detect_volume_anomaly(self, df, symbol, timeframe):
        """
        Detect volume outliers
        
        Args:
            df (DataFrame): Price data
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            dict: Volume anomaly if detected, None otherwise
        """
        try:
            # Calculate average volume over last 20 periods
            avg_volume = df['volume'].iloc[-20:-1].mean()
            latest_volume = df['volume'].iloc[-1]
            
            # Check for volume spike (3x average)
            if latest_volume > avg_volume * 3:
                # Calculate if price is moving up or down with the volume
                price_direction = 'bullish' if df['close'].iloc[-1] > df['open'].iloc[-1] else 'bearish'
                
                # Calculate anomaly strength (0-1)
                volume_ratio = latest_volume / avg_volume
                anomaly_strength = min(volume_ratio / 5, 1.0)
                
                # Score the opportunity
                score = self._calculate_opportunity_score({
                    'pattern_strength': anomaly_strength,
                    'volume_confirmation': 1.0,  # Max for volume anomaly
                    'trend_alignment': 0.7 if df['close'].iloc[-5:].is_monotonic else 0.3,
                    'volatility': min(df['high'].pct_change().std() * 10, 1.0),
                    'liquidity': 0.8  # Placeholder
                })
                
                return {
                    'type': 'anomaly',
                    'anomaly': 'volume_outlier',
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'direction': price_direction,
                    'price': df['close'].iloc[-1],
                    'score': score,
                    'detection_time': datetime.utcnow().isoformat(),
                    'metrics': {
                        'volume_ratio': volume_ratio,
                        'volume': latest_volume,
                        'average_volume': avg_volume,
                        'price_change': (df['close'].iloc[-1] - df['open'].iloc[-1]) / df['open'].iloc[-1] * 100
                    }
                }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error detecting volume anomaly for {symbol} on {timeframe}: {e}")
            return None
    
    def _detect_funding_rate_anomaly(self, symbol, timeframe):
        """
        Detect funding rate anomalies
        
        Args:
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            dict: Funding rate anomaly if detected, None otherwise
        """
        try:
            # Get current funding rate
            funding_info = self.client.get_funding_rate(symbol)
            current_rate = float(funding_info.get('lastFundingRate', 0.0)) * 100  # Convert to percentage
            
            # Check for extreme funding rate (absolute value > 0.1%)
            if abs(current_rate) > 0.1:
                direction = 'bearish' if current_rate > 0 else 'bullish'
                
                # Calculate anomaly strength (0-1)
                # Normalize: 0.1% -> 0.5, 0.2% -> 1.0
                anomaly_strength = min(abs(current_rate) / 0.2, 1.0)
                
                # Score the opportunity
                score = self._calculate_opportunity_score({
                    'pattern_strength': anomaly_strength,
                    'volume_confirmation': 0.5,  # Neutral
                    'trend_alignment': 0.6,  # Slightly positive
                    'volatility': 0.5,  # Neutral
                    'liquidity': 0.8  # Placeholder
                })
                
                return {
                    'type': 'anomaly',
                    'anomaly': 'funding_rate_extreme',
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'direction': direction,
                    'price': float(funding_info.get('markPrice', 0.0)),
                    'score': score,
                    'detection_time': datetime.utcnow().isoformat(),
                    'metrics': {
                        'funding_rate': current_rate,
                        'next_funding_time': funding_info.get('nextFundingTime', 0),
                        'mark_price': funding_info.get('markPrice', 0.0),
                        'index_price': funding_info.get('indexPrice', 0.0)
                    }
                }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error detecting funding rate anomaly for {symbol}: {e}")
            return None
    
    def _analyze_momentum(self, df, symbol, timeframe):
        """
        Analyze momentum and trends
        
        Args:
            df (DataFrame): Price data
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            list: Momentum signals
        """
        signals = []
        
        try:
            # Detect trend strength
            trend_signal = self._detect_trend_strength(df, symbol, timeframe)
            if trend_signal:
                signals.append(trend_signal)
                
            # Detect momentum acceleration
            momentum_signal = self._detect_momentum_acceleration(df, symbol, timeframe)
            if momentum_signal:
                signals.append(momentum_signal)
            
            return signals
            
        except Exception as e:
            self.logger.error(f"Error analyzing momentum for {symbol} on {timeframe}: {e}")
            return []
    
    def _detect_trend_strength(self, df, symbol, timeframe):
        """
        Detect trend strength
        
        Args:
            df (DataFrame): Price data
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            dict: Trend signal if strong trend detected, None otherwise
        """
        try:
            # Calculate EMAs
            df['ema20'] = df['close'].ewm(span=20).mean()
            df['ema50'] = df['close'].ewm(span=50).mean()
            
            # Determine trend direction
            trend_direction = 'bullish' if df['ema20'].iloc[-1] > df['ema50'].iloc[-1] else 'bearish'
            
            # Calculate trend strength
            ema_distance = abs(df['ema20'].iloc[-1] - df['ema50'].iloc[-1]) / df['close'].iloc[-1] * 100
            
            # Consider trend strong if EMAs are far apart (>1% distance)
            if ema_distance > 1.0:
                # Calculate additional trend metrics
                price_above_ema = df['close'].iloc[-1] > df['ema20'].iloc[-1]
                ema_slope = (df['ema20'].iloc[-1] - df['ema20'].iloc[-5]) / df['ema20'].iloc[-5] * 100
                
                # Only consider strong trend if price is above EMA20 for bullish, below for bearish
                if (trend_direction == 'bullish' and price_above_ema) or (trend_direction == 'bearish' and not price_above_ema):
                    # Calculate trend strength score (0-1)
                    trend_strength = min(ema_distance / 2, 1.0)
                    
                    # Score the opportunity
                    score = self._calculate_opportunity_score({
                        'pattern_strength': trend_strength,
                        'volume_confirmation': min(df['volume'].iloc[-1] / df['volume'].iloc[-20:].mean() / 2, 1.0),
                        'trend_alignment': 1.0,  # Max for trend signal
                        'volatility': min(df['high'].pct_change().std() * 10, 1.0),
                        'liquidity': 0.8  # Placeholder
                    })
                    
                    return {
                        'type': 'momentum',
                        'momentum': 'strong_trend',
                        'symbol': symbol,
                        'timeframe': timeframe,
                        'direction': trend_direction,
                        'price': df['close'].iloc[-1],
                        'score': score,
                        'detection_time': datetime.utcnow().isoformat(),
                        'metrics': {
                            'ema_distance_pct': ema_distance,
                            'ema20': df['ema20'].iloc[-1],
                            'ema50': df['ema50'].iloc[-1],
                            'ema_slope': ema_slope,
                            'price_position': 'above_ema' if price_above_ema else 'below_ema'
                        }
                    }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error detecting trend strength for {symbol} on {timeframe}: {e}")
            return None
    
    def _detect_momentum_acceleration(self, df, symbol, timeframe):
        """
        Detect momentum acceleration
        
        Args:
            df (DataFrame): Price data
            symbol (str): Trading symbol
            timeframe (str): Timeframe
            
        Returns:
            dict: Momentum signal if acceleration detected, None otherwise
        """
        try:
            # Calculate rate of change for different lookback periods
            df['roc1'] = df['close'].pct_change(1) * 100
            df['roc5'] = df['close'].pct_change(5) * 100
            df['roc20'] = df['close'].pct_change(20) * 100
            
            # Detect momentum acceleration when shorter ROC is greater than longer ROC
            accelerating_momentum = df['roc1'].iloc[-1] > df['roc5'].iloc[-1] > df['roc20'].iloc[-1]
            decelerating_momentum = df['roc1'].iloc[-1] < df['roc5'].iloc[-1] < df['roc20'].iloc[-1]
            
            if accelerating_momentum or decelerating_momentum:
                direction = 'bullish' if accelerating_momentum else 'bearish'
                
                # Calculate momentum strength
                momentum_strength = abs(df['roc1'].iloc[-1] - df['roc20'].iloc[-1]) / 5
                momentum_strength = min(momentum_strength, 1.0)
                
                # Score the opportunity
                score = self._calculate_opportunity_score({
                    'pattern_strength': momentum_strength,
                    'volume_confirmation': min(df['volume'].iloc[-1] / df['volume'].iloc[-5:-1].mean() / 2, 1.0),
                    'trend_alignment': 0.8,  # High for momentum signal
                    'volatility': min(df['high'].pct_change().std() * 10, 1.0),
                    'liquidity': 0.8  # Placeholder
                })
                
                return {
                    'type': 'momentum',
                    'momentum': 'acceleration',
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'direction': direction,
                    'price': df['close'].iloc[-1],
                    'score': score,
                    'detection_time': datetime.utcnow().isoformat(),
                    'metrics': {
                        'roc1': df['roc1'].iloc[-1],
                        'roc5': df['roc5'].iloc[-1],
                        'roc20': df['roc20'].iloc[-1],
                        'acceleration_type': 'accelerating' if accelerating_momentum else 'decelerating'
                    }
                }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error detecting momentum acceleration for {symbol} on {timeframe}: {e}")
            return None
    
    def _calculate_opportunity_score(self, factor_scores):
        """
        Calculate weighted opportunity score
        
        Args:
            factor_scores (dict): Factor scores (0-1 scale)
            
        Returns:
            float: Weighted score (0-100 scale)
        """
        try:
            score = 0
            
            for factor, weight in self.scoring_weights.items():
                if factor in factor_scores:
                    score += factor_scores[factor] * weight
            
            # Convert to 0-100 scale
            return round(score * 100, 1)
            
        except Exception as e:
            self.logger.error(f"Error calculating opportunity score: {e}")
            return 0
    
    def add_to_watchlist(self, opportunity_id, notes=None):
        """
        Add opportunity to watchlist
        
        Args:
            opportunity_id (str): Opportunity ID
            notes (str, optional): Notes about the opportunity
            
        Returns:
            dict: Watchlist entry
        """
        try:
            # Find the opportunity
            opportunity = next((o for o in self.opportunities if o.get('id') == opportunity_id), None)
            
            if not opportunity:
                return {'error': 'Opportunity not found'}
            
            # Create watchlist entry
            watchlist_entry = {
                'id': opportunity_id,
                'symbol': opportunity['symbol'],
                'type': opportunity['type'],
                'direction': opportunity['direction'],
                'price': opportunity['price'],
                'score': opportunity['score'],
                'added_time': datetime.utcnow().isoformat(),
                'notes': notes
            }
            
            # Add to watchlist
            self.watchlist.append(watchlist_entry)
            
            self.logger.info(f"Added {opportunity['symbol']} to watchlist")
            return watchlist_entry
            
        except Exception as e:
            self.logger.error(f"Error adding to watchlist: {e}")
            return {'error': str(e)}
    
    def get_watchlist(self):
        """
        Get current watchlist
        
        Returns:
            list: Current watchlist
        """
        try:
            # Check if opportunities on watchlist are still valid
            for entry in self.watchlist:
                # Get current price
                symbol = entry['symbol']
                ticker = self.client.get_ticker_price(symbol)
                current_price = float(ticker['price'])
                
                # Update price and calculate price change
                price_change = (current_price - entry['price']) / entry['price'] * 100
                entry['current_price'] = current_price
                entry['price_change'] = price_change
                entry['last_updated'] = datetime.utcnow().isoformat()
                
                # Check if the opportunity is still valid (price hasn't moved too much)
                entry['still_valid'] = abs(price_change) < 3.0  # Example threshold
            
            # Sort watchlist by score
            self.watchlist.sort(key=lambda x: x['score'], reverse=True)
            
            return self.watchlist
            
        except Exception as e:
            self.logger.error(f"Error getting watchlist: {e}")
            return []
    
    def remove_from_watchlist(self, opportunity_id):
        """
        Remove opportunity from watchlist
        
        Args:
            opportunity_id (str): Opportunity ID
            
        Returns:
            bool: Success flag
        """
        try:
            # Find the opportunity
            entry = next((o for o in self.watchlist if o.get('id') == opportunity_id), None)
            
            if not entry:
                return {'error': 'Opportunity not found in watchlist'}
            
            # Remove from watchlist
            self.watchlist = [o for o in self.watchlist if o.get('id') != opportunity_id]
            
            self.logger.info(f"Removed {entry['symbol']} from watchlist")
            return {'success': True}
            
        except Exception as e:
            self.logger.error(f"Error removing from watchlist: {e}")
            return {'error': str(e)}
    
    def get_top_opportunities(self, n=10):
        """
        Get top N opportunities by score
        
        Args:
            n (int, optional): Number of opportunities to return
            
        Returns:
            list: Top opportunities
        """
        try:
            # Sort by score and return top N
            sorted_opportunities = sorted(self.opportunities, key=lambda x: x['score'], reverse=True)
            return sorted_opportunities[:n]
            
        except Exception as e:
            self.logger.error(f"Error getting top opportunities: {e}")
            return []