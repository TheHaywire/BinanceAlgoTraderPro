"""
WebSocket manager for real-time data from Binance
"""

import json
import logging
import threading
import time
import websocket

class WebSocketManager:
    """
    WebSocket manager for handling real-time data streams from Binance
    """
    
    def __init__(self, binance_client, strategies):
        """
        Initialize WebSocket manager
        
        Args:
            binance_client (BinanceClient): Binance client instance
            strategies (list): List of strategy instances
        """
        self.logger = logging.getLogger(__name__)
        self.binance_client = binance_client
        self.strategies = strategies
        self.ws = None
        self.running = False
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 10
        self.reconnect_delay = 60  # 1 minute
        
        # Get list of symbols to monitor
        self.symbols = list(set([strategy.symbol for strategy in strategies]))
        
        # Get list of timeframes to monitor
        self.timeframes = []
        for strategy in strategies:
            self.timeframes.extend(strategy.timeframes)
        self.timeframes = list(set(self.timeframes))
        
        self.logger.info(f"Initialized WebSocket manager for symbols: {self.symbols}, timeframes: {self.timeframes}")
    
    def start(self):
        """Start the WebSocket connection"""
        self.running = True
        self._connect()
        
    def stop(self):
        """Stop the WebSocket connection"""
        self.running = False
        self.reconnect_attempts = 0
        if self.ws:
            self.ws.close()
            self.ws = None
            
    def _connect(self):
        """Establish WebSocket connection"""
        if not self.running:
            return
            
        try:
            # Create WebSocket URL with streams for each symbol and interval
            streams = []
            
            # Add kline streams for each symbol and timeframe
            for symbol in self.symbols:
                for interval in self.timeframes:
                    streams.append(f"{symbol.lower()}@kline_{interval}")
                
                # Add book ticker stream for each symbol
                streams.append(f"{symbol.lower()}@bookTicker")
            
            # Create WebSocket URL
            base_url = "wss://fstream.binancefuture.com/stream?streams=" if not self.binance_client.testnet else "wss://stream.binancefuture.com:9443/stream?streams="
            url = base_url + "/".join(streams)
            
            # Define WebSocket callbacks
            def on_message(ws, message):
                try:
                    self._process_message(message)
                except Exception as e:
                    self.logger.error(f"Error processing WebSocket message: {e}")
            
            def on_error(ws, error):
                self.logger.error(f"WebSocket error: {error}")
            
            def on_close(ws, close_status_code, close_msg):
                self.logger.info(f"WebSocket closed: {close_status_code} - {close_msg}")
                
                if self.running:
                    self._reconnect()
            
            def on_open(ws):
                self.logger.info("WebSocket connection established")
                self.reconnect_attempts = 0
            
            # Create and start WebSocket
            websocket.enableTrace(False)
            self.ws = websocket.WebSocketApp(
                url,
                on_message=on_message,
                on_error=on_error,
                on_close=on_close,
                on_open=on_open
            )
            
            self.logger.info("WebSocket manager started")
            
            # Run WebSocket in current thread
            self.ws.run_forever()
            
        except Exception as e:
            self.logger.error(f"Error connecting to WebSocket: {e}")
            if self.running:
                self._reconnect()
                
    def _reconnect(self):
        """Reconnect to WebSocket after disconnect"""
        if not self.running:
            return
            
        self.reconnect_attempts += 1
        
        if self.reconnect_attempts > self.max_reconnect_attempts:
            self.logger.error(f"Maximum reconnect attempts ({self.max_reconnect_attempts}) reached. Stopping WebSocket manager.")
            self.running = False
            return
            
        delay = self.reconnect_delay * self.reconnect_attempts
        self.logger.info(f"Reconnecting in {delay} seconds (attempt {self.reconnect_attempts})")
        
        # Wait before reconnecting
        time.sleep(delay)
        
        # Reconnect
        self._connect()
        
    def _process_message(self, message):
        """
        Process incoming WebSocket message
        
        Args:
            message (str): WebSocket message
        """
        message = json.loads(message)
        
        # Check for "stream" field which indicates it's from the stream API
        if 'stream' not in message or 'data' not in message:
            self.logger.warning(f"Unexpected message format: {message}")
            return
            
        stream = message['stream']
        data = message['data']
        
        # Parse stream name to get symbol, data type, and interval
        stream_parts = stream.split('@')
        if len(stream_parts) < 2:
            self.logger.warning(f"Invalid stream name: {stream}")
            return
            
        symbol = stream_parts[0].upper()
        data_type = stream_parts[1].split('_')[0]
        
        # Handle different data types
        if data_type == 'kline':
            # Extract interval from stream name (e.g., kline_1m)
            interval = stream_parts[1].split('_')[1]
            self._handle_kline_data(symbol, interval, data)
            
        elif data_type == 'bookTicker':
            self._handle_book_ticker(symbol, data)
    
    def _handle_kline_data(self, symbol, interval, data):
        """
        Handle kline/candlestick data
        
        Args:
            symbol (str): Trading symbol
            interval (str): Candle interval
            data (dict): Kline data
        """
        kline = data['k']
        
        # Check if candle is closed
        if kline['x']:
            # Process closed candle for each strategy
            for strategy in self.strategies:
                if strategy.symbol == symbol:
                    strategy.on_candle_closed(symbol, interval, kline)
    
    def _handle_book_ticker(self, symbol, data):
        """
        Handle book ticker data for real-time price updates
        
        Args:
            symbol (str): Trading symbol
            data (dict): Book ticker data
        """
        # Calculate average price from best bid and ask
        best_bid = float(data['b'])
        best_ask = float(data['a'])
        price = (best_bid + best_ask) / 2
        
        # Process price update for each strategy
        for strategy in self.strategies:
            if strategy.symbol == symbol:
                strategy.on_price_update(symbol, price, best_bid, best_ask)