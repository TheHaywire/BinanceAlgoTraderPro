"""
Base strategy module that provides common functionality for all trading strategies
"""

import logging
import pandas as pd
from abc import ABC, abstractmethod
from datetime import datetime
import time
from models import db, Trade, MarketData

class BaseStrategy(ABC):
    """
    Base class for all trading strategies
    """
    
    def __init__(self, client, risk_manager, symbol, interval, timeframes=None):
        """
        Initialize the strategy
        
        Args:
            client (BinanceClient): Binance client instance
            risk_manager (RiskManager): Risk manager instance
            symbol (str): Trading symbol
            interval (str): Primary timeframe interval
            timeframes (list, optional): Additional timeframes to track
        """
        self.client = client
        self.risk_manager = risk_manager
        self.symbol = symbol
        self.interval = interval
        self.timeframes = timeframes if timeframes else [interval]
        
        # Ensure the primary interval is included in timeframes
        if interval not in self.timeframes:
            self.timeframes.append(interval)
        
        # Strategy state variables
        self.historical_data = {}  # Dictionary to store historical data for each timeframe
        self.current_price = 0
        self.in_position = False
        self.position_side = None
        self.position_entry_price = 0
        self.position_quantity = 0
        self.stop_loss_price = 0
        self.take_profit_price = 0
        self.position_id = None
        self.trade_db_id = None
        
        self.logger = logging.getLogger(__name__)
        
        # Initialize historical data
        self._initialize_historical_data()
        
    def _initialize_historical_data(self):
        """Initialize historical candle data for all timeframes"""
        for tf in self.timeframes:
            try:
                # Get historical klines from Binance
                klines = self.client.get_historical_klines(self.symbol, tf, limit=500)
                self.historical_data[tf] = klines
                self.logger.info(f"Initialized historical data for {self.symbol} on {tf} timeframe: {len(klines)} candles")
            except Exception as e:
                self.logger.error(f"Error initializing historical data for {self.symbol} on {tf} timeframe: {e}")
                # Initialize with empty DataFrame as a fallback
                self.historical_data[tf] = pd.DataFrame(columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    
    def on_candle_closed(self, symbol, interval, kline_data):
        """
        Handle new closed candle data
        
        Args:
            symbol (str): Trading symbol
            interval (str): Candle interval
            kline_data (dict): Kline/candle data
        """
        if symbol != self.symbol or interval not in self.timeframes:
            return
            
        try:
            # Extract data from kline_data
            timestamp = datetime.fromtimestamp(kline_data['t'] / 1000)
            open_price = float(kline_data['o'])
            high_price = float(kline_data['h'])
            low_price = float(kline_data['l'])
            close_price = float(kline_data['c'])
            volume = float(kline_data['v'])
            
            # Create a DataFrame for the new candle
            new_candle = {
                'timestamp': timestamp,
                'open': open_price,
                'high': high_price,
                'low': low_price,
                'close': close_price,
                'volume': volume
            }
            
            new_candle_df = pd.DataFrame([new_candle])
            
            # Check if we already have data for this timeframe
            if interval in self.historical_data and not self.historical_data[interval].empty:
                # Append new candle to historical data
                self.historical_data[interval] = pd.concat([self.historical_data[interval], new_candle_df])
                # Keep only the last 500 candles to prevent memory issues
                self.historical_data[interval] = self.historical_data[interval].tail(500)
            else:
                # Initialize with the new candle
                self.historical_data[interval] = new_candle_df
                
            # Update current price
            self.current_price = close_price
            
            # Store candle data in database if it's the main interval
            if interval == self.interval:
                try:
                    # Get funding rate (only for main interval)
                    funding_rate = self.client.get_funding_rate(symbol)
                    
                    # Create market data record
                    market_data = MarketData(
                        symbol=symbol,
                        timestamp=timestamp,
                        open=open_price,
                        high=high_price,
                        low=low_price,
                        close=close_price,
                        volume=volume,
                        funding_rate=funding_rate
                    )
                    
                    # Add to database
                    db.session.add(market_data)
                    db.session.commit()
                except Exception as e:
                    self.logger.error(f"Error storing market data: {e}")
                    db.session.rollback()
            
            self.logger.debug(f"Updated {interval} candle for {symbol}: Close: {close_price}")
            
        except Exception as e:
            self.logger.error(f"Error updating candle data: {e}")
    
    def on_price_update(self, symbol, price, bid, ask):
        """
        Handle real-time price updates
        
        Args:
            symbol (str): Trading symbol
            price (float): Current price
            bid (float): Best bid price
            ask (float): Best ask price
        """
        if symbol != self.symbol:
            return
        
        # Update current price
        self.current_price = price
        
        # Check exit conditions if in a position
        if self.in_position:
            self._check_exit_conditions(price)
    
    def _check_exit_conditions(self, current_price):
        """
        Check if stop loss or take profit conditions are met
        
        Args:
            current_price (float): Current price
        """
        if not self.in_position:
            return
            
        if self.position_side == 'LONG':
            # Check stop loss
            if current_price <= self.stop_loss_price:
                self.exit_position('stop_loss')
                return
                
            # Check take profit
            if current_price >= self.take_profit_price:
                self.exit_position('take_profit')
                return
        
        elif self.position_side == 'SHORT':
            # Check stop loss
            if current_price >= self.stop_loss_price:
                self.exit_position('stop_loss')
                return
                
            # Check take profit
            if current_price <= self.take_profit_price:
                self.exit_position('take_profit')
                return
    
    def check_and_update_positions(self):
        """Check position status and update tracking"""
        if not self.in_position:
            return
            
        try:
            # Get current position from exchange
            position = self.client.get_position(self.symbol)
            
            # Update position if it exists
            if position and position['positionAmt'] != '0':
                self.position_quantity = abs(float(position['positionAmt']))
                self.position_entry_price = float(position['entryPrice'])
                
                # Update position side if needed
                if float(position['positionAmt']) > 0 and self.position_side != 'LONG':
                    self.position_side = 'LONG'
                elif float(position['positionAmt']) < 0 and self.position_side != 'SHORT':
                    self.position_side = 'SHORT'
                    
                self.logger.info(f"Updated position for {self.symbol}: Side: {self.position_side}, "
                                f"Size: {self.position_quantity}, Entry: {self.position_entry_price}")
            else:
                # Position has been closed externally
                if self.in_position:
                    self.logger.info(f"Position for {self.symbol} has been closed externally")
                    
                    # If we have a database trade record, update it
                    if self.trade_db_id:
                        try:
                            # Get the trade
                            trade = Trade.query.get(self.trade_db_id)
                            if trade and trade.status == 'OPEN':
                                # Mark as closed with the last known price
                                trade.exit_price = self.current_price
                                trade.exit_time = datetime.utcnow()
                                trade.exit_reason = 'external_close'
                                trade.status = 'CLOSED'
                                
                                # Calculate profit/loss
                                if self.position_side == 'LONG':
                                    pnl = (self.current_price - trade.entry_price) * trade.quantity
                                    pnl_pct = (self.current_price / trade.entry_price - 1) * 100
                                else:  # SHORT
                                    pnl = (trade.entry_price - self.current_price) * trade.quantity
                                    pnl_pct = (trade.entry_price / self.current_price - 1) * 100
                                    
                                trade.profit_loss = pnl
                                trade.profit_loss_percent = pnl_pct
                                
                                # Save to database
                                db.session.commit()
                                
                                self.logger.info(f"Updated trade record for external close: ID {self.trade_db_id}, P/L: {pnl_pct:.2f}%")
                        except Exception as e:
                            self.logger.error(f"Error updating trade record for external close: {e}")
                            db.session.rollback()
                    
                    self._reset_trade_state()
                    
        except Exception as e:
            self.logger.error(f"Error checking position: {e}")
    
    def enter_position(self, side, size, entry_price, stop_loss_price, take_profit_price):
        """
        Enter a new position
        
        Args:
            side (str): Position side (LONG or SHORT)
            size (float): Position size
            entry_price (float): Entry price
            stop_loss_price (float): Stop loss price
            take_profit_price (float): Take profit price
            
        Returns:
            bool: True if successful, False otherwise
        """
        # Don't enter if already in a position
        if self.in_position:
            self.logger.warning(f"Already in a position for {self.symbol}")
            return False
            
        # Validate trade with risk manager
        if not self.risk_manager.validate_trade(
            symbol=self.symbol,
            side=side,
            entry_price=entry_price,
            stop_loss=stop_loss_price,
            take_profit=take_profit_price
        ):
            self.logger.warning(f"Trade validation failed for {self.symbol}")
            return False
            
        try:
            # Convert side to Binance format
            order_side = 'BUY' if side == 'LONG' else 'SELL'
            
            # Place the order
            order = self.client.create_order(
                symbol=self.symbol,
                side=order_side,
                order_type='MARKET',
                quantity=size
            )
            
            if order and order.get('status') == 'FILLED':
                # Update position tracking
                self.in_position = True
                self.position_side = side
                self.position_entry_price = entry_price
                self.position_quantity = size
                self.stop_loss_price = stop_loss_price
                self.take_profit_price = take_profit_price
                self.position_id = order.get('orderId')
                
                # Insert trade record in database
                try:
                    trade = Trade(
                        symbol=self.symbol,
                        strategy=self.__class__.__name__,
                        side=side,
                        entry_price=entry_price,
                        quantity=size,
                        stop_loss=stop_loss_price,
                        take_profit=take_profit_price,
                        entry_time=datetime.utcnow(),
                        status='OPEN'
                    )
                    
                    db.session.add(trade)
                    db.session.commit()
                    
                    # Store the database ID for later use
                    self.trade_db_id = trade.id
                    
                    self.logger.info(f"Recorded trade in database: ID {trade.id}")
                except Exception as e:
                    self.logger.error(f"Error recording trade in database: {e}")
                    db.session.rollback()
                
                self.logger.info(f"Entered {side} position for {self.symbol} at {entry_price} with size {size}")
                return True
            else:
                self.logger.error(f"Failed to enter position: {order}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error entering position: {e}")
            return False
    
    def exit_position(self, reason):
        """
        Exit the current position
        
        Args:
            reason (str): Reason for exiting
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.in_position:
            return False
            
        try:
            # Convert side to Binance format (exit is opposite of entry)
            order_side = 'SELL' if self.position_side == 'LONG' else 'BUY'
            
            # Place the order
            order = self.client.create_order(
                symbol=self.symbol,
                side=order_side,
                order_type='MARKET',
                quantity=self.position_quantity,
                reduce_only=True
            )
            
            if order and order.get('status') == 'FILLED':
                exit_price = float(order['price']) if 'price' in order else self.current_price
                
                # Calculate profit/loss
                if self.position_side == 'LONG':
                    pnl = (exit_price - self.position_entry_price) * self.position_quantity
                    pnl_pct = (exit_price / self.position_entry_price - 1) * 100
                else:  # SHORT
                    pnl = (self.position_entry_price - exit_price) * self.position_quantity
                    pnl_pct = (self.position_entry_price / exit_price - 1) * 100
                
                # Update trade record in database
                if self.trade_db_id:
                    try:
                        trade = Trade.query.get(self.trade_db_id)
                        if trade:
                            trade.exit_price = exit_price
                            trade.exit_time = datetime.utcnow()
                            trade.exit_reason = reason
                            trade.status = 'CLOSED'
                            trade.profit_loss = pnl
                            trade.profit_loss_percent = pnl_pct
                            
                            db.session.commit()
                            
                            self.logger.info(f"Updated trade record: ID {self.trade_db_id}, P/L: {pnl_pct:.2f}%")
                    except Exception as e:
                        self.logger.error(f"Error updating trade record: {e}")
                        db.session.rollback()
                
                self.logger.info(f"Exited {self.position_side} position for {self.symbol} at {exit_price}: "
                                f"P/L: {pnl_pct:.2f}%, Reason: {reason}")
                
                # Update risk manager with result
                self.risk_manager.update_trade_result(pnl_pct)
                
                # Reset trade state
                self._reset_trade_state()
                
                return True
            else:
                self.logger.error(f"Failed to exit position: {order}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error exiting position: {e}")
            return False
    
    def _reset_trade_state(self):
        """Reset the trade state after position is closed"""
        self.in_position = False
        self.position_side = None
        self.position_entry_price = 0
        self.position_quantity = 0
        self.stop_loss_price = 0
        self.take_profit_price = 0
        self.position_id = None
        self.trade_db_id = None
    
    @abstractmethod
    def check_for_signals(self):
        """
        Check for entry/exit signals
        To be implemented by each strategy
        """
        pass