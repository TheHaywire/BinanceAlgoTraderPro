"""
Configuration settings for the trading bot
"""

# General settings
DEFAULT_TIMEFRAMES = ['15m', '1h', '4h']
SUPPORTED_TIMEFRAMES = {
    '1m': 60,
    '3m': 180,
    '5m': 300,
    '15m': 900,
    '30m': 1800,
    '1h': 3600,
    '2h': 7200,
    '4h': 14400,
    '6h': 21600,
    '8h': 28800,
    '12h': 43200,
    '1d': 86400,
    '3d': 259200,
    '1w': 604800
}

# Technical indicators settings
RSI_PERIOD = 14
RSI_OVERBOUGHT = 70
RSI_OVERSOLD = 30

MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9

BBANDS_PERIOD = 20
BBANDS_STDDEV = 2

# Momentum breakout strategy settings
VOLUME_PROFILE_PERIODS = 20
BREAKOUT_VOLUME_FACTOR = 1.5
BREAKOUT_CONFIRMATION_CANDLES = 2

# Risk management settings
DEFAULT_MAX_POSITION_SIZE_PCT = 5.0  # Maximum position size as % of account
DEFAULT_MAX_EXPOSURE_PCT = 25.0  # Maximum total exposure
DEFAULT_STOP_LOSS_PCT = 2.0  # Default stop loss percentage
DEFAULT_TAKE_PROFIT_PCT = 3.0  # Default take profit percentage
MIN_REWARD_RISK_RATIO = 1.5  # Minimum reward:risk ratio

# Websocket settings
WEBSOCKET_RECONNECT_TIMEOUT = 60  # Reconnect timeout in seconds
KLINE_STREAM_SUFFIX = "@kline_"
BOOKTICKET_STREAM_SUFFIX = "@bookTicker"

# Database settings
DB_FILENAME = "trading_history.db"

# Logging settings
LOG_FILENAME = "trading_bot.log"
LOG_LEVEL = "INFO"
