"""
Performance Monitoring System for tracking and analyzing trading system performance
"""

import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from models import db, Trade, DailyPerformance, StrategyPerformance, SystemMetrics

class PerformanceMonitor:
    """
    Performance monitor for tracking and analyzing trading system performance
    """
    
    def __init__(self, client):
        """
        Initialize performance monitor
        
        Args:
            client (BinanceClient): Binance client instance
        """
        self.client = client
        self.logger = logging.getLogger(__name__)
        
        # Performance metrics
        self.metrics = {
            'overall': {},
            'by_strategy': {},
            'by_symbol': {}
        }
        
    def update_performance_metrics(self):
        """
        Calculate and update all performance metrics
        """
        try:
            # Get all closed trades from the database
            trades = Trade.query.filter_by(status='CLOSED').all()
            
            if not trades:
                self.logger.info("No closed trades found for performance calculation")
                return
                
            # Create DataFrame from trades
            trades_df = pd.DataFrame([trade.to_dict() for trade in trades])
            
            # Calculate overall metrics
            self._calculate_overall_metrics(trades_df)
            
            # Calculate metrics by strategy
            self._calculate_strategy_metrics(trades_df)
            
            # Calculate metrics by symbol
            self._calculate_symbol_metrics(trades_df)
            
            # Update daily performance in database
            self._update_daily_performance()
            
            # Update strategy performance in database
            self._update_strategy_performance(trades_df)
            
            # Log summary of performance
            self._log_performance_summary()
            
        except Exception as e:
            self.logger.error(f"Error updating performance metrics: {e}")
    
    def _calculate_overall_metrics(self, trades_df):
        """
        Calculate overall performance metrics
        
        Args:
            trades_df (pd.DataFrame): DataFrame of trade data
        """
        # Basic metrics
        total_trades = len(trades_df)
        winning_trades = len(trades_df[trades_df['profit_loss_percent'] > 0])
        losing_trades = len(trades_df[trades_df['profit_loss_percent'] <= 0])
        
        win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
        
        # Calculate profit metrics
        total_profit = trades_df[trades_df['profit_loss'] > 0]['profit_loss'].sum() or 0
        total_loss = abs(trades_df[trades_df['profit_loss'] <= 0]['profit_loss'].sum() or 0)
        net_profit = total_profit - total_loss
        
        # Calculate profit factor
        profit_factor = (total_profit / total_loss) if total_loss > 0 else float('inf')
        
        # Calculate average profit/loss percentages
        avg_profit_pct = trades_df[trades_df['profit_loss_percent'] > 0]['profit_loss_percent'].mean() or 0
        avg_loss_pct = trades_df[trades_df['profit_loss_percent'] <= 0]['profit_loss_percent'].mean() or 0
        
        # Calculate expectancy and R-multiple
        r_multiple = avg_profit_pct / abs(avg_loss_pct) if avg_loss_pct != 0 else float('inf')
        expectancy = (win_rate/100 * avg_profit_pct) + ((1-win_rate/100) * avg_loss_pct)
        
        # Calculate max drawdown
        trades_df = trades_df.sort_values('exit_time')
        trades_df['cumulative_profit'] = trades_df['profit_loss'].cumsum()
        trades_df['drawdown'] = trades_df['cumulative_profit'] - trades_df['cumulative_profit'].cummax()
        max_drawdown = abs(trades_df['drawdown'].min()) if not trades_df['drawdown'].empty else 0
        
        # Calculate Sharpe ratio (simplified)
        returns = trades_df['profit_loss_percent'] / 100  # Convert to decimal for returns
        annualized_return = returns.mean() * 252  # Assuming average of 252 trading days per year
        annualized_volatility = returns.std() * np.sqrt(252) if len(returns) > 1 else 0
        sharpe_ratio = annualized_return / annualized_volatility if annualized_volatility > 0 else 0
        
        # Calculate Sortino ratio (only considering negative returns for volatility)
        downside_returns = returns[returns < 0]
        downside_volatility = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 1 else 0
        sortino_ratio = annualized_return / downside_volatility if downside_volatility > 0 else 0
        
        # Store metrics
        self.metrics['overall'] = {
            'total_trades': total_trades,
            'winning_trades': winning_trades,
            'losing_trades': losing_trades,
            'win_rate': win_rate,
            'profit_factor': profit_factor,
            'net_profit': net_profit,
            'avg_profit_pct': avg_profit_pct,
            'avg_loss_pct': avg_loss_pct,
            'r_multiple': r_multiple,
            'expectancy': expectancy,
            'max_drawdown': max_drawdown,
            'sharpe_ratio': sharpe_ratio,
            'sortino_ratio': sortino_ratio
        }
        
    def _calculate_strategy_metrics(self, trades_df):
        """
        Calculate performance metrics by strategy
        
        Args:
            trades_df (pd.DataFrame): DataFrame of trade data
        """
        # Group by strategy
        for strategy, strategy_df in trades_df.groupby('strategy'):
            # Basic metrics
            total_trades = len(strategy_df)
            winning_trades = len(strategy_df[strategy_df['profit_loss_percent'] > 0])
            losing_trades = len(strategy_df[strategy_df['profit_loss_percent'] <= 0])
            
            win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
            
            # Calculate profit metrics
            total_profit = strategy_df[strategy_df['profit_loss'] > 0]['profit_loss'].sum() or 0
            total_loss = abs(strategy_df[strategy_df['profit_loss'] <= 0]['profit_loss'].sum() or 0)
            net_profit = total_profit - total_loss
            
            # Calculate profit factor
            profit_factor = (total_profit / total_loss) if total_loss > 0 else float('inf')
            
            # Average profit/loss percentages
            avg_profit_pct = strategy_df[strategy_df['profit_loss_percent'] > 0]['profit_loss_percent'].mean() or 0
            avg_loss_pct = strategy_df[strategy_df['profit_loss_percent'] <= 0]['profit_loss_percent'].mean() or 0
            
            # R-multiple
            r_multiple = avg_profit_pct / abs(avg_loss_pct) if avg_loss_pct != 0 else float('inf')
            
            # Max drawdown
            strategy_df = strategy_df.sort_values('exit_time')
            strategy_df['cumulative_profit'] = strategy_df['profit_loss'].cumsum()
            strategy_df['drawdown'] = strategy_df['cumulative_profit'] - strategy_df['cumulative_profit'].cummax()
            max_drawdown = abs(strategy_df['drawdown'].min()) if not strategy_df['drawdown'].empty else 0
            
            # Store metrics
            self.metrics['by_strategy'][strategy] = {
                'total_trades': total_trades,
                'winning_trades': winning_trades,
                'losing_trades': losing_trades,
                'win_rate': win_rate,
                'profit_factor': profit_factor,
                'net_profit': net_profit,
                'avg_profit_pct': avg_profit_pct,
                'avg_loss_pct': avg_loss_pct,
                'r_multiple': r_multiple,
                'max_drawdown': max_drawdown
            }
            
    def _calculate_symbol_metrics(self, trades_df):
        """
        Calculate performance metrics by symbol
        
        Args:
            trades_df (pd.DataFrame): DataFrame of trade data
        """
        # Group by symbol
        for symbol, symbol_df in trades_df.groupby('symbol'):
            # Basic metrics
            total_trades = len(symbol_df)
            winning_trades = len(symbol_df[symbol_df['profit_loss_percent'] > 0])
            losing_trades = len(symbol_df[symbol_df['profit_loss_percent'] <= 0])
            
            win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
            
            # Calculate profit metrics
            total_profit = symbol_df[symbol_df['profit_loss'] > 0]['profit_loss'].sum() or 0
            total_loss = abs(symbol_df[symbol_df['profit_loss'] <= 0]['profit_loss'].sum() or 0)
            net_profit = total_profit - total_loss
            
            # Calculate profit factor
            profit_factor = (total_profit / total_loss) if total_loss > 0 else float('inf')
            
            # Store metrics
            self.metrics['by_symbol'][symbol] = {
                'total_trades': total_trades,
                'winning_trades': winning_trades,
                'losing_trades': losing_trades,
                'win_rate': win_rate,
                'profit_factor': profit_factor,
                'net_profit': net_profit
            }
    
    def _update_daily_performance(self):
        """Update daily performance record in database"""
        try:
            # Get today's date
            today = datetime.utcnow().date()
            
            # Check if we already have a record for today
            existing_record = DailyPerformance.query.filter_by(date=today).first()
            
            # Get latest account balance
            account_info = self.client.get_account_info()
            current_balance = float(account_info.get('totalWalletBalance', 0))
            
            # Get yesterday's record to determine starting balance
            yesterday = today - timedelta(days=1)
            yesterday_record = DailyPerformance.query.filter_by(date=yesterday).first()
            
            if yesterday_record:
                starting_balance = yesterday_record.ending_balance
            else:
                # If no yesterday record, use current balance as starting balance
                starting_balance = current_balance
            
            # Calculate daily profit/loss
            profit_loss = current_balance - starting_balance
            profit_loss_percent = (profit_loss / starting_balance * 100) if starting_balance > 0 else 0
            
            # Get today's trades
            today_trades = Trade.query.filter(
                Trade.exit_time.isnot(None),
                Trade.exit_time >= datetime.combine(today, datetime.min.time()),
                Trade.exit_time < datetime.combine(today + timedelta(days=1), datetime.min.time())
            ).all()
            
            trades_count = len(today_trades)
            winning_trades = len([t for t in today_trades if t.profit_loss_percent and t.profit_loss_percent > 0])
            losing_trades = len([t for t in today_trades if t.profit_loss_percent and t.profit_loss_percent <= 0])
            
            if existing_record:
                # Update existing record
                existing_record.ending_balance = current_balance
                existing_record.profit_loss = profit_loss
                existing_record.profit_loss_percent = profit_loss_percent
                existing_record.trades_count = trades_count
                existing_record.winning_trades = winning_trades
                existing_record.losing_trades = losing_trades
            else:
                # Create new record
                daily_performance = DailyPerformance(
                    date=today,
                    starting_balance=starting_balance,
                    ending_balance=current_balance,
                    profit_loss=profit_loss,
                    profit_loss_percent=profit_loss_percent,
                    trades_count=trades_count,
                    winning_trades=winning_trades,
                    losing_trades=losing_trades
                )
                db.session.add(daily_performance)
                
            db.session.commit()
            self.logger.info(f"Updated daily performance for {today}: P/L: {profit_loss_percent:.2f}%")
            
        except Exception as e:
            self.logger.error(f"Error updating daily performance: {e}")
            db.session.rollback()
    
    def _update_strategy_performance(self, trades_df):
        """
        Update strategy performance records in database
        
        Args:
            trades_df (pd.DataFrame): DataFrame of trade data
        """
        try:
            # Get current time
            now = datetime.utcnow()
            
            # Define period end (now) and period start (30 days ago)
            period_end = now
            period_start = now - timedelta(days=30)
            
            # Group trades by strategy and symbol
            for (strategy, symbol), group in trades_df.groupby(['strategy', 'symbol']):
                # Filter trades within the period
                period_trades = group[
                    (group['exit_time'] >= period_start) & 
                    (group['exit_time'] <= period_end)
                ]
                
                if len(period_trades) == 0:
                    continue
                
                # Calculate metrics
                trades_count = len(period_trades)
                winning_trades = len(period_trades[period_trades['profit_loss_percent'] > 0])
                losing_trades = len(period_trades[period_trades['profit_loss_percent'] <= 0])
                
                profit_loss = period_trades['profit_loss'].sum()
                
                # Calculate profit/loss percentage relative to average account balance
                # This is a simplified approach - ideally we'd use the actual account balance at each trade time
                avg_trade_size = period_trades['quantity'] * period_trades['entry_price']
                profit_loss_percent = (profit_loss / avg_trade_size.mean() * 100) if not avg_trade_size.empty else 0
                
                # Calculate max drawdown
                period_trades = period_trades.sort_values('exit_time')
                period_trades['cumulative_profit'] = period_trades['profit_loss'].cumsum()
                period_trades['drawdown'] = period_trades['cumulative_profit'] - period_trades['cumulative_profit'].cummax()
                max_drawdown = abs(period_trades['drawdown'].min()) if not period_trades['drawdown'].empty else 0
                
                # Calculate Sharpe ratio (simplified)
                returns = period_trades['profit_loss_percent'] / 100  # Convert to decimal
                sharpe_ratio = returns.mean() / returns.std() if len(returns) > 1 and returns.std() > 0 else 0
                
                # Check if we already have a record for this strategy/symbol/period
                existing_record = StrategyPerformance.query.filter_by(
                    strategy=strategy,
                    symbol=symbol,
                    period_start=period_start,
                    period_end=period_end
                ).first()
                
                if existing_record:
                    # Update existing record
                    existing_record.trades_count = trades_count
                    existing_record.winning_trades = winning_trades
                    existing_record.losing_trades = losing_trades
                    existing_record.profit_loss = profit_loss
                    existing_record.profit_loss_percent = profit_loss_percent
                    existing_record.max_drawdown = max_drawdown
                    existing_record.sharpe_ratio = sharpe_ratio
                else:
                    # Create new record
                    strategy_performance = StrategyPerformance(
                        strategy=strategy,
                        symbol=symbol,
                        period_start=period_start,
                        period_end=period_end,
                        trades_count=trades_count,
                        winning_trades=winning_trades,
                        losing_trades=losing_trades,
                        profit_loss=profit_loss,
                        profit_loss_percent=profit_loss_percent,
                        max_drawdown=max_drawdown,
                        sharpe_ratio=sharpe_ratio
                    )
                    db.session.add(strategy_performance)
                
            db.session.commit()
            self.logger.info(f"Updated strategy performance records for the past 30 days")
            
        except Exception as e:
            self.logger.error(f"Error updating strategy performance: {e}")
            db.session.rollback()
    
    def _log_performance_summary(self):
        """Log a summary of performance metrics"""
        overall = self.metrics['overall']
        
        self.logger.info(f"===== PERFORMANCE SUMMARY =====")
        self.logger.info(f"Total Trades: {overall['total_trades']}")
        self.logger.info(f"Win Rate: {overall['win_rate']:.2f}%")
        self.logger.info(f"Profit Factor: {overall['profit_factor']:.2f}")
        self.logger.info(f"Net Profit: {overall['net_profit']:.2f} USDT")
        self.logger.info(f"Average Win: {overall['avg_profit_pct']:.2f}%")
        self.logger.info(f"Average Loss: {overall['avg_loss_pct']:.2f}%")
        self.logger.info(f"Risk-Reward Ratio: {overall['r_multiple']:.2f}")
        self.logger.info(f"Max Drawdown: {overall['max_drawdown']:.2f} USDT")
        self.logger.info(f"Sharpe Ratio: {overall['sharpe_ratio']:.2f}")
        self.logger.info(f"Sortino Ratio: {overall['sortino_ratio']:.2f}")
        self.logger.info(f"===============================")
    
    def get_performance_report(self):
        """
        Get performance report as a dictionary
        
        Returns:
            dict: Performance report
        """
        # Calculate latest metrics before returning
        try:
            # Update metrics if we haven't done so already
            if not self.metrics['overall']:
                self.update_performance_metrics()
                
            # Return performance report
            return {
                'overall': self.metrics['overall'],
                'by_strategy': self.metrics['by_strategy'],
                'by_symbol': self.metrics['by_symbol']
            }
        except Exception as e:
            self.logger.error(f"Error generating performance report: {e}")
            return {
                'overall': {},
                'by_strategy': {},
                'by_symbol': {}
            }
    
    def log_system_metrics(self):
        """Log system metrics to database"""
        try:
            # Get CPU usage (simplified - would use psutil in a real implementation)
            cpu_usage = 50.0  # Placeholder
            
            # Get memory usage (simplified)
            memory_usage = 200.0  # MB, placeholder
            
            # Get API calls count (simplified)
            api_calls_count = 100  # Placeholder
            
            # Get active strategies count
            active_strategies = 1  # Just one for now
            
            # Create system metrics record
            system_metrics = SystemMetrics(
                timestamp=datetime.utcnow(),
                cpu_usage=cpu_usage,
                memory_usage=memory_usage,
                api_calls_count=api_calls_count,
                active_strategies=active_strategies
            )
            
            db.session.add(system_metrics)
            db.session.commit()
            
            self.logger.debug(f"Logged system metrics: CPU: {cpu_usage}%, Memory: {memory_usage}MB")
            
        except Exception as e:
            self.logger.error(f"Error logging system metrics: {e}")
            db.session.rollback()