"""
Real-time Trade Monitoring System for tracking active trades and performance
"""

import logging
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from models import db, Trade

class TradeMonitor:
    """
    Real-time Trade Monitor for tracking active positions and providing detailed analytics
    """
    
    def __init__(self, client):
        """
        Initialize the trade monitor
        
        Args:
            client (BinanceClient): Binance client instance
        """
        self.client = client
        self.logger = logging.getLogger(__name__)
        
        # Store active trades with additional metadata
        self.active_trades = {}
        # Cache for tracking position metrics over time
        self.position_history = {}
        # Execution quality metrics
        self.execution_metrics = {
            'average_slippage': 0.0,
            'fill_quality': 0.0,
            'execution_speed': 0.0
        }
        
    def update_active_trades(self):
        """Update active trades from database and add real-time metrics"""
        try:
            # Query all open trades from the database
            trades = Trade.query.filter_by(status='OPEN').all()
            
            # Clear the active trades cache
            self.active_trades = {}
            
            # Process each trade
            for trade in trades:
                trade_dict = trade.to_dict()
                # Add the trade to active trades
                self.active_trades[trade.id] = self._enrich_trade_data(trade_dict)
                
            self.logger.info(f"Updated {len(self.active_trades)} active trades")
            return self.active_trades
        except Exception as e:
            self.logger.error(f"Error updating active trades: {e}")
            return {}
    
    def _enrich_trade_data(self, trade_dict):
        """
        Enrich trade data with real-time market information
        
        Args:
            trade_dict (dict): Trade dictionary from database
            
        Returns:
            dict: Enriched trade data
        """
        try:
            # Get current price and calculate P&L
            symbol = trade_dict['symbol']
            current_price = self._get_current_price(symbol)
            
            # Calculate P&L
            entry_price = trade_dict['entry_price']
            quantity = trade_dict['quantity']
            side = trade_dict['side']
            
            # Calculate absolute P&L
            if side == 'LONG':
                pl_absolute = (current_price - entry_price) * quantity
                pl_percent = (current_price - entry_price) / entry_price * 100
            else:  # SHORT
                pl_absolute = (entry_price - current_price) * quantity
                pl_percent = (entry_price - current_price) / entry_price * 100
            
            # Get position age
            entry_time = datetime.fromisoformat(trade_dict['entry_time'].replace('Z', '+00:00'))
            position_age = (datetime.utcnow() - entry_time).total_seconds() / 60  # in minutes
            
            # Get funding rate
            funding_rate = self._get_funding_rate(symbol)
            
            # Get liquidation price
            liquidation_price = self._calculate_liquidation_price(
                symbol, side, entry_price, quantity, trade_dict.get('leverage', 1)
            )
            
            # Calculate margin ratio
            margin_ratio = self._calculate_margin_ratio(
                side, entry_price, current_price, trade_dict.get('leverage', 1)
            )
            
            # Add enriched data to trade dictionary
            enriched_data = {
                **trade_dict,
                'current_price': current_price,
                'pl_absolute': pl_absolute,
                'pl_percent': pl_percent,
                'position_age_minutes': position_age,
                'liquidation_price': liquidation_price,
                'margin_ratio': margin_ratio,
                'funding_rate': funding_rate,
                'last_updated': datetime.utcnow().isoformat()
            }
            
            # Update position history
            self._update_position_history(trade_dict['id'], enriched_data)
            
            return enriched_data
        
        except Exception as e:
            self.logger.error(f"Error enriching trade data: {e}")
            return trade_dict
    
    def _get_current_price(self, symbol):
        """
        Get current price for a symbol
        
        Args:
            symbol (str): Trading symbol
            
        Returns:
            float: Current price
        """
        try:
            ticker = self.client.get_ticker_price(symbol)
            return float(ticker['price'])
        except Exception as e:
            self.logger.error(f"Error getting current price for {symbol}: {e}")
            return 0.0
    
    def _get_funding_rate(self, symbol):
        """
        Get current funding rate for a symbol
        
        Args:
            symbol (str): Trading symbol
            
        Returns:
            float: Current funding rate (%)
        """
        try:
            funding_info = self.client.get_funding_rate(symbol)
            return float(funding_info.get('lastFundingRate', 0.0)) * 100  # Convert to percentage
        except Exception as e:
            self.logger.error(f"Error getting funding rate for {symbol}: {e}")
            return 0.0
    
    def _calculate_liquidation_price(self, symbol, side, entry_price, quantity, leverage):
        """
        Calculate estimated liquidation price
        
        Args:
            symbol (str): Trading symbol
            side (str): Position side (LONG or SHORT)
            entry_price (float): Entry price
            quantity (float): Position size
            leverage (float): Position leverage
            
        Returns:
            float: Estimated liquidation price
        """
        try:
            # This is a simplified calculation, actual liquidation price depends on
            # maintenance margin requirements which vary by exchange and can be complex
            maintenance_margin = 0.005  # 0.5% - simplified example
            
            if side == 'LONG':
                # For longs, liquidation occurs when price falls
                # Liquidation price = entry_price * (1 - (1 / leverage) + maintenance_margin)
                liquidation_price = entry_price * (1 - (1 / leverage) + maintenance_margin)
            else:  # SHORT
                # For shorts, liquidation occurs when price rises
                # Liquidation price = entry_price * (1 + (1 / leverage) - maintenance_margin)
                liquidation_price = entry_price * (1 + (1 / leverage) - maintenance_margin)
            
            return liquidation_price
        except Exception as e:
            self.logger.error(f"Error calculating liquidation price: {e}")
            return 0.0
    
    def _calculate_margin_ratio(self, side, entry_price, current_price, leverage):
        """
        Calculate margin ratio (how close to liquidation)
        
        Args:
            side (str): Position side (LONG or SHORT)
            entry_price (float): Entry price
            current_price (float): Current price
            leverage (float): Position leverage
            
        Returns:
            float: Margin ratio (%)
        """
        try:
            # Simplified margin ratio calculation
            # For longs: (current_price - liquidation_price) / current_price * 100
            # For shorts: (liquidation_price - current_price) / current_price * 100
            
            maintenance_margin = 0.005  # 0.5% - simplified example
            
            if side == 'LONG':
                liquidation_price = entry_price * (1 - (1 / leverage) + maintenance_margin)
                margin_ratio = (current_price - liquidation_price) / current_price * 100
            else:  # SHORT
                liquidation_price = entry_price * (1 + (1 / leverage) - maintenance_margin)
                margin_ratio = (liquidation_price - current_price) / current_price * 100
            
            return max(margin_ratio, 0.0)  # Ensure it's not negative
        except Exception as e:
            self.logger.error(f"Error calculating margin ratio: {e}")
            return 0.0
    
    def _update_position_history(self, trade_id, trade_data):
        """
        Update position history for a trade
        
        Args:
            trade_id (int): Trade ID
            trade_data (dict): Trade data
        """
        try:
            # Initialize history if not exists
            if trade_id not in self.position_history:
                self.position_history[trade_id] = []
            
            # Add current snapshot to history
            snapshot = {
                'timestamp': datetime.utcnow().isoformat(),
                'price': trade_data['current_price'],
                'pl_percent': trade_data['pl_percent'],
                'margin_ratio': trade_data['margin_ratio']
            }
            
            # Add to history, keeping the last 100 snapshots
            self.position_history[trade_id].append(snapshot)
            if len(self.position_history[trade_id]) > 100:
                self.position_history[trade_id].pop(0)
                
        except Exception as e:
            self.logger.error(f"Error updating position history: {e}")
    
    def get_execution_analytics(self, trade_id=None):
        """
        Get execution analytics for a trade or all trades
        
        Args:
            trade_id (int, optional): Trade ID. If None, return aggregated metrics.
            
        Returns:
            dict: Execution analytics
        """
        try:
            if trade_id is not None:
                # Get analytics for a specific trade
                trade = Trade.query.get(trade_id)
                if not trade:
                    return {'error': 'Trade not found'}
                
                # Calculate slippage (intended vs. actual entry)
                # This assumes we have an intended_entry_price field or similar
                # For demo, we'll use a placeholder calculation
                slippage = 0.05  # Example: 0.05%
                
                return {
                    'trade_id': trade_id,
                    'symbol': trade.symbol,
                    'slippage': slippage,
                    'execution_time_ms': 250,  # Example value in milliseconds
                    'fill_quality': 'Good',  # Example rating
                    'market_impact': 'Low'  # Example rating
                }
            else:
                # Return aggregated metrics
                return self.execution_metrics
                
        except Exception as e:
            self.logger.error(f"Error getting execution analytics: {e}")
            return {'error': str(e)}
    
    def get_trade_journal(self, trade_id=None, limit=10):
        """
        Get trade journal entries
        
        Args:
            trade_id (int, optional): Trade ID. If None, return recent entries.
            limit (int, optional): Maximum number of entries to return
            
        Returns:
            list: Trade journal entries
        """
        try:
            if trade_id is not None:
                # Get journal for a specific trade
                trade = Trade.query.get(trade_id)
                if not trade:
                    return {'error': 'Trade not found'}
                
                # For now, we'll return a placeholder journal entry
                # In a real implementation, this would come from a database
                return [{
                    'trade_id': trade_id,
                    'timestamp': datetime.utcnow().isoformat(),
                    'symbol': trade.symbol,
                    'action': 'Entry',
                    'price': trade.entry_price,
                    'notes': 'Entered position based on breakout pattern',
                    'market_conditions': 'Uptrend, low volatility',
                    'strategy': trade.strategy
                }]
            else:
                # Return recent journal entries
                trades = Trade.query.order_by(Trade.entry_time.desc()).limit(limit).all()
                journal = []
                
                for trade in trades:
                    journal.append({
                        'trade_id': trade.id,
                        'timestamp': trade.entry_time.isoformat(),
                        'symbol': trade.symbol,
                        'action': 'Entry' if trade.status == 'OPEN' else 'Exit',
                        'price': trade.entry_price if trade.status == 'OPEN' else trade.exit_price,
                        'notes': f"{'Entered' if trade.status == 'OPEN' else 'Exited'} position",
                        'strategy': trade.strategy
                    })
                
                return journal
                
        except Exception as e:
            self.logger.error(f"Error getting trade journal: {e}")
            return {'error': str(e)}
    
    def get_position_timeline(self, trade_id):
        """
        Get position timeline for a trade
        
        Args:
            trade_id (int): Trade ID
            
        Returns:
            dict: Position timeline data
        """
        try:
            if trade_id not in self.position_history:
                return {'error': 'No history available for this trade'}
            
            history = self.position_history[trade_id]
            
            # Extract time series data
            timestamps = [item['timestamp'] for item in history]
            prices = [item['price'] for item in history]
            pl_percents = [item['pl_percent'] for item in history]
            margin_ratios = [item['margin_ratio'] for item in history]
            
            return {
                'trade_id': trade_id,
                'timestamps': timestamps,
                'prices': prices,
                'pl_percents': pl_percents,
                'margin_ratios': margin_ratios
            }
                
        except Exception as e:
            self.logger.error(f"Error getting position timeline: {e}")
            return {'error': str(e)}
    
    def get_account_risk_exposure(self):
        """
        Calculate account risk exposure from all active trades
        
        Returns:
            dict: Account risk metrics
        """
        try:
            # Get account balance
            account_info = self.client.get_account_info()
            balance = float(account_info.get('totalWalletBalance', 0))
            
            # Calculate total position value and risk exposure
            total_position_value = 0.0
            max_position_size = 0.0
            position_distribution = {}
            
            for trade_id, trade in self.active_trades.items():
                position_value = trade['quantity'] * trade['current_price']
                total_position_value += position_value
                
                # Track max position
                if position_value > max_position_size:
                    max_position_size = position_value
                
                # Track position distribution by symbol
                symbol = trade['symbol']
                if symbol not in position_distribution:
                    position_distribution[symbol] = 0
                position_distribution[symbol] += position_value
            
            # Calculate metrics
            account_risk = (total_position_value / balance) * 100 if balance > 0 else 0
            concentration_risk = (max_position_size / total_position_value) * 100 if total_position_value > 0 else 0
            
            return {
                'account_balance': balance,
                'total_position_value': total_position_value,
                'account_risk_percent': account_risk,
                'concentration_risk_percent': concentration_risk,
                'position_distribution': position_distribution
            }
                
        except Exception as e:
            self.logger.error(f"Error calculating account risk exposure: {e}")
            return {'error': str(e)}
    
    def get_active_trade_summary(self):
        """
        Get a summary of all active trades
        
        Returns:
            dict: Active trade summary
        """
        try:
            # Count trades
            num_trades = len(self.active_trades)
            
            # Calculate total P&L
            total_pl_absolute = sum(trade['pl_absolute'] for trade in self.active_trades.values())
            
            # Get symbols
            symbols = set(trade['symbol'] for trade in self.active_trades.values())
            
            # Get strategies
            strategies = set(trade['strategy'] for trade in self.active_trades.values())
            
            # Calculate average age
            avg_age = sum(trade['position_age_minutes'] for trade in self.active_trades.values()) / num_trades if num_trades > 0 else 0
            
            # Count trades by side
            long_trades = sum(1 for trade in self.active_trades.values() if trade['side'] == 'LONG')
            short_trades = sum(1 for trade in self.active_trades.values() if trade['side'] == 'SHORT')
            
            return {
                'num_trades': num_trades,
                'total_pl_absolute': total_pl_absolute,
                'symbols': list(symbols),
                'strategies': list(strategies),
                'avg_position_age_minutes': avg_age,
                'long_trades': long_trades,
                'short_trades': short_trades
            }
                
        except Exception as e:
            self.logger.error(f"Error getting active trade summary: {e}")
            return {'error': str(e)}