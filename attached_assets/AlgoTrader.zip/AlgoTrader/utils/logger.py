"""
Logger module for setting up consistent logging across the application
"""

import logging
import os
import sys
from datetime import datetime

def setup_logger(log_level=logging.INFO, log_to_file=True):
    """
    Set up the logger with consistent formatting
    
    Args:
        log_level (int): Logging level (default: logging.INFO)
        log_to_file (bool): Whether to log to file (default: True)
        
    Returns:
        logging.Logger: Configured logger
    """
    # Create logs directory if it doesn't exist
    if log_to_file and not os.path.exists('logs'):
        os.makedirs('logs')
    
    # Set up root logger
    logger = logging.getLogger()
    logger.setLevel(log_level)
    
    # Remove existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Add console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Add file handler if enabled
    if log_to_file:
        log_filename = f"logs/bot_{datetime.now().strftime('%Y-%m-%d')}.log"
        file_handler = logging.FileHandler(log_filename)
        file_handler.setLevel(log_level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    # Set WebSocket client logger to ERROR level to reduce noise
    logging.getLogger('websocket').setLevel(logging.ERROR)
    
    return logger