"""
Technical indicators module for trading strategies
Includes functions for calculating common technical indicators
"""

import numpy as np
import pandas as pd

def calculate_atr(df, period=14):
    """
    Calculate Average True Range (ATR)
    
    Args:
        df (pd.DataFrame): Price data with 'high', 'low', 'close' columns
        period (int): ATR period
        
    Returns:
        pd.DataFrame: Input DataFrame with 'atr' column added
    """
    df = df.copy()
    
    # Calculate True Range
    df['tr0'] = abs(df['high'] - df['low'])
    df['tr1'] = abs(df['high'] - df['close'].shift())
    df['tr2'] = abs(df['low'] - df['close'].shift())
    df['tr'] = df[['tr0', 'tr1', 'tr2']].max(axis=1)
    
    # Calculate ATR
    df['atr'] = df['tr'].rolling(window=period).mean()
    
    # Drop temporary columns
    df.drop(['tr0', 'tr1', 'tr2', 'tr'], axis=1, inplace=True)
    
    return df

def calculate_rsi(df, period=14, column='close'):
    """
    Calculate Relative Strength Index (RSI)
    
    Args:
        df (pd.DataFrame): Price data
        period (int): RSI period
        column (str): Column name to use for calculation
        
    Returns:
        pd.DataFrame: Input DataFrame with 'rsi' column added
    """
    df = df.copy()
    
    # Calculate price changes
    delta = df[column].diff()
    
    # Separate gains and losses
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    
    # Calculate average gain and loss
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    
    # Calculate RS
    rs = avg_gain / avg_loss
    
    # Calculate RSI
    df['rsi'] = 100 - (100 / (1 + rs))
    
    return df

def calculate_macd(df, column='close', fast_period=12, slow_period=26, signal_period=9):
    """
    Calculate Moving Average Convergence Divergence (MACD)
    
    Args:
        df (pd.DataFrame): Price data
        column (str): Column name to use for calculation
        fast_period (int): Fast EMA period
        slow_period (int): Slow EMA period
        signal_period (int): Signal EMA period
        
    Returns:
        pd.DataFrame: Input DataFrame with 'macd', 'macd_signal', and 'macd_hist' columns added
    """
    df = df.copy()
    
    # Calculate EMAs
    df['ema_fast'] = df[column].ewm(span=fast_period, adjust=False).mean()
    df['ema_slow'] = df[column].ewm(span=slow_period, adjust=False).mean()
    
    # Calculate MACD and signal line
    df['macd'] = df['ema_fast'] - df['ema_slow']
    df['macd_signal'] = df['macd'].ewm(span=signal_period, adjust=False).mean()
    df['macd_hist'] = df['macd'] - df['macd_signal']
    
    # Drop temporary columns
    df.drop(['ema_fast', 'ema_slow'], axis=1, inplace=True)
    
    return df

def calculate_bollinger_bands(df, period=20, stdev=2, column='close'):
    """
    Calculate Bollinger Bands
    
    Args:
        df (pd.DataFrame): Price data
        period (int): Moving average period
        stdev (int): Number of standard deviations
        column (str): Column name to use for calculation
        
    Returns:
        pd.DataFrame: Input DataFrame with 'bb_upper', 'bb_middle', and 'bb_lower' columns added
    """
    df = df.copy()
    
    # Calculate middle band
    df['bb_middle'] = df[column].rolling(window=period).mean()
    
    # Calculate standard deviation
    bb_std = df[column].rolling(window=period).std()
    
    # Calculate upper and lower bands
    df['bb_upper'] = df['bb_middle'] + (bb_std * stdev)
    df['bb_lower'] = df['bb_middle'] - (bb_std * stdev)
    
    return df

def calculate_ema(df, period, column='close'):
    """
    Calculate Exponential Moving Average (EMA)
    
    Args:
        df (pd.DataFrame): Price data
        period (int): EMA period
        column (str): Column name to use for calculation
        
    Returns:
        pd.DataFrame: Input DataFrame with 'ema_{period}' column added
    """
    df = df.copy()
    df[f'ema_{period}'] = df[column].ewm(span=period, adjust=False).mean()
    return df

def calculate_sma(df, period, column='close'):
    """
    Calculate Simple Moving Average (SMA)
    
    Args:
        df (pd.DataFrame): Price data
        period (int): SMA period
        column (str): Column name to use for calculation
        
    Returns:
        pd.DataFrame: Input DataFrame with 'sma_{period}' column added
    """
    df = df.copy()
    df[f'sma_{period}'] = df[column].rolling(window=period).mean()
    return df

def identify_support_resistance(df, window=5):
    """
    Identify support and resistance levels using highs and lows
    
    Args:
        df (pd.DataFrame): Price data with 'high' and 'low' columns
        window (int): Window size for finding local highs and lows
        
    Returns:
        tuple: (support, resistance) prices
    """
    if len(df) < window * 2 + 1:
        # If not enough data, use min and max
        return df['low'].min(), df['high'].max()
    
    # Find local highs
    high_points = []
    for i in range(window, len(df) - window):
        if df['high'].iloc[i] > df['high'].iloc[i-window:i].max() and \
           df['high'].iloc[i] > df['high'].iloc[i+1:i+window+1].max():
            high_points.append(df['high'].iloc[i])
    
    # Find local lows
    low_points = []
    for i in range(window, len(df) - window):
        if df['low'].iloc[i] < df['low'].iloc[i-window:i].min() and \
           df['low'].iloc[i] < df['low'].iloc[i+1:i+window+1].min():
            low_points.append(df['low'].iloc[i])
    
    # Calculate support and resistance levels
    if len(high_points) > 0:
        resistance = np.median(high_points)
    else:
        resistance = df['high'].max()
        
    if len(low_points) > 0:
        support = np.median(low_points)
    else:
        support = df['low'].min()
    
    return support, resistance

def detect_divergence(df, period=14, window=5):
    """
    Detect price and RSI divergence
    
    Args:
        df (pd.DataFrame): Price data with 'close' column
        period (int): RSI period
        window (int): Window for local highs and lows
        
    Returns:
        pd.DataFrame: Input DataFrame with 'bullish_div' and 'bearish_div' columns added
    """
    df = df.copy()
    
    # Calculate RSI if not already present
    if 'rsi' not in df.columns:
        df = calculate_rsi(df, period=period)
    
    # Initialize divergence columns
    df['bullish_div'] = False
    df['bearish_div'] = False
    
    # We need enough data to find local highs/lows
    if len(df) < window * 2 + 1:
        return df
    
    # Check for bullish divergence (lower lows in price, higher lows in RSI)
    for i in range(window, len(df) - window):
        # Check if we have a local low in price
        if df['low'].iloc[i] < df['low'].iloc[i-window:i].min() and \
           df['low'].iloc[i] < df['low'].iloc[i+1:i+window+1].min():
            
            # Look for a previous local low within 20 bars
            for j in range(max(0, i-20), i-window):
                if df['low'].iloc[j] < df['low'].iloc[max(0, j-window):j].min() and \
                   df['low'].iloc[j] < df['low'].iloc[j+1:j+window+1].min():
                    
                    # Check for bullish divergence
                    if df['low'].iloc[i] < df['low'].iloc[j] and df['rsi'].iloc[i] > df['rsi'].iloc[j]:
                        df.loc[df.index[i], 'bullish_div'] = True
                        break
    
    # Check for bearish divergence (higher highs in price, lower highs in RSI)
    for i in range(window, len(df) - window):
        # Check if we have a local high in price
        if df['high'].iloc[i] > df['high'].iloc[i-window:i].max() and \
           df['high'].iloc[i] > df['high'].iloc[i+1:i+window+1].max():
            
            # Look for a previous local high within 20 bars
            for j in range(max(0, i-20), i-window):
                if df['high'].iloc[j] > df['high'].iloc[max(0, j-window):j].max() and \
                   df['high'].iloc[j] > df['high'].iloc[j+1:j+window+1].max():
                    
                    # Check for bearish divergence
                    if df['high'].iloc[i] > df['high'].iloc[j] and df['rsi'].iloc[i] < df['rsi'].iloc[j]:
                        df.loc[df.index[i], 'bearish_div'] = True
                        break
    
    return df