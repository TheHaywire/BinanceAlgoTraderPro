import os
import logging
from flask import Flask, render_template, jsonify
from dotenv import load_dotenv
import pandas as pd
import datetime
import threading
import time

# Import bot components
try:
    from api.binance_client import BinanceClient
    from data.database import Database
except ImportError:
    # For development without actual trading components
    pass

# Load environment variables
load_dotenv()

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global variables to store bot state
bot_state = {
    "running": False,
    "connected": False,
    "account_balance": 0,
    "active_trades": [],
    "last_update": None
}

# Initialize database
try:
    db = Database()
except Exception as e:
    logger.warning(f"Database initialization failed: {e}")
    db = None

# Try to initialize Binance client if credentials are available
try:
    api_key = os.environ.get("BINANCE_API_KEY")
    api_secret = os.environ.get("BINANCE_API_SECRET")
    
    if api_key and api_secret:
        client = BinanceClient(api_key, api_secret, testnet=True)
        bot_state["connected"] = True
        
        # Background thread to update bot state
        def update_bot_state():
            while True:
                try:
                    # Update account info
                    account_info = client.get_account_info()
                    bot_state["account_balance"] = float(account_info["totalMarginBalance"])
                    
                    # Update active trades from database
                    if db:
                        bot_state["active_trades"] = db.get_open_trades()
                    bot_state["last_update"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    
                except Exception as e:
                    logger.error(f"Error updating bot state: {e}")
                
                time.sleep(30)  # Update every 30 seconds
        
        # Start the update thread
        update_thread = threading.Thread(target=update_bot_state)
        update_thread.daemon = True
        update_thread.start()
        
except Exception as e:
    logger.warning(f"Failed to initialize Binance client: {e}")
    # Use demo data for testing
    bot_state["account_balance"] = 10000.00
    bot_state["connected"] = False
    bot_state["last_update"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

@app.route('/')
def index():
    """Dashboard homepage"""
    trade_history = []
    performance = []
    
    # Get trade history and performance data if database is available
    if db and hasattr(db, 'conn') and db.conn is not None:
        try:
            # Get trade history
            trade_history_df = db.get_trade_history(limit=20)
            if not trade_history_df.empty:
                trade_history = trade_history_df.to_dict('records')
            
            # Get performance data
            performance_df = db.get_performance_summary(days=30)
            if not performance_df.empty:
                performance = performance_df.to_dict('records')
        except Exception as e:
            logger.error(f"Error retrieving data: {e}")
    else:
        logger.warning("Database connection not available, using empty datasets")
    
    return render_template('index.html', 
                           bot_state=bot_state,
                           trade_history=trade_history,
                           performance=performance)

@app.route('/api/status')
def api_status():
    """API endpoint to get bot status"""
    return jsonify(bot_state)

@app.route('/api/trade_history')
def api_trade_history():
    """API endpoint to get trade history"""
    if not db or not hasattr(db, 'conn') or db.conn is None:
        return jsonify([])
        
    try:
        trade_history = db.get_trade_history(limit=50)
        
        if trade_history.empty:
            return jsonify([])
        
        # Convert to list of dicts
        return jsonify(trade_history.to_dict('records'))
    except Exception as e:
        logger.error(f"Error retrieving trade history: {e}")
        return jsonify([])

@app.route('/api/performance')
def api_performance():
    """API endpoint to get performance data"""
    if not db or not hasattr(db, 'conn') or db.conn is None:
        return jsonify([])
        
    try:
        performance = db.get_performance_summary(days=30)
        
        if performance.empty:
            return jsonify([])
        
        # Convert to list of dicts
        return jsonify(performance.to_dict('records'))
    except Exception as e:
        logger.error(f"Error retrieving performance data: {e}")
        return jsonify([])

@app.errorhandler(404)
def page_not_found(e):
    return render_template('index.html'), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
