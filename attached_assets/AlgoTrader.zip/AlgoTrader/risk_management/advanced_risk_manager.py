"""
Advanced Risk Management System with drawdown control and adaptive position sizing
"""

import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import math
from models import db, Trade, DailyPerformance

class AdvancedRiskManager:
    """
    Advanced risk manager with dynamic risk adjustment, drawdown control, and position sizing
    """
    
    def __init__(self, client, base_risk_pct=1.0, max_position_pct=5.0, max_drawdown_pct=10.0):
        """
        Initialize advanced risk manager
        
        Args:
            client (BinanceClient): Binance client instance
            base_risk_pct (float): Base risk percentage per trade
            max_position_pct (float): Maximum position size as percentage of account
            max_drawdown_pct (float): Maximum allowable drawdown percentage
        """
        self.client = client
        self.base_risk_pct = base_risk_pct
        self.max_position_pct = max_position_pct
        self.max_drawdown_pct = max_drawdown_pct
        
        self.logger = logging.getLogger(__name__)
        
        # State variables
        self.daily_loss_limit_pct = 5.0  # Maximum daily loss percentage
        self.weekly_loss_limit_pct = 10.0  # Maximum weekly loss percentage
        self.monthly_loss_limit_pct = 15.0  # Maximum monthly loss percentage
        
        self.consecutive_losses = 0
        self.win_streak = 0
        self.total_trades = 0
        self.winning_trades = 0
        self.current_drawdown_pct = 0.0
        self.max_drawdown_reached = False
        
        # Initialize trade history - this would ideally be loaded from the database
        self._load_trade_history()
        
    def _load_trade_history(self):
        """Load trade history from database"""
        try:
            # Get closed trades
            trades = Trade.query.filter_by(status='CLOSED').all()
            
            if trades:
                # Count wins and losses
                self.total_trades = len(trades)
                self.winning_trades = len([t for t in trades if t.profit_loss_percent and t.profit_loss_percent > 0])
                
                # Calculate current drawdown
                self._calculate_current_drawdown()
                
                # Check for consecutive losses
                recent_trades = sorted(trades, key=lambda t: t.exit_time if t.exit_time else datetime.min, reverse=True)[:10]
                self.consecutive_losses = 0
                
                for trade in recent_trades:
                    if trade.profit_loss_percent and trade.profit_loss_percent <= 0:
                        self.consecutive_losses += 1
                    else:
                        break
                
                self.logger.info(f"Loaded trade history: {self.total_trades} total trades, "
                               f"{self.winning_trades} winning trades, "
                               f"{self.consecutive_losses} consecutive losses")
                               
        except Exception as e:
            self.logger.error(f"Error loading trade history: {e}")
    
    def _calculate_current_drawdown(self):
        """Calculate current drawdown from account history"""
        try:
            # Get daily performance records
            records = DailyPerformance.query.order_by(DailyPerformance.date).all()
            
            if not records:
                return
                
            # Create DataFrame
            df = pd.DataFrame([{
                'date': r.date,
                'balance': r.ending_balance
            } for r in records])
            
            # Calculate drawdown
            df['peak'] = df['balance'].cummax()
            df['drawdown'] = (df['balance'] - df['peak']) / df['peak'] * 100
            
            # Get current drawdown
            self.current_drawdown_pct = abs(df['drawdown'].iloc[-1]) if len(df) > 0 else 0.0
            
            # Check if max drawdown has been reached
            self.max_drawdown_reached = self.current_drawdown_pct >= self.max_drawdown_pct
            
            if self.max_drawdown_reached:
                self.logger.warning(f"Maximum drawdown reached: {self.current_drawdown_pct:.2f}% > {self.max_drawdown_pct:.2f}%")
                
        except Exception as e:
            self.logger.error(f"Error calculating drawdown: {e}")
    
    def _check_daily_loss_limit(self):
        """
        Check if daily loss limit has been reached
        
        Returns:
            bool: True if limit reached, False otherwise
        """
        try:
            # Get today's performance
            today = datetime.utcnow().date()
            record = DailyPerformance.query.filter_by(date=today).first()
            
            if record and record.profit_loss_percent < -self.daily_loss_limit_pct:
                self.logger.warning(f"Daily loss limit reached: {record.profit_loss_percent:.2f}% < -{self.daily_loss_limit_pct:.2f}%")
                return True
                
            return False
            
        except Exception as e:
            self.logger.error(f"Error checking daily loss limit: {e}")
            return False
    
    def _check_weekly_loss_limit(self):
        """
        Check if weekly loss limit has been reached
        
        Returns:
            bool: True if limit reached, False otherwise
        """
        try:
            # Get performance for the last 7 days
            end_date = datetime.utcnow().date()
            start_date = end_date - timedelta(days=7)
            
            records = DailyPerformance.query.filter(
                DailyPerformance.date >= start_date,
                DailyPerformance.date <= end_date
            ).all()
            
            if not records:
                return False
                
            # Calculate total loss
            total_profit_loss_pct = sum(r.profit_loss_percent for r in records)
            
            if total_profit_loss_pct < -self.weekly_loss_limit_pct:
                self.logger.warning(f"Weekly loss limit reached: {total_profit_loss_pct:.2f}% < -{self.weekly_loss_limit_pct:.2f}%")
                return True
                
            return False
            
        except Exception as e:
            self.logger.error(f"Error checking weekly loss limit: {e}")
            return False
    
    def _calculate_risk_adjustment(self):
        """
        Calculate risk adjustment factor based on performance
        
        Returns:
            float: Risk adjustment factor (0.0-1.0)
        """
        # Start with base adjustment of 1.0 (no adjustment)
        adjustment = 1.0
        
        # Adjust for consecutive losses
        if self.consecutive_losses > 0:
            loss_factor = 1.0 - (0.1 * self.consecutive_losses)  # Reduce by 10% per consecutive loss
            adjustment *= max(loss_factor, 0.5)  # Don't go below 50%
        
        # Adjust for drawdown
        if self.current_drawdown_pct > 0:
            # Linear scale from 1.0 at 0% drawdown to 0.5 at max_drawdown_pct
            drawdown_factor = 1.0 - (0.5 * self.current_drawdown_pct / self.max_drawdown_pct)
            adjustment *= max(drawdown_factor, 0.5)  # Don't go below 50%
        
        # Adjust for win rate
        win_rate = self.winning_trades / self.total_trades if self.total_trades > 0 else 0.5
        
        if win_rate < 0.4:  # Below 40% win rate
            adjustment *= 0.8  # Reduce risk
        elif win_rate > 0.6:  # Above 60% win rate
            adjustment *= 1.2  # Increase risk
        
        # Cap adjustment
        adjustment = min(max(adjustment, 0.25), 1.5)  # Between 25% and 150%
        
        return adjustment
    
    def check_trading_allowed(self):
        """
        Check if trading is allowed based on risk limits
        
        Returns:
            bool: True if trading is allowed, False otherwise
        """
        # Update current drawdown
        self._calculate_current_drawdown()
        
        # Check drawdown circuit breaker
        if self.max_drawdown_reached:
            self.logger.warning(f"Trading halted: Maximum drawdown reached ({self.current_drawdown_pct:.2f}%)")
            return False
        
        # Check daily loss limit
        if self._check_daily_loss_limit():
            self.logger.warning("Trading halted: Daily loss limit reached")
            return False
        
        # Check weekly loss limit
        if self._check_weekly_loss_limit():
            self.logger.warning("Trading halted: Weekly loss limit reached")
            return False
        
        # Check consecutive losses circuit breaker
        if self.consecutive_losses >= 5:  # 5 consecutive losses
            self.logger.warning(f"Trading halted: Too many consecutive losses ({self.consecutive_losses})")
            return False
        
        return True
    
    def calculate_position_size(self, symbol, entry_price, stop_loss_price, strategy_quality=1.0):
        """
        Calculate position size with advanced risk management
        
        Args:
            symbol (str): Trading symbol
            entry_price (float): Entry price
            stop_loss_price (float): Stop loss price
            strategy_quality (float): Strategy quality factor (0.0-1.0)
            
        Returns:
            float: Position size
        """
        # Check if trading is allowed
        if not self.check_trading_allowed():
            return 0.0
            
        try:
            # Calculate risk adjustment
            risk_adjustment = self._calculate_risk_adjustment()
            
            # Apply risk adjustment and strategy quality
            adjusted_risk_pct = self.base_risk_pct * risk_adjustment * strategy_quality
            
            # Get account balance
            account_info = self.client.get_account_info()
            total_balance = float(account_info.get('totalWalletBalance', 0))
            
            # Calculate dollar risk (amount willing to lose)
            risk_amount = total_balance * (adjusted_risk_pct / 100)
            
            # Calculate risk per unit (in price)
            risk_per_unit = abs(entry_price - stop_loss_price)
            
            # Ensure minimum risk distance
            min_risk_distance = entry_price * 0.005  # Minimum 0.5% stop distance
            if risk_per_unit < min_risk_distance:
                risk_per_unit = min_risk_distance
                self.logger.warning(f"Stop loss too close, using minimum distance: {min_risk_distance}")
            
            # Calculate position size
            position_size = risk_amount / risk_per_unit
            
            # Check against maximum position size
            max_position_size_usd = total_balance * (self.max_position_pct / 100)
            max_position_units = max_position_size_usd / entry_price
            
            # Adjust for drawdown - reduce max position size in drawdown
            if self.current_drawdown_pct > 0:
                drawdown_factor = 1.0 - (self.current_drawdown_pct / (self.max_drawdown_pct * 2))
                drawdown_factor = max(drawdown_factor, 0.5)  # Don't go below 50%
                max_position_units *= drawdown_factor
            
            # Ensure position doesn't exceed maximum
            position_size = min(position_size, max_position_units)
            
            # Round position size to symbol precision
            quantity_precision = self.client.get_quantity_precision(symbol)
            position_size = math.floor(position_size / quantity_precision) * quantity_precision
            
            # Log position sizing information
            self.logger.info(f"Position size calculated: {position_size} units, "
                           f"Adjusted risk: {adjusted_risk_pct:.2f}%, "
                           f"Risk amount: ${risk_amount:.2f}, "
                           f"Risk per unit: ${risk_per_unit:.2f}")
            
            return position_size
            
        except Exception as e:
            self.logger.error(f"Error calculating position size: {e}")
            return 0.0
    
    def adjust_take_profit(self, side, entry_price, stop_loss_price, base_reward_risk=2.0):
        """
        Dynamically adjust take profit levels based on market conditions and trade history
        
        Args:
            side (str): Position side (LONG or SHORT)
            entry_price (float): Entry price
            stop_loss_price (float): Stop loss price
            base_reward_risk (float): Base reward:risk ratio
            
        Returns:
            float: Adjusted take profit price
        """
        # Calculate base take profit
        risk_amount = abs(entry_price - stop_loss_price)
        reward_amount = risk_amount * base_reward_risk
        
        # Adjust reward:risk based on win streak or consecutive losses
        adjusted_reward_risk = base_reward_risk
        
        if self.consecutive_losses >= 3:
            # After multiple losses, take profits sooner
            adjusted_reward_risk = base_reward_risk * 0.8
        elif self.win_streak >= 3:
            # During win streak, aim for larger profits
            adjusted_reward_risk = base_reward_risk * 1.2
        
        # Calculate adjusted reward amount
        adjusted_reward = risk_amount * adjusted_reward_risk
        
        # Calculate take profit price
        if side == 'LONG':
            take_profit = entry_price + adjusted_reward
        else:  # SHORT
            take_profit = entry_price - adjusted_reward
        
        return take_profit
    
    def update_trade_result(self, trade_id, profit_loss_pct):
        """
        Update trade result for tracking
        
        Args:
            trade_id (int): Trade ID
            profit_loss_pct (float): Profit/loss percentage
        """
        try:
            if profit_loss_pct > 0:
                self.winning_trades += 1
                self.win_streak += 1
                self.consecutive_losses = 0
            else:
                self.consecutive_losses += 1
                self.win_streak = 0
            
            self.total_trades += 1
            
            # Recalculate drawdown
            self._calculate_current_drawdown()
            
            self.logger.info(f"Updated trade result: P/L = {profit_loss_pct:.2f}%, "
                           f"Win streak: {self.win_streak}, "
                           f"Consecutive losses: {self.consecutive_losses}, "
                           f"Current drawdown: {self.current_drawdown_pct:.2f}%")
                           
        except Exception as e:
            self.logger.error(f"Error updating trade result: {e}")
    
    def get_trade_status(self):
        """
        Get trade status information
        
        Returns:
            dict: Trade status information
        """
        # First try to update the current status
        try:
            self._calculate_current_drawdown()
        except Exception as e:
            self.logger.warning(f"Could not update drawdown in get_trade_status: {e}")
        
        return {
            'trading_allowed': True,  # Default to true if we can't check
            'total_trades': self.total_trades,
            'winning_trades': self.winning_trades,
            'win_rate': (self.winning_trades / self.total_trades * 100) if self.total_trades > 0 else 0,
            'consecutive_losses': self.consecutive_losses,
            'current_drawdown_pct': self.current_drawdown_pct,
            'max_drawdown_reached': self.max_drawdown_reached,
            'risk_adjustment': self._calculate_risk_adjustment()
        }