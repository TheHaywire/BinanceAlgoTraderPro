"""
Binance API client wrapper for interacting with the Binance Futures API
"""

import logging
import time
import math
import pandas as pd
from binance.client import Client
from binance.exceptions import BinanceAPIException

class BinanceClient:
    """
    Wrapper for the Binance API client providing trading functionality
    """
    
    def __init__(self, api_key, api_secret, testnet=True):
        """
        Initialize Binance client
        
        Args:
            api_key (str): Binance API key
            api_secret (str): Binance API secret
            testnet (bool): Whether to use testnet or not
        """
        self.logger = logging.getLogger(__name__)
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet
        
        # Initialize Binance client
        self.client = Client(self.api_key, self.api_secret, testnet=self.testnet)
        
        # Cache exchange info
        self.exchange_info = self._get_exchange_info()
        self.symbol_info = {}  # Cache for symbol info
        
        self.logger.info(f"Initialized Binance client (testnet: {testnet})")
    
    def _get_exchange_info(self):
        """
        Get exchange information
        
        Returns:
            dict: Exchange information
        """
        try:
            return self.client.futures_exchange_info()
        except BinanceAPIException as e:
            self.logger.error(f"Error getting exchange info: {e}")
            return {}
    
    def get_symbol_info(self, symbol):
        """
        Get symbol information
        
        Args:
            symbol (str): Trading symbol
            
        Returns:
            dict: Symbol information
        """
        # Check cache first
        if symbol in self.symbol_info:
            return self.symbol_info[symbol]
            
        # Get from exchange info
        if self.exchange_info and 'symbols' in self.exchange_info:
            for sym_info in self.exchange_info['symbols']:
                if sym_info['symbol'] == symbol:
                    # Cache the info
                    self.symbol_info[symbol] = sym_info
                    return sym_info
                    
        self.logger.warning(f"Symbol info not found for {symbol}")
        return {}
    
    def get_account_info(self):
        """
        Get account information
        
        Returns:
            dict: Account information
        """
        try:
            return self.client.futures_account()
        except BinanceAPIException as e:
            self.logger.error(f"Error getting account info: {e}")
            return {}
    
    def get_balance(self):
        """
        Get USDT balance
        
        Returns:
            float: USDT balance
        """
        try:
            account_info = self.get_account_info()
            for asset in account_info.get('assets', []):
                if asset['asset'] == 'USDT':
                    return float(asset['walletBalance'])
            return 0
        except Exception as e:
            self.logger.error(f"Error getting balance: {e}")
            return 0
    
    def get_symbol_price(self, symbol):
        """
        Get current price for a symbol
        
        Args:
            symbol (str): Trading symbol
            
        Returns:
            float: Current price
        """
        try:
            ticker = self.client.futures_symbol_ticker(symbol=symbol)
            return float(ticker['price'])
        except BinanceAPIException as e:
            self.logger.error(f"Error getting symbol price: {e}")
            return 0
    
    def get_historical_klines(self, symbol, interval, limit=500):
        """
        Get historical klines (candlestick data)
        
        Args:
            symbol (str): Trading symbol
            interval (str): Kline interval (e.g., '15m', '1h')
            limit (int): Number of klines to retrieve
            
        Returns:
            pd.DataFrame: DataFrame with kline data
        """
        try:
            klines = self.client.futures_klines(
                symbol=symbol,
                interval=interval,
                limit=limit
            )
            
            # Convert to DataFrame
            df = pd.DataFrame(klines, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_asset_volume', 'number_of_trades',
                'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
            ])
            
            # Convert types
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df['open'] = df['open'].astype(float)
            df['high'] = df['high'].astype(float)
            df['low'] = df['low'].astype(float)
            df['close'] = df['close'].astype(float)
            df['volume'] = df['volume'].astype(float)
            
            return df
            
        except BinanceAPIException as e:
            self.logger.error(f"Error getting historical klines: {e}")
            return pd.DataFrame()
    
    def create_order(self, symbol, side, order_type, quantity=None, price=None, 
                     stop_price=None, reduce_only=False, close_position=False):
        """
        Create a new order
        
        Args:
            symbol (str): Trading symbol
            side (str): Order side (BUY or SELL)
            order_type (str): Order type (MARKET, LIMIT, STOP, etc.)
            quantity (float, optional): Order quantity
            price (float, optional): Order price
            stop_price (float, optional): Stop price
            reduce_only (bool): If the order should only reduce position
            close_position (bool): If the order should close the position
            
        Returns:
            dict: Order response
        """
        try:
            params = {
                'symbol': symbol,
                'side': side,
                'type': order_type,
                'reduceOnly': 'true' if reduce_only else 'false',
                'newOrderRespType': 'RESULT'  # Return full order result info
            }
            
            # Set quantity if provided
            if quantity is not None:
                quantity = self.round_step_size(quantity, self.get_quantity_precision(symbol))
                params['quantity'] = quantity
                
            # Set price if provided (required for LIMIT orders)
            if price is not None:
                params['price'] = price
                
            # Set stop price if provided (required for STOP/TAKE_PROFIT orders)
            if stop_price is not None:
                params['stopPrice'] = stop_price
                
            # Set closePosition if requested
            if close_position:
                params['closePosition'] = 'true'
                
            # Create the order
            response = self.client.futures_create_order(**params)
            
            self.logger.info(f"Created order: {symbol} {side} {order_type}, Quantity: {quantity}, Price: {price}")
            return response
            
        except BinanceAPIException as e:
            self.logger.error(f"Error creating order: {e}")
            return {}
    
    def get_open_orders(self, symbol=None):
        """
        Get open orders
        
        Args:
            symbol (str, optional): Trading symbol
            
        Returns:
            list: List of open orders
        """
        try:
            if symbol:
                return self.client.futures_get_open_orders(symbol=symbol)
            else:
                return self.client.futures_get_open_orders()
        except BinanceAPIException as e:
            self.logger.error(f"Error getting open orders: {e}")
            return []
    
    def get_position(self, symbol):
        """
        Get current position for a symbol
        
        Args:
            symbol (str): Trading symbol
            
        Returns:
            dict: Position information
        """
        try:
            positions = self.client.futures_position_information()
            for position in positions:
                if position['symbol'] == symbol:
                    return position
            return {}
        except BinanceAPIException as e:
            self.logger.error(f"Error getting position: {e}")
            return {}
    
    def get_positions(self):
        """
        Get all open positions
        
        Returns:
            list: List of positions
        """
        try:
            positions = self.client.futures_position_information()
            return [p for p in positions if float(p['positionAmt']) != 0]
        except BinanceAPIException as e:
            self.logger.error(f"Error getting positions: {e}")
            return []
    
    def cancel_all_orders(self, symbol):
        """
        Cancel all open orders for a symbol
        
        Args:
            symbol (str): Trading symbol
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            result = self.client.futures_cancel_all_open_orders(symbol=symbol)
            if result.get('code') == 200:
                self.logger.info(f"Cancelled all orders for {symbol}")
                return True
            return False
        except BinanceAPIException as e:
            self.logger.error(f"Error cancelling orders: {e}")
            return False
    
    def set_leverage(self, symbol, leverage):
        """
        Set leverage for a symbol
        
        Args:
            symbol (str): Trading symbol
            leverage (int): Leverage (1-125)
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            result = self.client.futures_change_leverage(
                symbol=symbol,
                leverage=leverage
            )
            if 'leverage' in result and result['leverage'] == leverage:
                return True
            return False
        except BinanceAPIException as e:
            self.logger.error(f"Error setting leverage: {e}")
            return False
    
    def get_quantity_precision(self, symbol):
        """
        Get the quantity precision for a symbol
        
        Args:
            symbol (str): Trading symbol
            
        Returns:
            float: Step size
        """
        try:
            symbol_info = self.get_symbol_info(symbol)
            
            # Find quantity filter
            for f in symbol_info.get('filters', []):
                if f['filterType'] == 'LOT_SIZE':
                    return float(f['stepSize'])
                    
            return 0.001  # Default to 3 decimal places
            
        except Exception as e:
            self.logger.error(f"Error getting quantity precision: {e}")
            return 0.001
    
    def round_step_size(self, quantity, step_size):
        """
        Round quantity to step size
        
        Args:
            quantity (float): Quantity to round
            step_size (float): Step size
            
        Returns:
            float: Rounded quantity
        """
        if step_size == 0:
            return quantity
            
        precision = int(round(-math.log(step_size, 10), 0))
        return round(quantity - (quantity % step_size), precision)
    
    def get_funding_rate(self, symbol):
        """
        Get current funding rate for a symbol
        
        Args:
            symbol (str): Trading symbol
            
        Returns:
            float: Current funding rate
        """
        try:
            funding_info = self.client.futures_funding_rate(symbol=symbol, limit=1)
            if funding_info:
                return float(funding_info[0]['fundingRate'])
            return 0
        except BinanceAPIException as e:
            self.logger.error(f"Error getting funding rate: {e}")
            return 0
    
    def get_mark_price(self, symbol):
        """
        Get mark price for a symbol
        
        Args:
            symbol (str): Trading symbol
            
        Returns:
            float: Mark price
        """
        try:
            mark_price = self.client.futures_mark_price(symbol=symbol)
            return float(mark_price['markPrice'])
        except BinanceAPIException as e:
            self.logger.error(f"Error getting mark price: {e}")
            return 0