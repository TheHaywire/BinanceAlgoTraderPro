"""
Position Sizer module for calculating optimal position sizes based on account risk parameters
"""

import logging
import math

class PositionSizer:
    """
    Position sizer class for calculating optimal position sizes
    based on account risk parameters
    """
    
    def __init__(self, client, default_risk_pct=1.0, max_position_pct=5.0):
        """
        Initialize position sizer
        
        Args:
            client (BinanceClient): Binance client instance
            default_risk_pct (float): Default risk percentage per trade
            max_position_pct (float): Maximum position size as percentage of account
        """
        self.client = client
        self.default_risk_pct = default_risk_pct
        self.max_position_pct = max_position_pct
        
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"Initialized Position Sizer with default risk: {default_risk_pct}%, "
                       f"max position size: {max_position_pct}%")
    
    def calculate_position_size(self, symbol, entry_price, stop_loss_price, risk_pct=None):
        """
        Calculate position size based on risk parameters
        
        Args:
            symbol (str): Trading symbol
            entry_price (float): Entry price
            stop_loss_price (float): Stop loss price
            risk_pct (float, optional): Risk percentage for this trade
            
        Returns:
            float: Position size in base currency
        """
        # Use default risk percentage if not provided
        if risk_pct is None:
            risk_pct = self.default_risk_pct
            
        try:
            # Get account balance
            account_info = self.client.get_account_info()
            
            if 'totalWalletBalance' not in account_info:
                self.logger.error("Unable to retrieve wallet balance")
                return 0
                
            total_balance = float(account_info['totalWalletBalance'])
            
            # Calculate dollar risk amount
            risk_amount = total_balance * (risk_pct / 100)
            
            # Calculate risk per unit (absolute distance to stop loss)
            if entry_price > stop_loss_price:  # Long position
                risk_per_unit = entry_price - stop_loss_price
            else:  # Short position
                risk_per_unit = stop_loss_price - entry_price
                
            # If risk per unit is too small, use a minimum value to prevent excessive leverage
            if risk_per_unit < entry_price * 0.005:  # Minimum 0.5% stop distance
                risk_per_unit = entry_price * 0.005
                self.logger.warning(f"Stop loss too close to entry, using minimum distance of 0.5%")
                
            # Calculate position size
            position_size = risk_amount / risk_per_unit
            
            # Apply maximum position size limit
            max_position_size = total_balance * (self.max_position_pct / 100) / entry_price
            position_size = min(position_size, max_position_size)
            
            # Round position size to symbol precision
            quantity_precision = self._get_quantity_precision(symbol)
            position_size = self._round_down(position_size, quantity_precision)
            
            # Ensure position size is above minimum
            min_notional = 5.0  # Minimum order value in USDT (typical for Binance Futures)
            min_position = min_notional / entry_price
            
            if position_size < min_position:
                self.logger.warning(f"Calculated position size ({position_size}) is below minimum, using {min_position}")
                position_size = min_position
                
            self.logger.info(f"Calculated position size for {symbol}: {position_size} units "
                           f"(value: ${position_size * entry_price:.2f}, risk: {risk_pct}%)")
                           
            return position_size
            
        except Exception as e:
            self.logger.error(f"Error calculating position size: {e}")
            return 0
    
    def _get_quantity_precision(self, symbol):
        """
        Get the quantity precision for a symbol
        
        Args:
            symbol (str): Trading symbol
            
        Returns:
            int: Decimal precision for quantity
        """
        try:
            precision = self.client.get_quantity_precision(symbol)
            return precision
        except Exception as e:
            self.logger.error(f"Error getting quantity precision: {e}")
            return 0.001  # Default to 3 decimal places
            
    def _round_down(self, value, precision):
        """
        Round down to the specified precision
        
        Args:
            value (float): Value to round
            precision (float): Precision step size
            
        Returns:
            float: Rounded value
        """
        return math.floor(value / precision) * precision
    
    def calculate_kelly_position_size(self, symbol, entry_price, stop_loss_price, 
                                    take_profit_price, win_rate, kelly_fraction=0.5):
        """
        Calculate position size using Kelly Criterion
        
        Args:
            symbol (str): Trading symbol
            entry_price (float): Entry price
            stop_loss_price (float): Stop loss price
            take_profit_price (float): Take profit price
            win_rate (float): Historical win rate (0-1)
            kelly_fraction (float): Fraction of Kelly to use (0-1)
            
        Returns:
            float: Position size in base currency
        """
        try:
            # Calculate potential profit and loss percentages
            if entry_price > stop_loss_price:  # Long position
                loss_pct = (entry_price - stop_loss_price) / entry_price
                profit_pct = (take_profit_price - entry_price) / entry_price
            else:  # Short position
                loss_pct = (stop_loss_price - entry_price) / entry_price
                profit_pct = (entry_price - take_profit_price) / entry_price
                
            # Calculate Kelly percentage
            # f = (bp - q) / b where b = odds, p = win rate, q = 1 - p
            b = profit_pct / loss_pct  # Odds (profit/loss ratio)
            p = win_rate
            q = 1 - p
            
            kelly_pct = (b * p - q) / b
            
            # Apply Kelly fraction to avoid over-betting
            kelly_pct = kelly_pct * kelly_fraction
            
            # Cap Kelly percentage at max_position_pct
            kelly_pct = min(kelly_pct, self.max_position_pct / 100)
            
            # Ensure Kelly percentage is positive
            if kelly_pct <= 0:
                self.logger.warning(f"Kelly calculation resulted in zero or negative position size, "
                                  f"using default risk percentage")
                return self.calculate_position_size(symbol, entry_price, stop_loss_price)
                
            # Calculate position size based on Kelly percentage
            account_info = self.client.get_account_info()
            total_balance = float(account_info['totalWalletBalance'])
            
            position_value = total_balance * kelly_pct
            position_size = position_value / entry_price
            
            # Round position size
            quantity_precision = self._get_quantity_precision(symbol)
            position_size = self._round_down(position_size, quantity_precision)
            
            self.logger.info(f"Calculated Kelly position size for {symbol}: {position_size} units "
                           f"(Kelly %: {kelly_pct * 100:.2f}%, win rate: {win_rate * 100:.1f}%)")
                           
            return position_size
            
        except Exception as e:
            self.logger.error(f"Error calculating Kelly position size: {e}")
            return self.calculate_position_size(symbol, entry_price, stop_loss_price)