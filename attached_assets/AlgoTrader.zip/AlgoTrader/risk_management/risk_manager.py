"""
Risk Manager module for managing trading risk and position sizing
"""

import logging
import math
from datetime import datetime

class RiskManager:
    """
    Risk manager class for handling all risk-related operations
    """
    
    def __init__(self, client, max_position_size_pct=5.0, max_loss_pct=2.0, 
                 max_exposure_pct=25.0, min_reward_risk_ratio=1.5):
        """
        Initialize risk manager
        
        Args:
            client (BinanceClient): Binance client instance
            max_position_size_pct (float): Maximum position size as percentage of account
            max_loss_pct (float): Maximum loss percentage per trade
            max_exposure_pct (float): Maximum total exposure percentage
            min_reward_risk_ratio (float): Minimum reward:risk ratio for trades
        """
        self.client = client
        self.max_position_size_pct = max_position_size_pct
        self.max_loss_pct = max_loss_pct
        self.max_exposure_pct = max_exposure_pct
        self.min_reward_risk_ratio = min_reward_risk_ratio
        
        # State variables
        self.current_exposure_pct = 0
        self.win_streak = 0
        self.loss_streak = 0
        self.consecutive_losses = 0
        self.wins = 0
        self.losses = 0
        
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"Initialized Risk Manager with max position size: {max_position_size_pct}%, "
                       f"max loss: {max_loss_pct}%, max exposure: {max_exposure_pct}%")
        
    def calculate_position_size(self, symbol, entry_price, stop_loss_price, risk_pct=None):
        """
        Calculate position size based on risk parameters
        
        Args:
            symbol (str): Trading symbol
            entry_price (float): Entry price
            stop_loss_price (float): Stop loss price
            risk_pct (float, optional): Risk percentage for this trade
            
        Returns:
            float: Position size
        """
        # Use default risk percentage if not provided
        if risk_pct is None:
            risk_pct = self.max_loss_pct
            
            # Adjust risk based on win/loss streaks
            if self.win_streak >= 3:
                # Increase risk after winning streak
                risk_pct = min(risk_pct * 1.5, self.max_loss_pct * 2)
            elif self.consecutive_losses >= 2:
                # Reduce risk after consecutive losses
                risk_pct = risk_pct * 0.7
                
        try:
            # Get account balance
            account_info = self.client.get_account_info()
            total_balance = float(account_info['totalWalletBalance'])
            available_balance = float(account_info['availableBalance'])
            
            # Calculate dollar risk amount
            risk_amount = total_balance * (risk_pct / 100)
            
            # Calculate distance to stop loss as percentage
            if entry_price >= stop_loss_price:  # Long position
                risk_distance_pct = (entry_price - stop_loss_price) / entry_price * 100
            else:  # Short position
                risk_distance_pct = (stop_loss_price - entry_price) / entry_price * 100
                
            # Calculate position size in USD
            position_size_usd = risk_amount / (risk_distance_pct / 100)
            
            # Limit position size to max percentage of account
            max_position_usd = total_balance * (self.max_position_size_pct / 100)
            position_size_usd = min(position_size_usd, max_position_usd)
            
            # Consider current exposure
            current_exposure = self._calculate_current_exposure()
            remaining_exposure = total_balance * (self.max_exposure_pct / 100) - current_exposure
            
            if remaining_exposure <= 0:
                self.logger.warning(f"Maximum exposure reached ({self.max_exposure_pct}%). Cannot open new positions.")
                return 0
                
            position_size_usd = min(position_size_usd, remaining_exposure)
            
            # Convert position size to quantity
            quantity = position_size_usd / entry_price
            
            # Round quantity based on symbol's quantity precision
            quantity_precision = self.client.get_quantity_precision(symbol)
            quantity = self.client.round_step_size(quantity, quantity_precision)
            
            self.logger.info(f"Calculated position size for {symbol}: {quantity} (${position_size_usd:.2f}), "
                           f"Risk: {risk_pct:.2f}%, Distance to SL: {risk_distance_pct:.2f}%")
                           
            return quantity
            
        except Exception as e:
            self.logger.error(f"Error calculating position size: {e}")
            return 0
    
    def validate_trade(self, symbol, side, entry_price, stop_loss, take_profit):
        """
        Validate a potential trade against risk parameters
        
        Args:
            symbol (str): Trading symbol
            side (str): Trade side (LONG or SHORT)
            entry_price (float): Entry price
            stop_loss (float): Stop loss price
            take_profit (float): Take profit price
            
        Returns:
            bool: True if trade is valid, False otherwise
        """
        try:
            # Calculate reward:risk ratio
            if side == 'LONG':
                risk = entry_price - stop_loss
                reward = take_profit - entry_price
            else:  # SHORT
                risk = stop_loss - entry_price
                reward = entry_price - take_profit
                
            reward_risk_ratio = reward / risk if risk > 0 else 0
            
            # Check if reward:risk ratio is acceptable
            if reward_risk_ratio < self.min_reward_risk_ratio:
                self.logger.warning(f"Trade validation failed: Reward:risk ratio ({reward_risk_ratio:.2f}) "
                                  f"below minimum ({self.min_reward_risk_ratio})")
                return False
                
            # Check if current exposure allows new trades
            current_exposure = self._calculate_current_exposure()
            account_info = self.client.get_account_info()
            total_balance = float(account_info['totalWalletBalance'])
            
            if current_exposure >= total_balance * (self.max_exposure_pct / 100):
                self.logger.warning(f"Trade validation failed: Maximum exposure reached ({self.max_exposure_pct}%)")
                return False
                
            # Check if stop loss distance is reasonable (at least 0.5% from entry)
            sl_distance_pct = abs(entry_price - stop_loss) / entry_price * 100
            if sl_distance_pct < 0.5:
                self.logger.warning(f"Trade validation failed: Stop loss too close to entry price ({sl_distance_pct:.2f}%)")
                return False
                
            # All checks passed
            self.logger.info(f"Trade validation passed for {symbol} {side}: R:R = {reward_risk_ratio:.2f}, "
                           f"SL distance = {sl_distance_pct:.2f}%")
            return True
            
        except Exception as e:
            self.logger.error(f"Error validating trade: {e}")
            return False
    
    def update_trade_result(self, profit_loss_pct):
        """
        Update trade results for tracking
        
        Args:
            profit_loss_pct (float): Profit/loss percentage
        """
        if profit_loss_pct > 0:
            self.wins += 1
            self.win_streak += 1
            self.loss_streak = 0
            self.consecutive_losses = 0
        else:
            self.losses += 1
            self.loss_streak += 1
            self.win_streak = 0
            self.consecutive_losses += 1
            
        self.logger.info(f"Updated trade result: P/L = {profit_loss_pct:.2f}%, "
                       f"Win streak: {self.win_streak}, Loss streak: {self.loss_streak}")
    
    def _calculate_current_exposure(self):
        """
        Calculate current exposure as percentage of account
        
        Returns:
            float: Current exposure in USD
        """
        try:
            # Get account information
            account_info = self.client.get_account_info()
            total_balance = float(account_info['totalWalletBalance'])
            
            # Get all positions
            positions = self.client.get_positions()
            
            # Calculate total exposure
            total_exposure = sum(abs(float(pos['positionAmt']) * float(pos['entryPrice'])) 
                               for pos in positions if float(pos['positionAmt']) != 0)
            
            # Update current exposure percentage
            self.current_exposure_pct = (total_exposure / total_balance) * 100 if total_balance > 0 else 0
            
            return total_exposure
            
        except Exception as e:
            self.logger.error(f"Error calculating current exposure: {e}")
            return 0
    
    def get_stats(self):
        """
        Get risk manager statistics
        
        Returns:
            dict: Risk manager statistics
        """
        return {
            'current_exposure_pct': self.current_exposure_pct,
            'win_streak': self.win_streak,
            'loss_streak': self.loss_streak,
            'consecutive_losses': self.consecutive_losses,
            'win_count': self.wins,
            'loss_count': self.losses,
            'win_rate': self.wins / (self.wins + self.losses) * 100 if (self.wins + self.losses) > 0 else 0
        }