from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Trade(db.Model):
    """Model for storing trade information"""
    id = db.Column(db.Integer, primary_key=True)
    symbol = db.Column(db.String(20), nullable=False)
    strategy = db.Column(db.String(50), nullable=False)
    side = db.Column(db.String(10), nullable=False)  # LONG or SHORT
    entry_price = db.Column(db.Float, nullable=False)
    exit_price = db.Column(db.Float, nullable=True)
    quantity = db.Column(db.Float, nullable=False)
    stop_loss = db.Column(db.Float, nullable=False)
    take_profit = db.Column(db.Float, nullable=False)
    entry_time = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    exit_time = db.Column(db.DateTime, nullable=True)
    exit_reason = db.Column(db.String(50), nullable=True)
    profit_loss = db.Column(db.Float, nullable=True)  # In quote currency
    profit_loss_percent = db.Column(db.Float, nullable=True)  # As percentage
    status = db.Column(db.String(20), nullable=False, default='OPEN')  # OPEN, CLOSED
    
    def __repr__(self):
        return f"<Trade {self.id} {self.symbol} {self.side} {self.status}>"
        
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'symbol': self.symbol,
            'strategy': self.strategy,
            'side': self.side,
            'entry_price': self.entry_price,
            'exit_price': self.exit_price,
            'quantity': self.quantity,
            'stop_loss': self.stop_loss,
            'take_profit': self.take_profit,
            'entry_time': self.entry_time.isoformat() if self.entry_time else None,
            'exit_time': self.exit_time.isoformat() if self.exit_time else None,
            'exit_reason': self.exit_reason,
            'profit_loss': self.profit_loss,
            'profit_loss_percent': self.profit_loss_percent,
            'status': self.status
        }

class DailyPerformance(db.Model):
    """Model for storing daily performance metrics"""
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, unique=True)
    starting_balance = db.Column(db.Float, nullable=False)
    ending_balance = db.Column(db.Float, nullable=False)
    profit_loss = db.Column(db.Float, nullable=False)
    profit_loss_percent = db.Column(db.Float, nullable=False)
    trades_count = db.Column(db.Integer, nullable=False)
    winning_trades = db.Column(db.Integer, nullable=False)
    losing_trades = db.Column(db.Integer, nullable=False)
    
    def __repr__(self):
        return f"<DailyPerformance {self.date} P/L: {self.profit_loss_percent}%>"
        
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'date': self.date.isoformat(),
            'starting_balance': self.starting_balance,
            'ending_balance': self.ending_balance,
            'profit_loss': self.profit_loss,
            'profit_loss_percent': self.profit_loss_percent,
            'trades_count': self.trades_count,
            'winning_trades': self.winning_trades,
            'losing_trades': self.losing_trades,
            'win_rate': (self.winning_trades / self.trades_count * 100) if self.trades_count > 0 else 0
        }

class StrategyPerformance(db.Model):
    """Model for storing strategy-specific performance metrics"""
    id = db.Column(db.Integer, primary_key=True)
    strategy = db.Column(db.String(50), nullable=False)
    symbol = db.Column(db.String(20), nullable=False)
    period_start = db.Column(db.DateTime, nullable=False)
    period_end = db.Column(db.DateTime, nullable=False)
    trades_count = db.Column(db.Integer, nullable=False)
    winning_trades = db.Column(db.Integer, nullable=False)
    losing_trades = db.Column(db.Integer, nullable=False)
    profit_loss = db.Column(db.Float, nullable=False)
    profit_loss_percent = db.Column(db.Float, nullable=False)
    max_drawdown = db.Column(db.Float, nullable=False)
    sharpe_ratio = db.Column(db.Float, nullable=True)
    
    __table_args__ = (
        db.UniqueConstraint('strategy', 'symbol', 'period_start', 'period_end', name='unique_strategy_period'),
    )
    
    def __repr__(self):
        return f"<StrategyPerformance {self.strategy} {self.symbol} P/L: {self.profit_loss_percent}%>"
        
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'strategy': self.strategy,
            'symbol': self.symbol,
            'period_start': self.period_start.isoformat(),
            'period_end': self.period_end.isoformat(),
            'trades_count': self.trades_count,
            'winning_trades': self.winning_trades,
            'losing_trades': self.losing_trades,
            'win_rate': (self.winning_trades / self.trades_count * 100) if self.trades_count > 0 else 0,
            'profit_loss': self.profit_loss,
            'profit_loss_percent': self.profit_loss_percent,
            'max_drawdown': self.max_drawdown,
            'sharpe_ratio': self.sharpe_ratio
        }

class MarketData(db.Model):
    """Model for storing relevant market data"""
    id = db.Column(db.Integer, primary_key=True)
    symbol = db.Column(db.String(20), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False)
    open = db.Column(db.Float, nullable=False)
    high = db.Column(db.Float, nullable=False)
    low = db.Column(db.Float, nullable=False)
    close = db.Column(db.Float, nullable=False)
    volume = db.Column(db.Float, nullable=False)
    funding_rate = db.Column(db.Float, nullable=True)
    
    __table_args__ = (
        db.UniqueConstraint('symbol', 'timestamp', name='unique_symbol_timestamp'),
    )
    
    def __repr__(self):
        return f"<MarketData {self.symbol} {self.timestamp} Close: {self.close}>"
        
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'symbol': self.symbol,
            'timestamp': self.timestamp.isoformat(),
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close,
            'volume': self.volume,
            'funding_rate': self.funding_rate
        }

class SystemMetrics(db.Model):
    """Model for storing system performance metrics"""
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    cpu_usage = db.Column(db.Float, nullable=True)  # Percentage
    memory_usage = db.Column(db.Float, nullable=True)  # MB
    network_latency = db.Column(db.Float, nullable=True)  # ms
    api_calls_count = db.Column(db.Integer, nullable=True)
    errors_count = db.Column(db.Integer, nullable=True)
    active_strategies = db.Column(db.Integer, nullable=True)
    
    def __repr__(self):
        return f"<SystemMetrics {self.timestamp}>"
        
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'timestamp': self.timestamp.isoformat(),
            'cpu_usage': self.cpu_usage,
            'memory_usage': self.memory_usage,
            'network_latency': self.network_latency,
            'api_calls_count': self.api_calls_count,
            'errors_count': self.errors_count,
            'active_strategies': self.active_strategies
        }