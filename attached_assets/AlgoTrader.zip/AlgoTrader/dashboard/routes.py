"""
Routes for the trading bot dashboard
"""

import os
import json
from datetime import datetime, timedelta
from flask import render_template, jsonify, request, redirect, url_for
from models import db, Trade, DailyPerformance, StrategyPerformance, MarketData, SystemMetrics

def init_routes(app, bot_state, trading_components):
    """Initialize routes for the Flask app"""
    
    @app.route('/')
    def index():
        """Dashboard homepage"""
        return render_template('dashboard.html', bot_state=bot_state)
    
    @app.route('/api/status')
    def api_status():
        """API endpoint to get bot status"""
        # Update account balance if bot is connected
        if bot_state["connected"] and trading_components:
            try:
                account_info = trading_components["client"].get_account_info()
                bot_state["account_balance"] = float(account_info.get('totalWalletBalance', 0))
                
                # Update active trades count
                bot_state["active_trades"] = Trade.query.filter_by(status='OPEN').count()
                bot_state["total_trades"] = Trade.query.count()
                
                # Calculate daily P&L
                today = datetime.utcnow().date()
                daily_perf = DailyPerformance.query.filter_by(date=today).first()
                if daily_perf:
                    bot_state["daily_pnl"] = daily_perf.profit_loss
                
                # Update last update time
                bot_state["last_update"] = datetime.utcnow().isoformat()
                
                # Get latest risk status if advanced risk manager is available
                if trading_components.get("advanced_risk_manager"):
                    risk_status = trading_components["advanced_risk_manager"].get_trade_status()
                    bot_state["trading_allowed"] = risk_status["trading_allowed"]
                    bot_state["current_drawdown"] = risk_status["current_drawdown_pct"]
                
            except Exception as e:
                print(f"Error updating bot status: {e}")
        
        return jsonify(bot_state)
    
    @app.route('/api/trades')
    def api_trades():
        """API endpoint to get trade history"""
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        
        # Get trades with pagination
        trades_pagination = Trade.query.order_by(Trade.entry_time.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        trades = [trade.to_dict() for trade in trades_pagination.items]
        
        return jsonify({
            'trades': trades,
            'total': trades_pagination.total,
            'pages': trades_pagination.pages,
            'current_page': page
        })
    
    @app.route('/api/performance')
    def api_performance():
        """API endpoint to get performance data"""
        period = request.args.get('period', 'day')
        
        try:
            if period == 'day':
                # Get daily performance for the last 30 days
                start_date = datetime.utcnow() - timedelta(days=30)
                daily_perf = DailyPerformance.query.filter(
                    DailyPerformance.date >= start_date.date()
                ).order_by(DailyPerformance.date).all()
                
                data = [perf.to_dict() for perf in daily_perf]
            
            elif period == 'strategy':
                # Get strategy performance
                strategy_perf = StrategyPerformance.query.order_by(
                    StrategyPerformance.period_end.desc()
                ).all()
                
                data = [perf.to_dict() for perf in strategy_perf]
            
            elif period == 'advanced':
                # Get advanced performance metrics from the performance monitor
                if trading_components and trading_components.get("performance_monitor"):
                    data = trading_components["performance_monitor"].get_performance_report()
                else:
                    data = {"message": "Performance monitor not available"}
            else:
                data = []
                
            return jsonify(data)
        except Exception as e:
            app.logger.error(f"Error in performance data API: {e}")
            return jsonify({"error": str(e)})
    
    @app.route('/api/market_data')
    def api_market_data():
        """API endpoint to get market data"""
        symbol = request.args.get('symbol', 'BTCUSDT')
        limit = request.args.get('limit', 100, type=int)
        
        # Get latest market data
        market_data = MarketData.query.filter_by(symbol=symbol).order_by(
            MarketData.timestamp.desc()
        ).limit(limit).all()
        
        # Reverse to get chronological order
        market_data = market_data[::-1]
        
        data = [md.to_dict() for md in market_data]
        
        return jsonify(data)
    
    @app.route('/api/system')
    def api_system():
        """API endpoint to get system metrics"""
        hours = request.args.get('hours', 24, type=int)
        
        # Get system metrics for the specified time period
        start_time = datetime.utcnow() - timedelta(hours=hours)
        metrics = SystemMetrics.query.filter(
            SystemMetrics.timestamp >= start_time
        ).order_by(SystemMetrics.timestamp).all()
        
        data = [metric.to_dict() for metric in metrics]
        
        return jsonify(data)
    
    @app.route('/api/strategy_allocation')
    def api_strategy_allocation():
        """API endpoint to get strategy allocation"""
        if trading_components and trading_components.get("strategy_allocator"):
            allocation = trading_components["strategy_allocator"].allocation
            
            # Format for chart display
            chart_data = [
                {"strategy": strategy, "allocation": value}
                for strategy, value in allocation.items()
            ]
            
            return jsonify(chart_data)
        else:
            return jsonify([{"strategy": "MomentumBreakoutStrategy", "allocation": 100}])
    
    @app.route('/api/risk_status')
    def api_risk_status():
        """API endpoint to get risk management status"""
        if trading_components and trading_components.get("advanced_risk_manager"):
            risk_status = trading_components["advanced_risk_manager"].get_trade_status()
            return jsonify(risk_status)
        else:
            return jsonify({
                "trading_allowed": bot_state.get("trading_allowed", True),
                "current_drawdown_pct": bot_state.get("current_drawdown", 0),
                "max_drawdown_reached": False,
                "consecutive_losses": 0
            })
    
    @app.route('/api/start_bot', methods=['POST'])
    def api_start_bot():
        """API endpoint to start the trading bot"""
        if not bot_state["running"] and trading_components:
            try:
                # Start the WebSocket manager
                if trading_components.get("websocket_manager"):
                    trading_components["websocket_manager"].start()
                    
                bot_state["running"] = True
                return jsonify({"success": True, "message": "Bot started successfully"})
            except Exception as e:
                return jsonify({"success": False, "message": f"Error starting bot: {e}"})
        else:
            return jsonify({"success": False, "message": "Bot is already running or not initialized"})
    
    @app.route('/api/stop_bot', methods=['POST'])
    def api_stop_bot():
        """API endpoint to stop the trading bot"""
        if bot_state["running"] and trading_components:
            try:
                # Stop the WebSocket manager
                if trading_components.get("websocket_manager"):
                    trading_components["websocket_manager"].stop()
                    
                bot_state["running"] = False
                return jsonify({"success": True, "message": "Bot stopped successfully"})
            except Exception as e:
                return jsonify({"success": False, "message": f"Error stopping bot: {e}"})
        else:
            return jsonify({"success": False, "message": "Bot is not running or not initialized"})
    
    @app.route('/api/market_regime')
    def api_market_regime():
        """API endpoint to get market regime data"""
        if trading_components and trading_components.get("strategy_allocator"):
            # Update market regime before returning
            trading_components["strategy_allocator"].update_market_regime()
            
            # Get market regime
            market_regime = trading_components["strategy_allocator"].market_regime
            return jsonify(market_regime)
        else:
            return jsonify({
                "is_trending": False,
                "is_volatile": False,
                "correlation_level": "low",
                "trend_direction": "neutral"
            })
    
    @app.route('/api/active_trades')
    def api_active_trades():
        """API endpoint to get active trade details"""
        if not trading_components or not trading_components.get("trade_monitor"):
            return jsonify({"error": "Trade monitor not initialized"})
        
        # Update and get active trades
        active_trades = trading_components["trade_monitor"].update_active_trades()
        
        # Return as list for easier consumption by frontend
        active_trades_list = list(active_trades.values())
        
        return jsonify(active_trades_list)
    
    @app.route('/api/active_trades/<int:trade_id>')
    def api_active_trade_detail(trade_id):
        """API endpoint to get detailed information about a specific active trade"""
        if not trading_components or not trading_components.get("trade_monitor"):
            return jsonify({"error": "Trade monitor not initialized"})
        
        # Update active trades first
        trading_components["trade_monitor"].update_active_trades()
        
        # Get specific trade
        trade = trading_components["trade_monitor"].active_trades.get(trade_id)
        if not trade:
            return jsonify({"error": "Trade not found"})
        
        # Get position timeline
        timeline = trading_components["trade_monitor"].get_position_timeline(trade_id)
        
        # Get execution analytics
        execution = trading_components["trade_monitor"].get_execution_analytics(trade_id)
        
        # Combine all data
        result = {
            "trade": trade,
            "timeline": timeline,
            "execution": execution
        }
        
        return jsonify(result)
    
    @app.route('/api/trade_summary')
    def api_trade_summary():
        """API endpoint to get a summary of all active trades"""
        if not trading_components or not trading_components.get("trade_monitor"):
            return jsonify({"error": "Trade monitor not initialized"})
        
        # Update active trades first
        trading_components["trade_monitor"].update_active_trades()
        
        # Get summary
        summary = trading_components["trade_monitor"].get_active_trade_summary()
        
        # Get risk exposure
        risk = trading_components["trade_monitor"].get_account_risk_exposure()
        
        # Combine results
        result = {
            "summary": summary,
            "risk": risk
        }
        
        return jsonify(result)
    
    @app.route('/api/opportunities')
    def api_opportunities():
        """API endpoint to get detected trading opportunities"""
        if not trading_components or not trading_components.get("opportunity_detector"):
            return jsonify({"error": "Opportunity detector not initialized"})
        
        # Get parameters
        symbols = request.args.get('symbols')
        symbols = symbols.split(',') if symbols else None
        
        timeframes = request.args.get('timeframes', '15m,1h,4h')
        timeframes = timeframes.split(',')
        
        # Scan for opportunities
        opportunities = trading_components["opportunity_detector"].scan_all_markets(
            symbols=symbols,
            timeframes=timeframes
        )
        
        return jsonify(opportunities)
    
    @app.route('/api/opportunities/top')
    def api_top_opportunities():
        """API endpoint to get top trading opportunities"""
        if not trading_components or not trading_components.get("opportunity_detector"):
            return jsonify({"error": "Opportunity detector not initialized"})
        
        # Get number of opportunities to return
        limit = request.args.get('limit', 10, type=int)
        
        # Get top opportunities
        opportunities = trading_components["opportunity_detector"].get_top_opportunities(n=limit)
        
        return jsonify(opportunities)
    
    @app.route('/api/watchlist', methods=['GET'])
    def api_get_watchlist():
        """API endpoint to get the opportunity watchlist"""
        if not trading_components or not trading_components.get("opportunity_detector"):
            return jsonify({"error": "Opportunity detector not initialized"})
        
        # Get watchlist
        watchlist = trading_components["opportunity_detector"].get_watchlist()
        
        return jsonify(watchlist)
    
    @app.route('/api/watchlist/add', methods=['POST'])
    def api_add_to_watchlist():
        """API endpoint to add an opportunity to the watchlist"""
        if not trading_components or not trading_components.get("opportunity_detector"):
            return jsonify({"error": "Opportunity detector not initialized"})
        
        # Get opportunity ID and notes from request
        data = request.json
        opportunity_id = data.get('opportunity_id')
        notes = data.get('notes')
        
        if not opportunity_id:
            return jsonify({"error": "Opportunity ID is required"})
        
        # Add to watchlist
        result = trading_components["opportunity_detector"].add_to_watchlist(
            opportunity_id=opportunity_id,
            notes=notes
        )
        
        return jsonify(result)
    
    @app.route('/api/watchlist/remove', methods=['POST'])
    def api_remove_from_watchlist():
        """API endpoint to remove an opportunity from the watchlist"""
        if not trading_components or not trading_components.get("opportunity_detector"):
            return jsonify({"error": "Opportunity detector not initialized"})
        
        # Get opportunity ID from request
        data = request.json
        opportunity_id = data.get('opportunity_id')
        
        if not opportunity_id:
            return jsonify({"error": "Opportunity ID is required"})
        
        # Remove from watchlist
        result = trading_components["opportunity_detector"].remove_from_watchlist(
            opportunity_id=opportunity_id
        )
        
        return jsonify(result)
    
    @app.route('/api/alerts')
    def api_get_alerts():
        """API endpoint to get alerts"""
        if not trading_components or not trading_components.get("alert_system"):
            return jsonify({"error": "Alert system not initialized"})
        
        # Get parameters
        include_read = request.args.get('include_read', 'false').lower() == 'true'
        include_dismissed = request.args.get('include_dismissed', 'false').lower() == 'true'
        category = request.args.get('category')
        limit = request.args.get('limit', 20, type=int)
        
        # Get alerts
        alerts = trading_components["alert_system"].get_alerts(
            include_read=include_read,
            include_dismissed=include_dismissed,
            category=category,
            limit=limit
        )
        
        return jsonify(alerts)
    
    @app.route('/api/alerts/mark_read', methods=['POST'])
    def api_mark_alert_as_read():
        """API endpoint to mark an alert as read"""
        if not trading_components or not trading_components.get("alert_system"):
            return jsonify({"error": "Alert system not initialized"})
        
        # Get alert ID from request
        data = request.json
        alert_id = data.get('alert_id')
        
        if not alert_id:
            return jsonify({"error": "Alert ID is required"})
        
        # Mark as read
        success = trading_components["alert_system"].mark_alert_as_read(alert_id)
        
        return jsonify({"success": success})
    
    @app.route('/api/alerts/dismiss', methods=['POST'])
    def api_dismiss_alert():
        """API endpoint to dismiss an alert"""
        if not trading_components or not trading_components.get("alert_system"):
            return jsonify({"error": "Alert system not initialized"})
        
        # Get alert ID from request
        data = request.json
        alert_id = data.get('alert_id')
        
        if not alert_id:
            return jsonify({"error": "Alert ID is required"})
        
        # Dismiss alert
        success = trading_components["alert_system"].dismiss_alert(alert_id)
        
        return jsonify({"success": success})
    
    @app.route('/api/alerts/dismiss_all', methods=['POST'])
    def api_dismiss_all_alerts():
        """API endpoint to dismiss all alerts"""
        if not trading_components or not trading_components.get("alert_system"):
            return jsonify({"error": "Alert system not initialized"})
        
        # Get category from request
        data = request.json
        category = data.get('category')
        
        # Dismiss all alerts
        count = trading_components["alert_system"].dismiss_all_alerts(category=category)
        
        return jsonify({"success": True, "dismissed_count": count})
    
    @app.route('/api/alerts/statistics')
    def api_alert_statistics():
        """API endpoint to get alert statistics"""
        if not trading_components or not trading_components.get("alert_system"):
            return jsonify({"error": "Alert system not initialized"})
        
        # Get statistics
        statistics = trading_components["alert_system"].get_alert_statistics()
        
        return jsonify(statistics)
    
    @app.errorhandler(404)
    def page_not_found(e):
        """Handle 404 errors"""
        return render_template('error.html', error=e), 404
    
    @app.errorhandler(500)
    def server_error(e):
        """Handle 500 errors"""
        return render_template('error.html', error=e), 500