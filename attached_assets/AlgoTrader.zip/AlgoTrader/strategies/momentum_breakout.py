"""
Momentum Breakout Strategy Implementation

This strategy identifies and trades breakouts with strong momentum across multiple timeframes,
using the following signals:
1. Price breaking out of consolidation patterns
2. Increasing volume during breakout
3. Strong momentum indicators across multiple timeframes
4. Volatility expansion
"""

import numpy as np
import pandas as pd
import logging
from datetime import datetime
import time

from strategies.base_strategy import BaseStrategy
from utils.indicators import calculate_atr, calculate_rsi, calculate_macd, identify_support_resistance

class MomentumBreakoutStrategy(BaseStrategy):
    """
    Momentum Breakout Strategy class that extends the BaseStrategy
    
    This strategy looks for strong momentum breakouts with the following characteristics:
    - Price breaking out of a consolidation pattern with increased volume
    - Strong momentum indicators (RSI, MACD) confirming the move
    - Multiple timeframe confirmation
    - Volatility expansion (measured by ATR)
    """
    
    def __init__(self, client, risk_manager, symbol, interval='15m', 
                 timeframes=None, atr_period=14, rsi_period=14, 
                 rsi_overbought=70, rsi_oversold=30, use_multi_timeframe=True,
                 max_leverage=20):
        """
        Initialize the Momentum Breakout Strategy
        
        Args:
            client (BinanceClient): Binance client instance
            risk_manager (RiskManager): Risk manager instance
            symbol (str): Trading symbol
            interval (str): Primary timeframe interval
            timeframes (list, optional): Additional timeframes to track
            atr_period (int): ATR calculation period
            rsi_period (int): RSI calculation period
            rsi_overbought (int): RSI overbought threshold
            rsi_oversold (int): RSI oversold threshold
            use_multi_timeframe (bool): Whether to use multi-timeframe analysis
            max_leverage (int): Maximum leverage to use
        """
        # Default timeframes for multi-timeframe analysis
        if timeframes is None:
            timeframes = ['5m', '15m', '1h', '4h']
            
        super().__init__(client, risk_manager, symbol, interval, timeframes)
        
        self.logger = logging.getLogger(__name__)
        self.atr_period = atr_period
        self.rsi_period = rsi_period
        self.rsi_overbought = rsi_overbought
        self.rsi_oversold = rsi_oversold
        self.use_multi_timeframe = use_multi_timeframe
        self.max_leverage = max_leverage
        
        # Strategy-specific state variables
        self.consolidation_detected = False
        self.consolidation_high = 0
        self.consolidation_low = 0
        self.consolidation_duration = 0
        self.volume_baseline = 0
        self.last_signal_time = None
        self.cooldown_period = 60 * 60  # 1 hour cooldown after trade
        
        # Set leverage
        self._set_leverage()
        
        self.logger.info(f"Initialized Momentum Breakout Strategy for {symbol} on {interval} timeframe")
        
    def _set_leverage(self):
        """Set leverage for the symbol"""
        try:
            result = self.client.set_leverage(self.symbol, self.max_leverage)
            self.logger.info(f"Set leverage for {self.symbol} to {self.max_leverage}x: {result}")
        except Exception as e:
            self.logger.error(f"Error setting leverage: {e}")
    
    def on_candle_closed(self, symbol, interval, kline_data):
        """
        Process closed candle data and check for trade signals
        
        Args:
            symbol (str): Trading symbol
            interval (str): Candle interval
            kline_data (dict): Kline/candle data
        """
        if symbol != self.symbol:
            return
        
        # Update historical data for all timeframes
        super().on_candle_closed(symbol, interval, kline_data)
        
        # Only process candles for our strategy's main interval
        if interval != self.interval:
            return
            
        # Check for trade opportunities on new candle close
        self.check_for_signals()
        
    def on_price_update(self, symbol, price, bid, ask):
        """
        Process real-time price updates for potential breakout trade signals
        
        Args:
            symbol (str): Trading symbol
            price (float): Current price
            bid (float): Best bid price
            ask (float): Best ask price
        """
        if symbol != self.symbol:
            return
        
        # Update current price
        self.current_price = price
        
        # Check if we're in a trade
        if self.in_position:
            # Check for stop loss or take profit conditions
            self._check_exit_conditions(price)
            return
        
        # If we've detected a consolidation pattern previously, check for breakout in real-time
        if self.consolidation_detected:
            # Check for upward breakout
            if price > self.consolidation_high * 1.005:  # 0.5% breakout confirmation
                # Confirm with volume and momentum
                if self._confirm_breakout('LONG'):
                    self._enter_long_position(price)
                    
            # Check for downward breakout
            elif price < self.consolidation_low * 0.995:  # 0.5% breakout confirmation
                # Confirm with volume and momentum
                if self._confirm_breakout('SHORT'):
                    self._enter_short_position(price)
        
    def check_for_signals(self):
        """
        Check historical data for entry/exit signals
        Called after each candle close on the main timeframe
        """
        # Don't check for new signals if we're in a trade
        if self.in_position:
            return
            
        # Don't check for signals if we're in cooldown period after a trade
        if self.last_signal_time and (time.time() - self.last_signal_time) < self.cooldown_period:
            return
        
        # Get historical data for the main timeframe
        df = self.historical_data[self.interval]
        
        if len(df) < 50:  # Ensure we have enough data
            self.logger.warning(f"Not enough historical data for {self.symbol}")
            return
        
        # Calculate indicators
        df = calculate_atr(df, period=self.atr_period)
        df = calculate_rsi(df, period=self.rsi_period)
        df = calculate_macd(df)
        
        # Detect consolidation patterns
        self._detect_consolidation(df)
        
        # Check for breakout signals
        if self.consolidation_detected:
            # Get the latest candle
            latest = df.iloc[-1]
            prev = df.iloc[-2]
            
            # Check for volume increase (1.5x above average)
            volume_increased = latest['volume'] > (self.volume_baseline * 1.5)
            
            # Check for upward breakout
            if latest['close'] > self.consolidation_high and volume_increased:
                # Confirm with momentum indicators
                if latest['rsi'] > 60 and latest['macd'] > 0 and latest['macd'] > prev['macd']:
                    # Check multi-timeframe confirmation if enabled
                    if not self.use_multi_timeframe or self._check_multi_timeframe_confirmation('LONG'):
                        self._enter_long_position(latest['close'])
            
            # Check for downward breakout
            elif latest['close'] < self.consolidation_low and volume_increased:
                # Confirm with momentum indicators
                if latest['rsi'] < 40 and latest['macd'] < 0 and latest['macd'] < prev['macd']:
                    # Check multi-timeframe confirmation if enabled
                    if not self.use_multi_timeframe or self._check_multi_timeframe_confirmation('SHORT'):
                        self._enter_short_position(latest['close'])
    
    def _detect_consolidation(self, df):
        """
        Detect consolidation patterns in the price data
        
        Args:
            df (pd.DataFrame): Historical price data with indicators
        """
        # Minimum number of candles to check for consolidation
        lookback = 20
        
        if len(df) < lookback:
            return
            
        # Get recent candles
        recent = df.iloc[-lookback:]
        
        # Calculate price range as percentage of current price
        high = recent['high'].max()
        low = recent['low'].min()
        last_close = df.iloc[-1]['close']
        price_range_pct = (high - low) / last_close * 100
        
        # Calculate ATR as percentage of price
        atr = df.iloc[-1]['atr']
        atr_pct = atr / last_close * 100
        
        # Check if price range is small relative to historical volatility
        # and ATR is decreasing (volatility contraction)
        atr_decreasing = df.iloc[-5:]['atr'].pct_change().mean() < 0
        
        # Detect consolidation (tight price range and decreasing volatility)
        if price_range_pct < 3.0 and atr_decreasing:
            # Identify support and resistance within consolidation
            support, resistance = identify_support_resistance(recent)
            
            # Update consolidation state
            self.consolidation_detected = True
            self.consolidation_high = resistance
            self.consolidation_low = support
            self.consolidation_duration = lookback
            self.volume_baseline = recent['volume'].mean()
            
            self.logger.info(f"Detected consolidation pattern for {self.symbol}: "
                            f"Support: {support:.2f}, Resistance: {resistance:.2f}, "
                            f"Range: {price_range_pct:.2f}%, ATR: {atr_pct:.2f}%")
        else:
            # Reset consolidation state if no longer in consolidation
            self.consolidation_detected = False
            
    def _confirm_breakout(self, direction):
        """
        Confirm breakout with additional indicators
        
        Args:
            direction (str): 'LONG' or 'SHORT'
            
        Returns:
            bool: Whether breakout is confirmed
        """
        df = self.historical_data[self.interval]
        
        # Ensure we have enough data
        if len(df) < 30:
            return False
            
        # Calculate indicators
        if 'rsi' not in df.columns:
            df = calculate_rsi(df, period=self.rsi_period)
        if 'macd' not in df.columns:
            df = calculate_macd(df)
            
        # Get most recent values
        latest_rsi = df.iloc[-1]['rsi']
        latest_macd = df.iloc[-1]['macd']
        latest_signal = df.iloc[-1]['macd_signal']
        latest_volume = df.iloc[-1]['volume']
        
        # Check for additional confirmation factors
        volume_confirmation = latest_volume > (self.volume_baseline * 1.5)
        
        if direction == 'LONG':
            # Strong momentum and volume for long position
            momentum_confirmation = latest_rsi > 55 and latest_macd > 0 and latest_macd > latest_signal
            multi_tf_confirmation = not self.use_multi_timeframe or self._check_multi_timeframe_confirmation('LONG')
            
            return volume_confirmation and momentum_confirmation and multi_tf_confirmation
            
        else:  # SHORT
            # Strong momentum and volume for short position
            momentum_confirmation = latest_rsi < 45 and latest_macd < 0 and latest_macd < latest_signal
            multi_tf_confirmation = not self.use_multi_timeframe or self._check_multi_timeframe_confirmation('SHORT')
            
            return volume_confirmation and momentum_confirmation and multi_tf_confirmation
            
    def _check_multi_timeframe_confirmation(self, direction):
        """
        Check for confirmation across multiple timeframes
        
        Args:
            direction (str): 'LONG' or 'SHORT'
            
        Returns:
            bool: Whether signal is confirmed across timeframes
        """
        # Skip if we're not using multi-timeframe analysis
        if not self.use_multi_timeframe:
            return True
            
        confirmations = 0
        required_confirmations = len(self.timeframes) // 2  # At least half of the timeframes must confirm
        
        for tf in self.timeframes:
            if tf not in self.historical_data or len(self.historical_data[tf]) < 30:
                continue
                
            # Get data for this timeframe
            df = self.historical_data[tf]
            
            # Calculate indicators if needed
            if 'rsi' not in df.columns:
                df = calculate_rsi(df, period=self.rsi_period)
            if 'macd' not in df.columns:
                df = calculate_macd(df)
                
            # Get most recent values
            latest_rsi = df.iloc[-1]['rsi']
            latest_macd = df.iloc[-1]['macd']
            prev_macd = df.iloc[-2]['macd'] if len(df) > 2 else 0
            
            # Check for confirmation based on direction
            if direction == 'LONG':
                if latest_rsi > 50 and latest_macd > 0 and latest_macd > prev_macd:
                    confirmations += 1
            else:  # SHORT
                if latest_rsi < 50 and latest_macd < 0 and latest_macd < prev_macd:
                    confirmations += 1
        
        # Return True if we have enough confirmations
        return confirmations >= required_confirmations
            
    def _enter_long_position(self, price):
        """
        Enter a long position
        
        Args:
            price (float): Entry price
        """
        # Don't enter if we're already in a position
        if self.in_position:
            return

        # Calculate stop loss and take profit prices
        atr = self.historical_data[self.interval].iloc[-1].get('atr', price * 0.02)  # Default to 2% if ATR not available
        
        stop_loss_price = price - (atr * 1.5)  # Stop loss at 1.5 ATR
        take_profit_price = price + (atr * 3.0)  # Take profit at 3.0 ATR (2:1 reward-risk)
        
        # Calculate position size based on risk management
        position_size = self.risk_manager.calculate_position_size(
            symbol=self.symbol,
            entry_price=price,
            stop_loss_price=stop_loss_price
        )
        
        # Enter position through the base strategy class
        success = self.enter_position(
            side='LONG',
            size=position_size,
            entry_price=price,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price
        )
        
        if success:
            self.logger.info(f"Entered LONG position for {self.symbol} at {price:.2f} with size {position_size:.6f}")
            self.last_signal_time = time.time()
        
    def _enter_short_position(self, price):
        """
        Enter a short position
        
        Args:
            price (float): Entry price
        """
        # Don't enter if we're already in a position
        if self.in_position:
            return
            
        # Calculate stop loss and take profit prices
        atr = self.historical_data[self.interval].iloc[-1].get('atr', price * 0.02)  # Default to 2% if ATR not available
        
        stop_loss_price = price + (atr * 1.5)  # Stop loss at 1.5 ATR
        take_profit_price = price - (atr * 3.0)  # Take profit at 3.0 ATR (2:1 reward-risk)
        
        # Calculate position size based on risk management
        position_size = self.risk_manager.calculate_position_size(
            symbol=self.symbol,
            entry_price=price,
            stop_loss_price=stop_loss_price
        )
        
        # Enter position through the base strategy class
        success = self.enter_position(
            side='SHORT',
            size=position_size,
            entry_price=price,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price
        )
        
        if success:
            self.logger.info(f"Entered SHORT position for {self.symbol} at {price:.2f} with size {position_size:.6f}")
            self.last_signal_time = time.time()