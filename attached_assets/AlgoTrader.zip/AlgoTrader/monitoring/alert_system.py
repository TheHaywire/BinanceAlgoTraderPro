"""
Intelligent Alerting System for trading opportunities and active trade monitoring
"""

import logging
import json
from datetime import datetime, timedelta
import math

class AlertSystem:
    """
    Advanced alert system for intelligently prioritizing and delivering trading alerts
    """
    
    def __init__(self):
        """Initialize the alert system"""
        self.logger = logging.getLogger(__name__)
        
        # Store active alerts
        self.active_alerts = []
        
        # Store alert history
        self.alert_history = []
        
        # Alert thresholds
        self.thresholds = {
            'position_drawdown': 5.0,  # Alert if position drawdown exceeds 5%
            'position_profit': 10.0,   # Alert if position profit exceeds 10%
            'liquidation_risk': 20.0,  # Alert if margin ratio drops below 20%
            'opportunity_score': 80.0  # Alert for opportunities with score above 80
        }
        
        # Alert categories and their priority weights
        self.alert_categories = {
            'liquidation_warning': {
                'priority': 100,
                'color': '#FF0000',  # Red
                'sound': 'critical_alert'
            },
            'high_opportunity': {
                'priority': 90,
                'color': '#00FF00',  # Green
                'sound': 'opportunity_alert'
            },
            'position_risk': {
                'priority': 80,
                'color': '#FFA500',  # Orange
                'sound': 'warning_alert'
            },
            'position_target': {
                'priority': 70,
                'color': '#00FF00',  # Green
                'sound': 'success_alert'
            },
            'market_movement': {
                'priority': 60,
                'color': '#FFFF00',  # Yellow
                'sound': 'info_alert'
            },
            'pattern_developing': {
                'priority': 50,
                'color': '#00FFFF',  # Cyan
                'sound': 'pattern_alert'
            },
            'system_notification': {
                'priority': 40,
                'color': '#FFFFFF',  # White
                'sound': 'notification'
            }
        }
    
    def check_position_alerts(self, trade_monitor):
        """
        Check for position-related alerts
        
        Args:
            trade_monitor (TradeMonitor): Trade monitor instance
            
        Returns:
            list: New alerts
        """
        new_alerts = []
        
        try:
            # Get active trades from the trade monitor
            active_trades = trade_monitor.active_trades
            
            for trade_id, trade in active_trades.items():
                # Check for significant drawdown
                if trade['pl_percent'] < -self.thresholds['position_drawdown']:
                    alert = self._create_alert(
                        category='position_risk',
                        title=f"Position Drawdown: {trade['symbol']}",
                        message=f"Position drawdown of {trade['pl_percent']:.2f}% exceeds threshold of {self.thresholds['position_drawdown']}%",
                        data={
                            'trade_id': trade_id,
                            'symbol': trade['symbol'],
                            'side': trade['side'],
                            'entry_price': trade['entry_price'],
                            'current_price': trade['current_price'],
                            'pl_percent': trade['pl_percent']
                        }
                    )
                    new_alerts.append(alert)
                
                # Check for significant profit
                if trade['pl_percent'] > self.thresholds['position_profit']:
                    alert = self._create_alert(
                        category='position_target',
                        title=f"Profit Target: {trade['symbol']}",
                        message=f"Position profit of {trade['pl_percent']:.2f}% exceeds threshold of {self.thresholds['position_profit']}%",
                        data={
                            'trade_id': trade_id,
                            'symbol': trade['symbol'],
                            'side': trade['side'],
                            'entry_price': trade['entry_price'],
                            'current_price': trade['current_price'],
                            'pl_percent': trade['pl_percent']
                        }
                    )
                    new_alerts.append(alert)
                
                # Check for liquidation risk
                if trade.get('margin_ratio', 100) < self.thresholds['liquidation_risk']:
                    alert = self._create_alert(
                        category='liquidation_warning',
                        title=f"Liquidation Risk: {trade['symbol']}",
                        message=f"Position margin ratio of {trade.get('margin_ratio', 0):.2f}% below threshold of {self.thresholds['liquidation_risk']}%",
                        data={
                            'trade_id': trade_id,
                            'symbol': trade['symbol'],
                            'side': trade['side'],
                            'entry_price': trade['entry_price'],
                            'current_price': trade['current_price'],
                            'margin_ratio': trade.get('margin_ratio', 0),
                            'liquidation_price': trade.get('liquidation_price', 0)
                        }
                    )
                    new_alerts.append(alert)
            
            # Add new alerts to active alerts
            for alert in new_alerts:
                # Check if alert already exists
                if not any(a['id'] == alert['id'] for a in self.active_alerts):
                    self.active_alerts.append(alert)
            
            return new_alerts
            
        except Exception as e:
            self.logger.error(f"Error checking position alerts: {e}")
            return []
    
    def check_opportunity_alerts(self, opportunity_detector):
        """
        Check for opportunity-related alerts
        
        Args:
            opportunity_detector (OpportunityDetector): Opportunity detector instance
            
        Returns:
            list: New alerts
        """
        new_alerts = []
        
        try:
            # Get opportunities from the detector
            opportunities = opportunity_detector.opportunities
            
            for opportunity in opportunities:
                # Check for high-scoring opportunities
                if opportunity['score'] >= self.thresholds['opportunity_score']:
                    alert = self._create_alert(
                        category='high_opportunity',
                        title=f"High-Score Opportunity: {opportunity['symbol']}",
                        message=f"Found {opportunity['direction']} opportunity with score {opportunity['score']} ({opportunity.get('type', 'unknown')} - {opportunity.get('pattern', opportunity.get('anomaly', opportunity.get('momentum', 'unknown')))})",
                        data={
                            'opportunity_id': opportunity.get('id', ''),
                            'symbol': opportunity['symbol'],
                            'type': opportunity.get('type', 'unknown'),
                            'pattern': opportunity.get('pattern', opportunity.get('anomaly', opportunity.get('momentum', 'unknown'))),
                            'direction': opportunity['direction'],
                            'score': opportunity['score'],
                            'price': opportunity['price'],
                            'timeframe': opportunity.get('timeframe', '1h')
                        }
                    )
                    new_alerts.append(alert)
            
            # Add new alerts to active alerts
            for alert in new_alerts:
                # Check if alert already exists
                if not any(a['id'] == alert['id'] for a in self.active_alerts):
                    self.active_alerts.append(alert)
            
            return new_alerts
            
        except Exception as e:
            self.logger.error(f"Error checking opportunity alerts: {e}")
            return []
    
    def create_market_movement_alert(self, symbol, price, change_percent, volume_change=None):
        """
        Create a market movement alert
        
        Args:
            symbol (str): Symbol that experienced significant movement
            price (float): Current price
            change_percent (float): Price change percentage
            volume_change (float, optional): Volume change percentage
            
        Returns:
            dict: Created alert
        """
        try:
            direction = 'up' if change_percent > 0 else 'down'
            
            alert = self._create_alert(
                category='market_movement',
                title=f"Market Movement: {symbol}",
                message=f"{symbol} moved {direction} by {abs(change_percent):.2f}% to {price}",
                data={
                    'symbol': symbol,
                    'price': price,
                    'change_percent': change_percent,
                    'volume_change': volume_change,
                    'direction': 'bullish' if change_percent > 0 else 'bearish'
                }
            )
            
            # Add to active alerts
            if not any(a['id'] == alert['id'] for a in self.active_alerts):
                self.active_alerts.append(alert)
            
            return alert
            
        except Exception as e:
            self.logger.error(f"Error creating market movement alert: {e}")
            return None
    
    def create_pattern_developing_alert(self, symbol, pattern, timeframe, completion_percent, direction):
        """
        Create an alert for a developing pattern
        
        Args:
            symbol (str): Symbol where pattern is developing
            pattern (str): Pattern type
            timeframe (str): Timeframe
            completion_percent (float): Pattern completion percentage
            direction (str): Expected direction after pattern completes
            
        Returns:
            dict: Created alert
        """
        try:
            alert = self._create_alert(
                category='pattern_developing',
                title=f"Pattern Developing: {symbol}",
                message=f"{pattern} pattern forming on {symbol} ({timeframe}), {completion_percent:.0f}% complete, potential {direction} move",
                data={
                    'symbol': symbol,
                    'pattern': pattern,
                    'timeframe': timeframe,
                    'completion_percent': completion_percent,
                    'direction': direction
                }
            )
            
            # Add to active alerts
            if not any(a['id'] == alert['id'] for a in self.active_alerts):
                self.active_alerts.append(alert)
            
            return alert
            
        except Exception as e:
            self.logger.error(f"Error creating pattern developing alert: {e}")
            return None
    
    def create_system_notification(self, title, message, data=None):
        """
        Create a system notification
        
        Args:
            title (str): Notification title
            message (str): Notification message
            data (dict, optional): Additional data
            
        Returns:
            dict: Created alert
        """
        try:
            alert = self._create_alert(
                category='system_notification',
                title=title,
                message=message,
                data=data or {}
            )
            
            # Add to active alerts
            if not any(a['id'] == alert['id'] for a in self.active_alerts):
                self.active_alerts.append(alert)
            
            return alert
            
        except Exception as e:
            self.logger.error(f"Error creating system notification: {e}")
            return None
    
    def _create_alert(self, category, title, message, data=None):
        """
        Create an alert
        
        Args:
            category (str): Alert category
            title (str): Alert title
            message (str): Alert message
            data (dict, optional): Additional data
            
        Returns:
            dict: Created alert
        """
        try:
            # Generate a unique ID for the alert
            alert_id = f"{category}_{datetime.utcnow().timestamp()}"
            
            # Get category metadata
            category_info = self.alert_categories.get(category, {
                'priority': 0,
                'color': '#FFFFFF',
                'sound': 'default'
            })
            
            # Create alert
            alert = {
                'id': alert_id,
                'category': category,
                'title': title,
                'message': message,
                'created_at': datetime.utcnow().isoformat(),
                'expires_at': (datetime.utcnow() + timedelta(hours=24)).isoformat(),
                'is_read': False,
                'is_dismissed': False,
                'priority': category_info['priority'],
                'color': category_info['color'],
                'sound': category_info['sound'],
                'data': data or {}
            }
            
            self.logger.info(f"Created alert: {title}")
            return alert
            
        except Exception as e:
            self.logger.error(f"Error creating alert: {e}")
            return None
    
    def get_alerts(self, include_read=False, include_dismissed=False, category=None, limit=20):
        """
        Get active alerts
        
        Args:
            include_read (bool, optional): Include read alerts
            include_dismissed (bool, optional): Include dismissed alerts
            category (str, optional): Filter by category
            limit (int, optional): Maximum number of alerts to return
            
        Returns:
            list: Filtered alerts
        """
        try:
            filtered_alerts = []
            
            for alert in self.active_alerts:
                # Skip read alerts if not included
                if not include_read and alert['is_read']:
                    continue
                    
                # Skip dismissed alerts if not included
                if not include_dismissed and alert['is_dismissed']:
                    continue
                    
                # Skip if category filter is applied and doesn't match
                if category and alert['category'] != category:
                    continue
                    
                filtered_alerts.append(alert)
            
            # Sort by priority (highest first), then by creation time (newest first)
            sorted_alerts = sorted(
                filtered_alerts,
                key=lambda a: (-a['priority'], a['created_at']),
                reverse=True
            )
            
            # Return up to limit
            return sorted_alerts[:limit]
            
        except Exception as e:
            self.logger.error(f"Error getting alerts: {e}")
            return []
    
    def mark_alert_as_read(self, alert_id):
        """
        Mark an alert as read
        
        Args:
            alert_id (str): Alert ID
            
        Returns:
            bool: Success flag
        """
        try:
            # Find the alert
            alert = next((a for a in self.active_alerts if a['id'] == alert_id), None)
            
            if not alert:
                return False
                
            # Mark as read
            alert['is_read'] = True
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error marking alert as read: {e}")
            return False
    
    def dismiss_alert(self, alert_id):
        """
        Dismiss an alert
        
        Args:
            alert_id (str): Alert ID
            
        Returns:
            bool: Success flag
        """
        try:
            # Find the alert
            alert = next((a for a in self.active_alerts if a['id'] == alert_id), None)
            
            if not alert:
                return False
                
            # Mark as dismissed
            alert['is_dismissed'] = True
            
            # Add to history
            self.alert_history.append(alert)
            
            # Remove from active alerts
            self.active_alerts = [a for a in self.active_alerts if a['id'] != alert_id]
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error dismissing alert: {e}")
            return False
    
    def dismiss_all_alerts(self, category=None):
        """
        Dismiss all alerts
        
        Args:
            category (str, optional): Dismiss only alerts in this category
            
        Returns:
            int: Number of alerts dismissed
        """
        try:
            dismissed_count = 0
            
            # Filter alerts to dismiss
            to_dismiss = []
            remaining = []
            
            for alert in self.active_alerts:
                if category is None or alert['category'] == category:
                    alert['is_dismissed'] = True
                    to_dismiss.append(alert)
                    dismissed_count += 1
                else:
                    remaining.append(alert)
            
            # Add dismissed alerts to history
            self.alert_history.extend(to_dismiss)
            
            # Update active alerts
            self.active_alerts = remaining
            
            return dismissed_count
            
        except Exception as e:
            self.logger.error(f"Error dismissing all alerts: {e}")
            return 0
    
    def clean_expired_alerts(self):
        """
        Clean expired alerts
        
        Returns:
            int: Number of alerts cleaned
        """
        try:
            cleaned_count = 0
            current_time = datetime.utcnow()
            
            # Filter expired alerts
            expired = []
            remaining = []
            
            for alert in self.active_alerts:
                expires_at = datetime.fromisoformat(alert['expires_at'].replace('Z', '+00:00'))
                
                if expires_at < current_time:
                    alert['is_dismissed'] = True
                    expired.append(alert)
                    cleaned_count += 1
                else:
                    remaining.append(alert)
            
            # Add expired alerts to history
            self.alert_history.extend(expired)
            
            # Update active alerts
            self.active_alerts = remaining
            
            return cleaned_count
            
        except Exception as e:
            self.logger.error(f"Error cleaning expired alerts: {e}")
            return 0
    
    def get_alert_statistics(self):
        """
        Get alert statistics
        
        Returns:
            dict: Alert statistics
        """
        try:
            # Count alerts by category
            category_counts = {}
            
            for alert in self.active_alerts:
                category = alert['category']
                if category not in category_counts:
                    category_counts[category] = 0
                category_counts[category] += 1
            
            # Count unread alerts
            unread_count = len([a for a in self.active_alerts if not a['is_read']])
            
            # Count high priority alerts
            high_priority_count = len([a for a in self.active_alerts if a['priority'] >= 80])
            
            return {
                'total_active': len(self.active_alerts),
                'total_history': len(self.alert_history),
                'unread_count': unread_count,
                'high_priority_count': high_priority_count,
                'by_category': category_counts
            }
            
        except Exception as e:
            self.logger.error(f"Error getting alert statistics: {e}")
            return {}